// symtab.h — symbol table lookup for backtrace

// Number of entries in the symbol table.
extern int nsyminfos;

// Look up a kernel address and write the function name
// and file:line into the provided buffers (each of size 64).
// Returns 0 on success, -1 if not found.
int lookup_symbol(uint64 addr, char *func_out, char *fileline_out);
