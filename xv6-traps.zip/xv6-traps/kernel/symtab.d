kernel/symtab.o: kernel/symtab.c kernel/types.h kernel/symtab.h
