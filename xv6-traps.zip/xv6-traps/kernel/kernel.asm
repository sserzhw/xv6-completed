
kernel/kernel：     文件格式 elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	0000e117          	auipc	sp,0xe
    80000004:	e0013103          	ld	sp,-512(sp) # 8000de00 <_GLOBAL_OFFSET_TABLE_+0x8>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	1d9050ef          	jal	800059ee <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    8000001c:	1101                	addi	sp,sp,-32
    8000001e:	ec06                	sd	ra,24(sp)
    80000020:	e822                	sd	s0,16(sp)
    80000022:	e426                	sd	s1,8(sp)
    80000024:	e04a                	sd	s2,0(sp)
    80000026:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000028:	03451793          	slli	a5,a0,0x34
    8000002c:	ebb9                	bnez	a5,80000082 <kfree+0x66>
    8000002e:	84aa                	mv	s1,a0
    80000030:	00028797          	auipc	a5,0x28
    80000034:	a9078793          	addi	a5,a5,-1392 # 80027ac0 <end>
    80000038:	04f56563          	bltu	a0,a5,80000082 <kfree+0x66>
    8000003c:	47c5                	li	a5,17
    8000003e:	07ee                	slli	a5,a5,0x1b
    80000040:	04f57163          	bgeu	a0,a5,80000082 <kfree+0x66>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000044:	6605                	lui	a2,0x1
    80000046:	4585                	li	a1,1
    80000048:	00000097          	auipc	ra,0x0
    8000004c:	132080e7          	jalr	306(ra) # 8000017a <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000050:	0000e917          	auipc	s2,0xe
    80000054:	e0090913          	addi	s2,s2,-512 # 8000de50 <kmem>
    80000058:	854a                	mv	a0,s2
    8000005a:	00006097          	auipc	ra,0x6
    8000005e:	4b4080e7          	jalr	1204(ra) # 8000650e <acquire>
  r->next = kmem.freelist;
    80000062:	01893783          	ld	a5,24(s2)
    80000066:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000068:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    8000006c:	854a                	mv	a0,s2
    8000006e:	00006097          	auipc	ra,0x6
    80000072:	554080e7          	jalr	1364(ra) # 800065c2 <release>
}
    80000076:	60e2                	ld	ra,24(sp)
    80000078:	6442                	ld	s0,16(sp)
    8000007a:	64a2                	ld	s1,8(sp)
    8000007c:	6902                	ld	s2,0(sp)
    8000007e:	6105                	addi	sp,sp,32
    80000080:	8082                	ret
    panic("kfree");
    80000082:	00008517          	auipc	a0,0x8
    80000086:	f7e50513          	addi	a0,a0,-130 # 80008000 <etext>
    8000008a:	00006097          	auipc	ra,0x6
    8000008e:	f02080e7          	jalr	-254(ra) # 80005f8c <panic>

0000000080000092 <freerange>:
{
    80000092:	7179                	addi	sp,sp,-48
    80000094:	f406                	sd	ra,40(sp)
    80000096:	f022                	sd	s0,32(sp)
    80000098:	ec26                	sd	s1,24(sp)
    8000009a:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    8000009c:	6785                	lui	a5,0x1
    8000009e:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    800000a2:	00e504b3          	add	s1,a0,a4
    800000a6:	777d                	lui	a4,0xfffff
    800000a8:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000aa:	94be                	add	s1,s1,a5
    800000ac:	0295e463          	bltu	a1,s1,800000d4 <freerange+0x42>
    800000b0:	e84a                	sd	s2,16(sp)
    800000b2:	e44e                	sd	s3,8(sp)
    800000b4:	e052                	sd	s4,0(sp)
    800000b6:	892e                	mv	s2,a1
    kfree(p);
    800000b8:	7a7d                	lui	s4,0xfffff
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000ba:	6985                	lui	s3,0x1
    kfree(p);
    800000bc:	01448533          	add	a0,s1,s4
    800000c0:	00000097          	auipc	ra,0x0
    800000c4:	f5c080e7          	jalr	-164(ra) # 8000001c <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000c8:	94ce                	add	s1,s1,s3
    800000ca:	fe9979e3          	bgeu	s2,s1,800000bc <freerange+0x2a>
    800000ce:	6942                	ld	s2,16(sp)
    800000d0:	69a2                	ld	s3,8(sp)
    800000d2:	6a02                	ld	s4,0(sp)
}
    800000d4:	70a2                	ld	ra,40(sp)
    800000d6:	7402                	ld	s0,32(sp)
    800000d8:	64e2                	ld	s1,24(sp)
    800000da:	6145                	addi	sp,sp,48
    800000dc:	8082                	ret

00000000800000de <kinit>:
{
    800000de:	1141                	addi	sp,sp,-16
    800000e0:	e406                	sd	ra,8(sp)
    800000e2:	e022                	sd	s0,0(sp)
    800000e4:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    800000e6:	00008597          	auipc	a1,0x8
    800000ea:	f2a58593          	addi	a1,a1,-214 # 80008010 <etext+0x10>
    800000ee:	0000e517          	auipc	a0,0xe
    800000f2:	d6250513          	addi	a0,a0,-670 # 8000de50 <kmem>
    800000f6:	00006097          	auipc	ra,0x6
    800000fa:	388080e7          	jalr	904(ra) # 8000647e <initlock>
  freerange(end, (void*)PHYSTOP);
    800000fe:	45c5                	li	a1,17
    80000100:	05ee                	slli	a1,a1,0x1b
    80000102:	00028517          	auipc	a0,0x28
    80000106:	9be50513          	addi	a0,a0,-1602 # 80027ac0 <end>
    8000010a:	00000097          	auipc	ra,0x0
    8000010e:	f88080e7          	jalr	-120(ra) # 80000092 <freerange>
}
    80000112:	60a2                	ld	ra,8(sp)
    80000114:	6402                	ld	s0,0(sp)
    80000116:	0141                	addi	sp,sp,16
    80000118:	8082                	ret

000000008000011a <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    8000011a:	1101                	addi	sp,sp,-32
    8000011c:	ec06                	sd	ra,24(sp)
    8000011e:	e822                	sd	s0,16(sp)
    80000120:	e426                	sd	s1,8(sp)
    80000122:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000124:	0000e497          	auipc	s1,0xe
    80000128:	d2c48493          	addi	s1,s1,-724 # 8000de50 <kmem>
    8000012c:	8526                	mv	a0,s1
    8000012e:	00006097          	auipc	ra,0x6
    80000132:	3e0080e7          	jalr	992(ra) # 8000650e <acquire>
  r = kmem.freelist;
    80000136:	6c84                	ld	s1,24(s1)
  if(r)
    80000138:	c885                	beqz	s1,80000168 <kalloc+0x4e>
    kmem.freelist = r->next;
    8000013a:	609c                	ld	a5,0(s1)
    8000013c:	0000e517          	auipc	a0,0xe
    80000140:	d1450513          	addi	a0,a0,-748 # 8000de50 <kmem>
    80000144:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000146:	00006097          	auipc	ra,0x6
    8000014a:	47c080e7          	jalr	1148(ra) # 800065c2 <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    8000014e:	6605                	lui	a2,0x1
    80000150:	4595                	li	a1,5
    80000152:	8526                	mv	a0,s1
    80000154:	00000097          	auipc	ra,0x0
    80000158:	026080e7          	jalr	38(ra) # 8000017a <memset>
  return (void*)r;
}
    8000015c:	8526                	mv	a0,s1
    8000015e:	60e2                	ld	ra,24(sp)
    80000160:	6442                	ld	s0,16(sp)
    80000162:	64a2                	ld	s1,8(sp)
    80000164:	6105                	addi	sp,sp,32
    80000166:	8082                	ret
  release(&kmem.lock);
    80000168:	0000e517          	auipc	a0,0xe
    8000016c:	ce850513          	addi	a0,a0,-792 # 8000de50 <kmem>
    80000170:	00006097          	auipc	ra,0x6
    80000174:	452080e7          	jalr	1106(ra) # 800065c2 <release>
  if(r)
    80000178:	b7d5                	j	8000015c <kalloc+0x42>

000000008000017a <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    8000017a:	1141                	addi	sp,sp,-16
    8000017c:	e422                	sd	s0,8(sp)
    8000017e:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000180:	ca19                	beqz	a2,80000196 <memset+0x1c>
    80000182:	87aa                	mv	a5,a0
    80000184:	1602                	slli	a2,a2,0x20
    80000186:	9201                	srli	a2,a2,0x20
    80000188:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    8000018c:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000190:	0785                	addi	a5,a5,1
    80000192:	fee79de3          	bne	a5,a4,8000018c <memset+0x12>
  }
  return dst;
}
    80000196:	6422                	ld	s0,8(sp)
    80000198:	0141                	addi	sp,sp,16
    8000019a:	8082                	ret

000000008000019c <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    8000019c:	1141                	addi	sp,sp,-16
    8000019e:	e422                	sd	s0,8(sp)
    800001a0:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    800001a2:	ca05                	beqz	a2,800001d2 <memcmp+0x36>
    800001a4:	fff6069b          	addiw	a3,a2,-1 # fff <_entry-0x7ffff001>
    800001a8:	1682                	slli	a3,a3,0x20
    800001aa:	9281                	srli	a3,a3,0x20
    800001ac:	0685                	addi	a3,a3,1
    800001ae:	96aa                	add	a3,a3,a0
    if(*s1 != *s2)
    800001b0:	00054783          	lbu	a5,0(a0)
    800001b4:	0005c703          	lbu	a4,0(a1)
    800001b8:	00e79863          	bne	a5,a4,800001c8 <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    800001bc:	0505                	addi	a0,a0,1
    800001be:	0585                	addi	a1,a1,1
  while(n-- > 0){
    800001c0:	fed518e3          	bne	a0,a3,800001b0 <memcmp+0x14>
  }

  return 0;
    800001c4:	4501                	li	a0,0
    800001c6:	a019                	j	800001cc <memcmp+0x30>
      return *s1 - *s2;
    800001c8:	40e7853b          	subw	a0,a5,a4
}
    800001cc:	6422                	ld	s0,8(sp)
    800001ce:	0141                	addi	sp,sp,16
    800001d0:	8082                	ret
  return 0;
    800001d2:	4501                	li	a0,0
    800001d4:	bfe5                	j	800001cc <memcmp+0x30>

00000000800001d6 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    800001d6:	1141                	addi	sp,sp,-16
    800001d8:	e422                	sd	s0,8(sp)
    800001da:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    800001dc:	c205                	beqz	a2,800001fc <memmove+0x26>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    800001de:	02a5e263          	bltu	a1,a0,80000202 <memmove+0x2c>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    800001e2:	1602                	slli	a2,a2,0x20
    800001e4:	9201                	srli	a2,a2,0x20
    800001e6:	00c587b3          	add	a5,a1,a2
{
    800001ea:	872a                	mv	a4,a0
      *d++ = *s++;
    800001ec:	0585                	addi	a1,a1,1
    800001ee:	0705                	addi	a4,a4,1 # fffffffffffff001 <end+0xffffffff7ffd7541>
    800001f0:	fff5c683          	lbu	a3,-1(a1)
    800001f4:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    800001f8:	feb79ae3          	bne	a5,a1,800001ec <memmove+0x16>

  return dst;
}
    800001fc:	6422                	ld	s0,8(sp)
    800001fe:	0141                	addi	sp,sp,16
    80000200:	8082                	ret
  if(s < d && s + n > d){
    80000202:	02061693          	slli	a3,a2,0x20
    80000206:	9281                	srli	a3,a3,0x20
    80000208:	00d58733          	add	a4,a1,a3
    8000020c:	fce57be3          	bgeu	a0,a4,800001e2 <memmove+0xc>
    d += n;
    80000210:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000212:	fff6079b          	addiw	a5,a2,-1
    80000216:	1782                	slli	a5,a5,0x20
    80000218:	9381                	srli	a5,a5,0x20
    8000021a:	fff7c793          	not	a5,a5
    8000021e:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000220:	177d                	addi	a4,a4,-1
    80000222:	16fd                	addi	a3,a3,-1
    80000224:	00074603          	lbu	a2,0(a4)
    80000228:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    8000022c:	fef71ae3          	bne	a4,a5,80000220 <memmove+0x4a>
    80000230:	b7f1                	j	800001fc <memmove+0x26>

0000000080000232 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000232:	1141                	addi	sp,sp,-16
    80000234:	e406                	sd	ra,8(sp)
    80000236:	e022                	sd	s0,0(sp)
    80000238:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    8000023a:	00000097          	auipc	ra,0x0
    8000023e:	f9c080e7          	jalr	-100(ra) # 800001d6 <memmove>
}
    80000242:	60a2                	ld	ra,8(sp)
    80000244:	6402                	ld	s0,0(sp)
    80000246:	0141                	addi	sp,sp,16
    80000248:	8082                	ret

000000008000024a <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    8000024a:	1141                	addi	sp,sp,-16
    8000024c:	e422                	sd	s0,8(sp)
    8000024e:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000250:	ce11                	beqz	a2,8000026c <strncmp+0x22>
    80000252:	00054783          	lbu	a5,0(a0)
    80000256:	cf89                	beqz	a5,80000270 <strncmp+0x26>
    80000258:	0005c703          	lbu	a4,0(a1)
    8000025c:	00f71a63          	bne	a4,a5,80000270 <strncmp+0x26>
    n--, p++, q++;
    80000260:	367d                	addiw	a2,a2,-1
    80000262:	0505                	addi	a0,a0,1
    80000264:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000266:	f675                	bnez	a2,80000252 <strncmp+0x8>
  if(n == 0)
    return 0;
    80000268:	4501                	li	a0,0
    8000026a:	a801                	j	8000027a <strncmp+0x30>
    8000026c:	4501                	li	a0,0
    8000026e:	a031                	j	8000027a <strncmp+0x30>
  return (uchar)*p - (uchar)*q;
    80000270:	00054503          	lbu	a0,0(a0)
    80000274:	0005c783          	lbu	a5,0(a1)
    80000278:	9d1d                	subw	a0,a0,a5
}
    8000027a:	6422                	ld	s0,8(sp)
    8000027c:	0141                	addi	sp,sp,16
    8000027e:	8082                	ret

0000000080000280 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000280:	1141                	addi	sp,sp,-16
    80000282:	e422                	sd	s0,8(sp)
    80000284:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000286:	87aa                	mv	a5,a0
    80000288:	86b2                	mv	a3,a2
    8000028a:	367d                	addiw	a2,a2,-1
    8000028c:	02d05563          	blez	a3,800002b6 <strncpy+0x36>
    80000290:	0785                	addi	a5,a5,1
    80000292:	0005c703          	lbu	a4,0(a1)
    80000296:	fee78fa3          	sb	a4,-1(a5)
    8000029a:	0585                	addi	a1,a1,1
    8000029c:	f775                	bnez	a4,80000288 <strncpy+0x8>
    ;
  while(n-- > 0)
    8000029e:	873e                	mv	a4,a5
    800002a0:	9fb5                	addw	a5,a5,a3
    800002a2:	37fd                	addiw	a5,a5,-1
    800002a4:	00c05963          	blez	a2,800002b6 <strncpy+0x36>
    *s++ = 0;
    800002a8:	0705                	addi	a4,a4,1
    800002aa:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    800002ae:	40e786bb          	subw	a3,a5,a4
    800002b2:	fed04be3          	bgtz	a3,800002a8 <strncpy+0x28>
  return os;
}
    800002b6:	6422                	ld	s0,8(sp)
    800002b8:	0141                	addi	sp,sp,16
    800002ba:	8082                	ret

00000000800002bc <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    800002bc:	1141                	addi	sp,sp,-16
    800002be:	e422                	sd	s0,8(sp)
    800002c0:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    800002c2:	02c05363          	blez	a2,800002e8 <safestrcpy+0x2c>
    800002c6:	fff6069b          	addiw	a3,a2,-1
    800002ca:	1682                	slli	a3,a3,0x20
    800002cc:	9281                	srli	a3,a3,0x20
    800002ce:	96ae                	add	a3,a3,a1
    800002d0:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    800002d2:	00d58963          	beq	a1,a3,800002e4 <safestrcpy+0x28>
    800002d6:	0585                	addi	a1,a1,1
    800002d8:	0785                	addi	a5,a5,1
    800002da:	fff5c703          	lbu	a4,-1(a1)
    800002de:	fee78fa3          	sb	a4,-1(a5)
    800002e2:	fb65                	bnez	a4,800002d2 <safestrcpy+0x16>
    ;
  *s = 0;
    800002e4:	00078023          	sb	zero,0(a5)
  return os;
}
    800002e8:	6422                	ld	s0,8(sp)
    800002ea:	0141                	addi	sp,sp,16
    800002ec:	8082                	ret

00000000800002ee <strlen>:

int
strlen(const char *s)
{
    800002ee:	1141                	addi	sp,sp,-16
    800002f0:	e422                	sd	s0,8(sp)
    800002f2:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    800002f4:	00054783          	lbu	a5,0(a0)
    800002f8:	cf91                	beqz	a5,80000314 <strlen+0x26>
    800002fa:	0505                	addi	a0,a0,1
    800002fc:	87aa                	mv	a5,a0
    800002fe:	86be                	mv	a3,a5
    80000300:	0785                	addi	a5,a5,1
    80000302:	fff7c703          	lbu	a4,-1(a5)
    80000306:	ff65                	bnez	a4,800002fe <strlen+0x10>
    80000308:	40a6853b          	subw	a0,a3,a0
    8000030c:	2505                	addiw	a0,a0,1
    ;
  return n;
}
    8000030e:	6422                	ld	s0,8(sp)
    80000310:	0141                	addi	sp,sp,16
    80000312:	8082                	ret
  for(n = 0; s[n]; n++)
    80000314:	4501                	li	a0,0
    80000316:	bfe5                	j	8000030e <strlen+0x20>

0000000080000318 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000318:	1141                	addi	sp,sp,-16
    8000031a:	e406                	sd	ra,8(sp)
    8000031c:	e022                	sd	s0,0(sp)
    8000031e:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000320:	00001097          	auipc	ra,0x1
    80000324:	bba080e7          	jalr	-1094(ra) # 80000eda <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000328:	0000e717          	auipc	a4,0xe
    8000032c:	af870713          	addi	a4,a4,-1288 # 8000de20 <started>
  if(cpuid() == 0){
    80000330:	c139                	beqz	a0,80000376 <main+0x5e>
    while(started == 0)
    80000332:	431c                	lw	a5,0(a4)
    80000334:	2781                	sext.w	a5,a5
    80000336:	dff5                	beqz	a5,80000332 <main+0x1a>
      ;
    __sync_synchronize();
    80000338:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    8000033c:	00001097          	auipc	ra,0x1
    80000340:	b9e080e7          	jalr	-1122(ra) # 80000eda <cpuid>
    80000344:	85aa                	mv	a1,a0
    80000346:	00008517          	auipc	a0,0x8
    8000034a:	cf250513          	addi	a0,a0,-782 # 80008038 <etext+0x38>
    8000034e:	00006097          	auipc	ra,0x6
    80000352:	c90080e7          	jalr	-880(ra) # 80005fde <printf>
    kvminithart();    // turn on paging
    80000356:	00000097          	auipc	ra,0x0
    8000035a:	0d8080e7          	jalr	216(ra) # 8000042e <kvminithart>
    trapinithart();   // install kernel trap vector
    8000035e:	00002097          	auipc	ra,0x2
    80000362:	89e080e7          	jalr	-1890(ra) # 80001bfc <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000366:	00005097          	auipc	ra,0x5
    8000036a:	ffe080e7          	jalr	-2(ra) # 80005364 <plicinithart>
  }

  scheduler();        
    8000036e:	00001097          	auipc	ra,0x1
    80000372:	0e6080e7          	jalr	230(ra) # 80001454 <scheduler>
    consoleinit();
    80000376:	00006097          	auipc	ra,0x6
    8000037a:	a5c080e7          	jalr	-1444(ra) # 80005dd2 <consoleinit>
    printfinit();
    8000037e:	00006097          	auipc	ra,0x6
    80000382:	e68080e7          	jalr	-408(ra) # 800061e6 <printfinit>
    printf("\n");
    80000386:	00008517          	auipc	a0,0x8
    8000038a:	c9250513          	addi	a0,a0,-878 # 80008018 <etext+0x18>
    8000038e:	00006097          	auipc	ra,0x6
    80000392:	c50080e7          	jalr	-944(ra) # 80005fde <printf>
    printf("xv6 kernel is booting\n");
    80000396:	00008517          	auipc	a0,0x8
    8000039a:	c8a50513          	addi	a0,a0,-886 # 80008020 <etext+0x20>
    8000039e:	00006097          	auipc	ra,0x6
    800003a2:	c40080e7          	jalr	-960(ra) # 80005fde <printf>
    printf("\n");
    800003a6:	00008517          	auipc	a0,0x8
    800003aa:	c7250513          	addi	a0,a0,-910 # 80008018 <etext+0x18>
    800003ae:	00006097          	auipc	ra,0x6
    800003b2:	c30080e7          	jalr	-976(ra) # 80005fde <printf>
    kinit();         // physical page allocator
    800003b6:	00000097          	auipc	ra,0x0
    800003ba:	d28080e7          	jalr	-728(ra) # 800000de <kinit>
    kvminit();       // create kernel page table
    800003be:	00000097          	auipc	ra,0x0
    800003c2:	34a080e7          	jalr	842(ra) # 80000708 <kvminit>
    kvminithart();   // turn on paging
    800003c6:	00000097          	auipc	ra,0x0
    800003ca:	068080e7          	jalr	104(ra) # 8000042e <kvminithart>
    procinit();      // process table
    800003ce:	00001097          	auipc	ra,0x1
    800003d2:	a4a080e7          	jalr	-1462(ra) # 80000e18 <procinit>
    trapinit();      // trap vectors
    800003d6:	00001097          	auipc	ra,0x1
    800003da:	7fe080e7          	jalr	2046(ra) # 80001bd4 <trapinit>
    trapinithart();  // install kernel trap vector
    800003de:	00002097          	auipc	ra,0x2
    800003e2:	81e080e7          	jalr	-2018(ra) # 80001bfc <trapinithart>
    plicinit();      // set up interrupt controller
    800003e6:	00005097          	auipc	ra,0x5
    800003ea:	f64080e7          	jalr	-156(ra) # 8000534a <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    800003ee:	00005097          	auipc	ra,0x5
    800003f2:	f76080e7          	jalr	-138(ra) # 80005364 <plicinithart>
    binit();         // buffer cache
    800003f6:	00002097          	auipc	ra,0x2
    800003fa:	036080e7          	jalr	54(ra) # 8000242c <binit>
    iinit();         // inode table
    800003fe:	00002097          	auipc	ra,0x2
    80000402:	6ec080e7          	jalr	1772(ra) # 80002aea <iinit>
    fileinit();      // file table
    80000406:	00003097          	auipc	ra,0x3
    8000040a:	69c080e7          	jalr	1692(ra) # 80003aa2 <fileinit>
    virtio_disk_init(); // emulated hard disk
    8000040e:	00005097          	auipc	ra,0x5
    80000412:	05e080e7          	jalr	94(ra) # 8000546c <virtio_disk_init>
    userinit();      // first user process
    80000416:	00001097          	auipc	ra,0x1
    8000041a:	e1e080e7          	jalr	-482(ra) # 80001234 <userinit>
    __sync_synchronize();
    8000041e:	0330000f          	fence	rw,rw
    started = 1;
    80000422:	4785                	li	a5,1
    80000424:	0000e717          	auipc	a4,0xe
    80000428:	9ef72e23          	sw	a5,-1540(a4) # 8000de20 <started>
    8000042c:	b789                	j	8000036e <main+0x56>

000000008000042e <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    8000042e:	1141                	addi	sp,sp,-16
    80000430:	e422                	sd	s0,8(sp)
    80000432:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000434:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000438:	0000e797          	auipc	a5,0xe
    8000043c:	9f07b783          	ld	a5,-1552(a5) # 8000de28 <kernel_pagetable>
    80000440:	83b1                	srli	a5,a5,0xc
    80000442:	577d                	li	a4,-1
    80000444:	177e                	slli	a4,a4,0x3f
    80000446:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80000448:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    8000044c:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000450:	6422                	ld	s0,8(sp)
    80000452:	0141                	addi	sp,sp,16
    80000454:	8082                	ret

0000000080000456 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000456:	7139                	addi	sp,sp,-64
    80000458:	fc06                	sd	ra,56(sp)
    8000045a:	f822                	sd	s0,48(sp)
    8000045c:	f426                	sd	s1,40(sp)
    8000045e:	f04a                	sd	s2,32(sp)
    80000460:	ec4e                	sd	s3,24(sp)
    80000462:	e852                	sd	s4,16(sp)
    80000464:	e456                	sd	s5,8(sp)
    80000466:	e05a                	sd	s6,0(sp)
    80000468:	0080                	addi	s0,sp,64
    8000046a:	84aa                	mv	s1,a0
    8000046c:	89ae                	mv	s3,a1
    8000046e:	8ab2                	mv	s5,a2
  if(va >= MAXVA)
    80000470:	57fd                	li	a5,-1
    80000472:	83e9                	srli	a5,a5,0x1a
    80000474:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000476:	4b31                	li	s6,12
  if(va >= MAXVA)
    80000478:	04b7f263          	bgeu	a5,a1,800004bc <walk+0x66>
    panic("walk");
    8000047c:	00008517          	auipc	a0,0x8
    80000480:	bd450513          	addi	a0,a0,-1068 # 80008050 <etext+0x50>
    80000484:	00006097          	auipc	ra,0x6
    80000488:	b08080e7          	jalr	-1272(ra) # 80005f8c <panic>
    pte_t *pte = &pagetable[PX(level, va)];
    if(*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    8000048c:	060a8663          	beqz	s5,800004f8 <walk+0xa2>
    80000490:	00000097          	auipc	ra,0x0
    80000494:	c8a080e7          	jalr	-886(ra) # 8000011a <kalloc>
    80000498:	84aa                	mv	s1,a0
    8000049a:	c529                	beqz	a0,800004e4 <walk+0x8e>
        return 0;
      memset(pagetable, 0, PGSIZE);
    8000049c:	6605                	lui	a2,0x1
    8000049e:	4581                	li	a1,0
    800004a0:	00000097          	auipc	ra,0x0
    800004a4:	cda080e7          	jalr	-806(ra) # 8000017a <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    800004a8:	00c4d793          	srli	a5,s1,0xc
    800004ac:	07aa                	slli	a5,a5,0xa
    800004ae:	0017e793          	ori	a5,a5,1
    800004b2:	00f93023          	sd	a5,0(s2)
  for(int level = 2; level > 0; level--) {
    800004b6:	3a5d                	addiw	s4,s4,-9 # ffffffffffffeff7 <end+0xffffffff7ffd7537>
    800004b8:	036a0063          	beq	s4,s6,800004d8 <walk+0x82>
    pte_t *pte = &pagetable[PX(level, va)];
    800004bc:	0149d933          	srl	s2,s3,s4
    800004c0:	1ff97913          	andi	s2,s2,511
    800004c4:	090e                	slli	s2,s2,0x3
    800004c6:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    800004c8:	00093483          	ld	s1,0(s2)
    800004cc:	0014f793          	andi	a5,s1,1
    800004d0:	dfd5                	beqz	a5,8000048c <walk+0x36>
      pagetable = (pagetable_t)PTE2PA(*pte);
    800004d2:	80a9                	srli	s1,s1,0xa
    800004d4:	04b2                	slli	s1,s1,0xc
    800004d6:	b7c5                	j	800004b6 <walk+0x60>
    }
  }
  return &pagetable[PX(0, va)];
    800004d8:	00c9d513          	srli	a0,s3,0xc
    800004dc:	1ff57513          	andi	a0,a0,511
    800004e0:	050e                	slli	a0,a0,0x3
    800004e2:	9526                	add	a0,a0,s1
}
    800004e4:	70e2                	ld	ra,56(sp)
    800004e6:	7442                	ld	s0,48(sp)
    800004e8:	74a2                	ld	s1,40(sp)
    800004ea:	7902                	ld	s2,32(sp)
    800004ec:	69e2                	ld	s3,24(sp)
    800004ee:	6a42                	ld	s4,16(sp)
    800004f0:	6aa2                	ld	s5,8(sp)
    800004f2:	6b02                	ld	s6,0(sp)
    800004f4:	6121                	addi	sp,sp,64
    800004f6:	8082                	ret
        return 0;
    800004f8:	4501                	li	a0,0
    800004fa:	b7ed                	j	800004e4 <walk+0x8e>

00000000800004fc <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    800004fc:	57fd                	li	a5,-1
    800004fe:	83e9                	srli	a5,a5,0x1a
    80000500:	00b7f463          	bgeu	a5,a1,80000508 <walkaddr+0xc>
    return 0;
    80000504:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000506:	8082                	ret
{
    80000508:	1141                	addi	sp,sp,-16
    8000050a:	e406                	sd	ra,8(sp)
    8000050c:	e022                	sd	s0,0(sp)
    8000050e:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000510:	4601                	li	a2,0
    80000512:	00000097          	auipc	ra,0x0
    80000516:	f44080e7          	jalr	-188(ra) # 80000456 <walk>
  if(pte == 0)
    8000051a:	c105                	beqz	a0,8000053a <walkaddr+0x3e>
  if((*pte & PTE_V) == 0)
    8000051c:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    8000051e:	0117f693          	andi	a3,a5,17
    80000522:	4745                	li	a4,17
    return 0;
    80000524:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80000526:	00e68663          	beq	a3,a4,80000532 <walkaddr+0x36>
}
    8000052a:	60a2                	ld	ra,8(sp)
    8000052c:	6402                	ld	s0,0(sp)
    8000052e:	0141                	addi	sp,sp,16
    80000530:	8082                	ret
  pa = PTE2PA(*pte);
    80000532:	83a9                	srli	a5,a5,0xa
    80000534:	00c79513          	slli	a0,a5,0xc
  return pa;
    80000538:	bfcd                	j	8000052a <walkaddr+0x2e>
    return 0;
    8000053a:	4501                	li	a0,0
    8000053c:	b7fd                	j	8000052a <walkaddr+0x2e>

000000008000053e <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    8000053e:	715d                	addi	sp,sp,-80
    80000540:	e486                	sd	ra,72(sp)
    80000542:	e0a2                	sd	s0,64(sp)
    80000544:	fc26                	sd	s1,56(sp)
    80000546:	f84a                	sd	s2,48(sp)
    80000548:	f44e                	sd	s3,40(sp)
    8000054a:	f052                	sd	s4,32(sp)
    8000054c:	ec56                	sd	s5,24(sp)
    8000054e:	e85a                	sd	s6,16(sp)
    80000550:	e45e                	sd	s7,8(sp)
    80000552:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80000554:	03459793          	slli	a5,a1,0x34
    80000558:	e7b9                	bnez	a5,800005a6 <mappages+0x68>
    8000055a:	8aaa                	mv	s5,a0
    8000055c:	8b3a                	mv	s6,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    8000055e:	03461793          	slli	a5,a2,0x34
    80000562:	ebb1                	bnez	a5,800005b6 <mappages+0x78>
    panic("mappages: size not aligned");

  if(size == 0)
    80000564:	c22d                	beqz	a2,800005c6 <mappages+0x88>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    80000566:	77fd                	lui	a5,0xfffff
    80000568:	963e                	add	a2,a2,a5
    8000056a:	00b609b3          	add	s3,a2,a1
  a = va;
    8000056e:	892e                	mv	s2,a1
    80000570:	40b68a33          	sub	s4,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    80000574:	6b85                	lui	s7,0x1
    80000576:	014904b3          	add	s1,s2,s4
    if((pte = walk(pagetable, a, 1)) == 0)
    8000057a:	4605                	li	a2,1
    8000057c:	85ca                	mv	a1,s2
    8000057e:	8556                	mv	a0,s5
    80000580:	00000097          	auipc	ra,0x0
    80000584:	ed6080e7          	jalr	-298(ra) # 80000456 <walk>
    80000588:	cd39                	beqz	a0,800005e6 <mappages+0xa8>
    if(*pte & PTE_V)
    8000058a:	611c                	ld	a5,0(a0)
    8000058c:	8b85                	andi	a5,a5,1
    8000058e:	e7a1                	bnez	a5,800005d6 <mappages+0x98>
    *pte = PA2PTE(pa) | perm | PTE_V;
    80000590:	80b1                	srli	s1,s1,0xc
    80000592:	04aa                	slli	s1,s1,0xa
    80000594:	0164e4b3          	or	s1,s1,s6
    80000598:	0014e493          	ori	s1,s1,1
    8000059c:	e104                	sd	s1,0(a0)
    if(a == last)
    8000059e:	07390063          	beq	s2,s3,800005fe <mappages+0xc0>
    a += PGSIZE;
    800005a2:	995e                	add	s2,s2,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    800005a4:	bfc9                	j	80000576 <mappages+0x38>
    panic("mappages: va not aligned");
    800005a6:	00008517          	auipc	a0,0x8
    800005aa:	ab250513          	addi	a0,a0,-1358 # 80008058 <etext+0x58>
    800005ae:	00006097          	auipc	ra,0x6
    800005b2:	9de080e7          	jalr	-1570(ra) # 80005f8c <panic>
    panic("mappages: size not aligned");
    800005b6:	00008517          	auipc	a0,0x8
    800005ba:	ac250513          	addi	a0,a0,-1342 # 80008078 <etext+0x78>
    800005be:	00006097          	auipc	ra,0x6
    800005c2:	9ce080e7          	jalr	-1586(ra) # 80005f8c <panic>
    panic("mappages: size");
    800005c6:	00008517          	auipc	a0,0x8
    800005ca:	ad250513          	addi	a0,a0,-1326 # 80008098 <etext+0x98>
    800005ce:	00006097          	auipc	ra,0x6
    800005d2:	9be080e7          	jalr	-1602(ra) # 80005f8c <panic>
      panic("mappages: remap");
    800005d6:	00008517          	auipc	a0,0x8
    800005da:	ad250513          	addi	a0,a0,-1326 # 800080a8 <etext+0xa8>
    800005de:	00006097          	auipc	ra,0x6
    800005e2:	9ae080e7          	jalr	-1618(ra) # 80005f8c <panic>
      return -1;
    800005e6:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    800005e8:	60a6                	ld	ra,72(sp)
    800005ea:	6406                	ld	s0,64(sp)
    800005ec:	74e2                	ld	s1,56(sp)
    800005ee:	7942                	ld	s2,48(sp)
    800005f0:	79a2                	ld	s3,40(sp)
    800005f2:	7a02                	ld	s4,32(sp)
    800005f4:	6ae2                	ld	s5,24(sp)
    800005f6:	6b42                	ld	s6,16(sp)
    800005f8:	6ba2                	ld	s7,8(sp)
    800005fa:	6161                	addi	sp,sp,80
    800005fc:	8082                	ret
  return 0;
    800005fe:	4501                	li	a0,0
    80000600:	b7e5                	j	800005e8 <mappages+0xaa>

0000000080000602 <kvmmap>:
{
    80000602:	1141                	addi	sp,sp,-16
    80000604:	e406                	sd	ra,8(sp)
    80000606:	e022                	sd	s0,0(sp)
    80000608:	0800                	addi	s0,sp,16
    8000060a:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    8000060c:	86b2                	mv	a3,a2
    8000060e:	863e                	mv	a2,a5
    80000610:	00000097          	auipc	ra,0x0
    80000614:	f2e080e7          	jalr	-210(ra) # 8000053e <mappages>
    80000618:	e509                	bnez	a0,80000622 <kvmmap+0x20>
}
    8000061a:	60a2                	ld	ra,8(sp)
    8000061c:	6402                	ld	s0,0(sp)
    8000061e:	0141                	addi	sp,sp,16
    80000620:	8082                	ret
    panic("kvmmap");
    80000622:	00008517          	auipc	a0,0x8
    80000626:	a9650513          	addi	a0,a0,-1386 # 800080b8 <etext+0xb8>
    8000062a:	00006097          	auipc	ra,0x6
    8000062e:	962080e7          	jalr	-1694(ra) # 80005f8c <panic>

0000000080000632 <kvmmake>:
{
    80000632:	1101                	addi	sp,sp,-32
    80000634:	ec06                	sd	ra,24(sp)
    80000636:	e822                	sd	s0,16(sp)
    80000638:	e426                	sd	s1,8(sp)
    8000063a:	e04a                	sd	s2,0(sp)
    8000063c:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    8000063e:	00000097          	auipc	ra,0x0
    80000642:	adc080e7          	jalr	-1316(ra) # 8000011a <kalloc>
    80000646:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80000648:	6605                	lui	a2,0x1
    8000064a:	4581                	li	a1,0
    8000064c:	00000097          	auipc	ra,0x0
    80000650:	b2e080e7          	jalr	-1234(ra) # 8000017a <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    80000654:	4719                	li	a4,6
    80000656:	6685                	lui	a3,0x1
    80000658:	10000637          	lui	a2,0x10000
    8000065c:	100005b7          	lui	a1,0x10000
    80000660:	8526                	mv	a0,s1
    80000662:	00000097          	auipc	ra,0x0
    80000666:	fa0080e7          	jalr	-96(ra) # 80000602 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    8000066a:	4719                	li	a4,6
    8000066c:	6685                	lui	a3,0x1
    8000066e:	10001637          	lui	a2,0x10001
    80000672:	100015b7          	lui	a1,0x10001
    80000676:	8526                	mv	a0,s1
    80000678:	00000097          	auipc	ra,0x0
    8000067c:	f8a080e7          	jalr	-118(ra) # 80000602 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x400000, PTE_R | PTE_W);
    80000680:	4719                	li	a4,6
    80000682:	004006b7          	lui	a3,0x400
    80000686:	0c000637          	lui	a2,0xc000
    8000068a:	0c0005b7          	lui	a1,0xc000
    8000068e:	8526                	mv	a0,s1
    80000690:	00000097          	auipc	ra,0x0
    80000694:	f72080e7          	jalr	-142(ra) # 80000602 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    80000698:	00008917          	auipc	s2,0x8
    8000069c:	96890913          	addi	s2,s2,-1688 # 80008000 <etext>
    800006a0:	4729                	li	a4,10
    800006a2:	80008697          	auipc	a3,0x80008
    800006a6:	95e68693          	addi	a3,a3,-1698 # 8000 <_entry-0x7fff8000>
    800006aa:	4605                	li	a2,1
    800006ac:	067e                	slli	a2,a2,0x1f
    800006ae:	85b2                	mv	a1,a2
    800006b0:	8526                	mv	a0,s1
    800006b2:	00000097          	auipc	ra,0x0
    800006b6:	f50080e7          	jalr	-176(ra) # 80000602 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    800006ba:	46c5                	li	a3,17
    800006bc:	06ee                	slli	a3,a3,0x1b
    800006be:	4719                	li	a4,6
    800006c0:	412686b3          	sub	a3,a3,s2
    800006c4:	864a                	mv	a2,s2
    800006c6:	85ca                	mv	a1,s2
    800006c8:	8526                	mv	a0,s1
    800006ca:	00000097          	auipc	ra,0x0
    800006ce:	f38080e7          	jalr	-200(ra) # 80000602 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    800006d2:	4729                	li	a4,10
    800006d4:	6685                	lui	a3,0x1
    800006d6:	00007617          	auipc	a2,0x7
    800006da:	92a60613          	addi	a2,a2,-1750 # 80007000 <_trampoline>
    800006de:	040005b7          	lui	a1,0x4000
    800006e2:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800006e4:	05b2                	slli	a1,a1,0xc
    800006e6:	8526                	mv	a0,s1
    800006e8:	00000097          	auipc	ra,0x0
    800006ec:	f1a080e7          	jalr	-230(ra) # 80000602 <kvmmap>
  proc_mapstacks(kpgtbl);
    800006f0:	8526                	mv	a0,s1
    800006f2:	00000097          	auipc	ra,0x0
    800006f6:	682080e7          	jalr	1666(ra) # 80000d74 <proc_mapstacks>
}
    800006fa:	8526                	mv	a0,s1
    800006fc:	60e2                	ld	ra,24(sp)
    800006fe:	6442                	ld	s0,16(sp)
    80000700:	64a2                	ld	s1,8(sp)
    80000702:	6902                	ld	s2,0(sp)
    80000704:	6105                	addi	sp,sp,32
    80000706:	8082                	ret

0000000080000708 <kvminit>:
{
    80000708:	1141                	addi	sp,sp,-16
    8000070a:	e406                	sd	ra,8(sp)
    8000070c:	e022                	sd	s0,0(sp)
    8000070e:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    80000710:	00000097          	auipc	ra,0x0
    80000714:	f22080e7          	jalr	-222(ra) # 80000632 <kvmmake>
    80000718:	0000d797          	auipc	a5,0xd
    8000071c:	70a7b823          	sd	a0,1808(a5) # 8000de28 <kernel_pagetable>
}
    80000720:	60a2                	ld	ra,8(sp)
    80000722:	6402                	ld	s0,0(sp)
    80000724:	0141                	addi	sp,sp,16
    80000726:	8082                	ret

0000000080000728 <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    80000728:	715d                	addi	sp,sp,-80
    8000072a:	e486                	sd	ra,72(sp)
    8000072c:	e0a2                	sd	s0,64(sp)
    8000072e:	0880                	addi	s0,sp,80
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80000730:	03459793          	slli	a5,a1,0x34
    80000734:	e39d                	bnez	a5,8000075a <uvmunmap+0x32>
    80000736:	f84a                	sd	s2,48(sp)
    80000738:	f44e                	sd	s3,40(sp)
    8000073a:	f052                	sd	s4,32(sp)
    8000073c:	ec56                	sd	s5,24(sp)
    8000073e:	e85a                	sd	s6,16(sp)
    80000740:	e45e                	sd	s7,8(sp)
    80000742:	8a2a                	mv	s4,a0
    80000744:	892e                	mv	s2,a1
    80000746:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80000748:	0632                	slli	a2,a2,0xc
    8000074a:	00b609b3          	add	s3,a2,a1
    if((pte = walk(pagetable, a, 0)) == 0)
      panic("uvmunmap: walk");
    if((*pte & PTE_V) == 0)
      panic("uvmunmap: not mapped");
    if(PTE_FLAGS(*pte) == PTE_V)
    8000074e:	4b85                	li	s7,1
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80000750:	6b05                	lui	s6,0x1
    80000752:	0935fb63          	bgeu	a1,s3,800007e8 <uvmunmap+0xc0>
    80000756:	fc26                	sd	s1,56(sp)
    80000758:	a8a9                	j	800007b2 <uvmunmap+0x8a>
    8000075a:	fc26                	sd	s1,56(sp)
    8000075c:	f84a                	sd	s2,48(sp)
    8000075e:	f44e                	sd	s3,40(sp)
    80000760:	f052                	sd	s4,32(sp)
    80000762:	ec56                	sd	s5,24(sp)
    80000764:	e85a                	sd	s6,16(sp)
    80000766:	e45e                	sd	s7,8(sp)
    panic("uvmunmap: not aligned");
    80000768:	00008517          	auipc	a0,0x8
    8000076c:	95850513          	addi	a0,a0,-1704 # 800080c0 <etext+0xc0>
    80000770:	00006097          	auipc	ra,0x6
    80000774:	81c080e7          	jalr	-2020(ra) # 80005f8c <panic>
      panic("uvmunmap: walk");
    80000778:	00008517          	auipc	a0,0x8
    8000077c:	96050513          	addi	a0,a0,-1696 # 800080d8 <etext+0xd8>
    80000780:	00006097          	auipc	ra,0x6
    80000784:	80c080e7          	jalr	-2036(ra) # 80005f8c <panic>
      panic("uvmunmap: not mapped");
    80000788:	00008517          	auipc	a0,0x8
    8000078c:	96050513          	addi	a0,a0,-1696 # 800080e8 <etext+0xe8>
    80000790:	00005097          	auipc	ra,0x5
    80000794:	7fc080e7          	jalr	2044(ra) # 80005f8c <panic>
      panic("uvmunmap: not a leaf");
    80000798:	00008517          	auipc	a0,0x8
    8000079c:	96850513          	addi	a0,a0,-1688 # 80008100 <etext+0x100>
    800007a0:	00005097          	auipc	ra,0x5
    800007a4:	7ec080e7          	jalr	2028(ra) # 80005f8c <panic>
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    800007a8:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800007ac:	995a                	add	s2,s2,s6
    800007ae:	03397c63          	bgeu	s2,s3,800007e6 <uvmunmap+0xbe>
    if((pte = walk(pagetable, a, 0)) == 0)
    800007b2:	4601                	li	a2,0
    800007b4:	85ca                	mv	a1,s2
    800007b6:	8552                	mv	a0,s4
    800007b8:	00000097          	auipc	ra,0x0
    800007bc:	c9e080e7          	jalr	-866(ra) # 80000456 <walk>
    800007c0:	84aa                	mv	s1,a0
    800007c2:	d95d                	beqz	a0,80000778 <uvmunmap+0x50>
    if((*pte & PTE_V) == 0)
    800007c4:	6108                	ld	a0,0(a0)
    800007c6:	00157793          	andi	a5,a0,1
    800007ca:	dfdd                	beqz	a5,80000788 <uvmunmap+0x60>
    if(PTE_FLAGS(*pte) == PTE_V)
    800007cc:	3ff57793          	andi	a5,a0,1023
    800007d0:	fd7784e3          	beq	a5,s7,80000798 <uvmunmap+0x70>
    if(do_free){
    800007d4:	fc0a8ae3          	beqz	s5,800007a8 <uvmunmap+0x80>
      uint64 pa = PTE2PA(*pte);
    800007d8:	8129                	srli	a0,a0,0xa
      kfree((void*)pa);
    800007da:	0532                	slli	a0,a0,0xc
    800007dc:	00000097          	auipc	ra,0x0
    800007e0:	840080e7          	jalr	-1984(ra) # 8000001c <kfree>
    800007e4:	b7d1                	j	800007a8 <uvmunmap+0x80>
    800007e6:	74e2                	ld	s1,56(sp)
    800007e8:	7942                	ld	s2,48(sp)
    800007ea:	79a2                	ld	s3,40(sp)
    800007ec:	7a02                	ld	s4,32(sp)
    800007ee:	6ae2                	ld	s5,24(sp)
    800007f0:	6b42                	ld	s6,16(sp)
    800007f2:	6ba2                	ld	s7,8(sp)
  }
}
    800007f4:	60a6                	ld	ra,72(sp)
    800007f6:	6406                	ld	s0,64(sp)
    800007f8:	6161                	addi	sp,sp,80
    800007fa:	8082                	ret

00000000800007fc <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    800007fc:	1101                	addi	sp,sp,-32
    800007fe:	ec06                	sd	ra,24(sp)
    80000800:	e822                	sd	s0,16(sp)
    80000802:	e426                	sd	s1,8(sp)
    80000804:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    80000806:	00000097          	auipc	ra,0x0
    8000080a:	914080e7          	jalr	-1772(ra) # 8000011a <kalloc>
    8000080e:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80000810:	c519                	beqz	a0,8000081e <uvmcreate+0x22>
    return 0;
  memset(pagetable, 0, PGSIZE);
    80000812:	6605                	lui	a2,0x1
    80000814:	4581                	li	a1,0
    80000816:	00000097          	auipc	ra,0x0
    8000081a:	964080e7          	jalr	-1692(ra) # 8000017a <memset>
  return pagetable;
}
    8000081e:	8526                	mv	a0,s1
    80000820:	60e2                	ld	ra,24(sp)
    80000822:	6442                	ld	s0,16(sp)
    80000824:	64a2                	ld	s1,8(sp)
    80000826:	6105                	addi	sp,sp,32
    80000828:	8082                	ret

000000008000082a <uvmfirst>:
// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvmfirst(pagetable_t pagetable, uchar *src, uint sz)
{
    8000082a:	7179                	addi	sp,sp,-48
    8000082c:	f406                	sd	ra,40(sp)
    8000082e:	f022                	sd	s0,32(sp)
    80000830:	ec26                	sd	s1,24(sp)
    80000832:	e84a                	sd	s2,16(sp)
    80000834:	e44e                	sd	s3,8(sp)
    80000836:	e052                	sd	s4,0(sp)
    80000838:	1800                	addi	s0,sp,48
  char *mem;

  if(sz >= PGSIZE)
    8000083a:	6785                	lui	a5,0x1
    8000083c:	04f67863          	bgeu	a2,a5,8000088c <uvmfirst+0x62>
    80000840:	8a2a                	mv	s4,a0
    80000842:	89ae                	mv	s3,a1
    80000844:	84b2                	mv	s1,a2
    panic("uvmfirst: more than a page");
  mem = kalloc();
    80000846:	00000097          	auipc	ra,0x0
    8000084a:	8d4080e7          	jalr	-1836(ra) # 8000011a <kalloc>
    8000084e:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    80000850:	6605                	lui	a2,0x1
    80000852:	4581                	li	a1,0
    80000854:	00000097          	auipc	ra,0x0
    80000858:	926080e7          	jalr	-1754(ra) # 8000017a <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    8000085c:	4779                	li	a4,30
    8000085e:	86ca                	mv	a3,s2
    80000860:	6605                	lui	a2,0x1
    80000862:	4581                	li	a1,0
    80000864:	8552                	mv	a0,s4
    80000866:	00000097          	auipc	ra,0x0
    8000086a:	cd8080e7          	jalr	-808(ra) # 8000053e <mappages>
  memmove(mem, src, sz);
    8000086e:	8626                	mv	a2,s1
    80000870:	85ce                	mv	a1,s3
    80000872:	854a                	mv	a0,s2
    80000874:	00000097          	auipc	ra,0x0
    80000878:	962080e7          	jalr	-1694(ra) # 800001d6 <memmove>
}
    8000087c:	70a2                	ld	ra,40(sp)
    8000087e:	7402                	ld	s0,32(sp)
    80000880:	64e2                	ld	s1,24(sp)
    80000882:	6942                	ld	s2,16(sp)
    80000884:	69a2                	ld	s3,8(sp)
    80000886:	6a02                	ld	s4,0(sp)
    80000888:	6145                	addi	sp,sp,48
    8000088a:	8082                	ret
    panic("uvmfirst: more than a page");
    8000088c:	00008517          	auipc	a0,0x8
    80000890:	88c50513          	addi	a0,a0,-1908 # 80008118 <etext+0x118>
    80000894:	00005097          	auipc	ra,0x5
    80000898:	6f8080e7          	jalr	1784(ra) # 80005f8c <panic>

000000008000089c <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    8000089c:	1101                	addi	sp,sp,-32
    8000089e:	ec06                	sd	ra,24(sp)
    800008a0:	e822                	sd	s0,16(sp)
    800008a2:	e426                	sd	s1,8(sp)
    800008a4:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    800008a6:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    800008a8:	00b67d63          	bgeu	a2,a1,800008c2 <uvmdealloc+0x26>
    800008ac:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    800008ae:	6785                	lui	a5,0x1
    800008b0:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800008b2:	00f60733          	add	a4,a2,a5
    800008b6:	76fd                	lui	a3,0xfffff
    800008b8:	8f75                	and	a4,a4,a3
    800008ba:	97ae                	add	a5,a5,a1
    800008bc:	8ff5                	and	a5,a5,a3
    800008be:	00f76863          	bltu	a4,a5,800008ce <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    800008c2:	8526                	mv	a0,s1
    800008c4:	60e2                	ld	ra,24(sp)
    800008c6:	6442                	ld	s0,16(sp)
    800008c8:	64a2                	ld	s1,8(sp)
    800008ca:	6105                	addi	sp,sp,32
    800008cc:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800008ce:	8f99                	sub	a5,a5,a4
    800008d0:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800008d2:	4685                	li	a3,1
    800008d4:	0007861b          	sext.w	a2,a5
    800008d8:	85ba                	mv	a1,a4
    800008da:	00000097          	auipc	ra,0x0
    800008de:	e4e080e7          	jalr	-434(ra) # 80000728 <uvmunmap>
    800008e2:	b7c5                	j	800008c2 <uvmdealloc+0x26>

00000000800008e4 <uvmalloc>:
  if(newsz < oldsz)
    800008e4:	0ab66b63          	bltu	a2,a1,8000099a <uvmalloc+0xb6>
{
    800008e8:	7139                	addi	sp,sp,-64
    800008ea:	fc06                	sd	ra,56(sp)
    800008ec:	f822                	sd	s0,48(sp)
    800008ee:	ec4e                	sd	s3,24(sp)
    800008f0:	e852                	sd	s4,16(sp)
    800008f2:	e456                	sd	s5,8(sp)
    800008f4:	0080                	addi	s0,sp,64
    800008f6:	8aaa                	mv	s5,a0
    800008f8:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    800008fa:	6785                	lui	a5,0x1
    800008fc:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800008fe:	95be                	add	a1,a1,a5
    80000900:	77fd                	lui	a5,0xfffff
    80000902:	00f5f9b3          	and	s3,a1,a5
  for(a = oldsz; a < newsz; a += PGSIZE){
    80000906:	08c9fc63          	bgeu	s3,a2,8000099e <uvmalloc+0xba>
    8000090a:	f426                	sd	s1,40(sp)
    8000090c:	f04a                	sd	s2,32(sp)
    8000090e:	e05a                	sd	s6,0(sp)
    80000910:	894e                	mv	s2,s3
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80000912:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80000916:	00000097          	auipc	ra,0x0
    8000091a:	804080e7          	jalr	-2044(ra) # 8000011a <kalloc>
    8000091e:	84aa                	mv	s1,a0
    if(mem == 0){
    80000920:	c915                	beqz	a0,80000954 <uvmalloc+0x70>
    memset(mem, 0, PGSIZE);
    80000922:	6605                	lui	a2,0x1
    80000924:	4581                	li	a1,0
    80000926:	00000097          	auipc	ra,0x0
    8000092a:	854080e7          	jalr	-1964(ra) # 8000017a <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    8000092e:	875a                	mv	a4,s6
    80000930:	86a6                	mv	a3,s1
    80000932:	6605                	lui	a2,0x1
    80000934:	85ca                	mv	a1,s2
    80000936:	8556                	mv	a0,s5
    80000938:	00000097          	auipc	ra,0x0
    8000093c:	c06080e7          	jalr	-1018(ra) # 8000053e <mappages>
    80000940:	ed05                	bnez	a0,80000978 <uvmalloc+0x94>
  for(a = oldsz; a < newsz; a += PGSIZE){
    80000942:	6785                	lui	a5,0x1
    80000944:	993e                	add	s2,s2,a5
    80000946:	fd4968e3          	bltu	s2,s4,80000916 <uvmalloc+0x32>
  return newsz;
    8000094a:	8552                	mv	a0,s4
    8000094c:	74a2                	ld	s1,40(sp)
    8000094e:	7902                	ld	s2,32(sp)
    80000950:	6b02                	ld	s6,0(sp)
    80000952:	a821                	j	8000096a <uvmalloc+0x86>
      uvmdealloc(pagetable, a, oldsz);
    80000954:	864e                	mv	a2,s3
    80000956:	85ca                	mv	a1,s2
    80000958:	8556                	mv	a0,s5
    8000095a:	00000097          	auipc	ra,0x0
    8000095e:	f42080e7          	jalr	-190(ra) # 8000089c <uvmdealloc>
      return 0;
    80000962:	4501                	li	a0,0
    80000964:	74a2                	ld	s1,40(sp)
    80000966:	7902                	ld	s2,32(sp)
    80000968:	6b02                	ld	s6,0(sp)
}
    8000096a:	70e2                	ld	ra,56(sp)
    8000096c:	7442                	ld	s0,48(sp)
    8000096e:	69e2                	ld	s3,24(sp)
    80000970:	6a42                	ld	s4,16(sp)
    80000972:	6aa2                	ld	s5,8(sp)
    80000974:	6121                	addi	sp,sp,64
    80000976:	8082                	ret
      kfree(mem);
    80000978:	8526                	mv	a0,s1
    8000097a:	fffff097          	auipc	ra,0xfffff
    8000097e:	6a2080e7          	jalr	1698(ra) # 8000001c <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80000982:	864e                	mv	a2,s3
    80000984:	85ca                	mv	a1,s2
    80000986:	8556                	mv	a0,s5
    80000988:	00000097          	auipc	ra,0x0
    8000098c:	f14080e7          	jalr	-236(ra) # 8000089c <uvmdealloc>
      return 0;
    80000990:	4501                	li	a0,0
    80000992:	74a2                	ld	s1,40(sp)
    80000994:	7902                	ld	s2,32(sp)
    80000996:	6b02                	ld	s6,0(sp)
    80000998:	bfc9                	j	8000096a <uvmalloc+0x86>
    return oldsz;
    8000099a:	852e                	mv	a0,a1
}
    8000099c:	8082                	ret
  return newsz;
    8000099e:	8532                	mv	a0,a2
    800009a0:	b7e9                	j	8000096a <uvmalloc+0x86>

00000000800009a2 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    800009a2:	7179                	addi	sp,sp,-48
    800009a4:	f406                	sd	ra,40(sp)
    800009a6:	f022                	sd	s0,32(sp)
    800009a8:	ec26                	sd	s1,24(sp)
    800009aa:	e84a                	sd	s2,16(sp)
    800009ac:	e44e                	sd	s3,8(sp)
    800009ae:	e052                	sd	s4,0(sp)
    800009b0:	1800                	addi	s0,sp,48
    800009b2:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    800009b4:	84aa                	mv	s1,a0
    800009b6:	6905                	lui	s2,0x1
    800009b8:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800009ba:	4985                	li	s3,1
    800009bc:	a829                	j	800009d6 <freewalk+0x34>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    800009be:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    800009c0:	00c79513          	slli	a0,a5,0xc
    800009c4:	00000097          	auipc	ra,0x0
    800009c8:	fde080e7          	jalr	-34(ra) # 800009a2 <freewalk>
      pagetable[i] = 0;
    800009cc:	0004b023          	sd	zero,0(s1)
  for(int i = 0; i < 512; i++){
    800009d0:	04a1                	addi	s1,s1,8
    800009d2:	03248163          	beq	s1,s2,800009f4 <freewalk+0x52>
    pte_t pte = pagetable[i];
    800009d6:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800009d8:	00f7f713          	andi	a4,a5,15
    800009dc:	ff3701e3          	beq	a4,s3,800009be <freewalk+0x1c>
    } else if(pte & PTE_V){
    800009e0:	8b85                	andi	a5,a5,1
    800009e2:	d7fd                	beqz	a5,800009d0 <freewalk+0x2e>
      panic("freewalk: leaf");
    800009e4:	00007517          	auipc	a0,0x7
    800009e8:	75450513          	addi	a0,a0,1876 # 80008138 <etext+0x138>
    800009ec:	00005097          	auipc	ra,0x5
    800009f0:	5a0080e7          	jalr	1440(ra) # 80005f8c <panic>
    }
  }
  kfree((void*)pagetable);
    800009f4:	8552                	mv	a0,s4
    800009f6:	fffff097          	auipc	ra,0xfffff
    800009fa:	626080e7          	jalr	1574(ra) # 8000001c <kfree>
}
    800009fe:	70a2                	ld	ra,40(sp)
    80000a00:	7402                	ld	s0,32(sp)
    80000a02:	64e2                	ld	s1,24(sp)
    80000a04:	6942                	ld	s2,16(sp)
    80000a06:	69a2                	ld	s3,8(sp)
    80000a08:	6a02                	ld	s4,0(sp)
    80000a0a:	6145                	addi	sp,sp,48
    80000a0c:	8082                	ret

0000000080000a0e <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    80000a0e:	1101                	addi	sp,sp,-32
    80000a10:	ec06                	sd	ra,24(sp)
    80000a12:	e822                	sd	s0,16(sp)
    80000a14:	e426                	sd	s1,8(sp)
    80000a16:	1000                	addi	s0,sp,32
    80000a18:	84aa                	mv	s1,a0
  if(sz > 0)
    80000a1a:	e999                	bnez	a1,80000a30 <uvmfree+0x22>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    80000a1c:	8526                	mv	a0,s1
    80000a1e:	00000097          	auipc	ra,0x0
    80000a22:	f84080e7          	jalr	-124(ra) # 800009a2 <freewalk>
}
    80000a26:	60e2                	ld	ra,24(sp)
    80000a28:	6442                	ld	s0,16(sp)
    80000a2a:	64a2                	ld	s1,8(sp)
    80000a2c:	6105                	addi	sp,sp,32
    80000a2e:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    80000a30:	6785                	lui	a5,0x1
    80000a32:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80000a34:	95be                	add	a1,a1,a5
    80000a36:	4685                	li	a3,1
    80000a38:	00c5d613          	srli	a2,a1,0xc
    80000a3c:	4581                	li	a1,0
    80000a3e:	00000097          	auipc	ra,0x0
    80000a42:	cea080e7          	jalr	-790(ra) # 80000728 <uvmunmap>
    80000a46:	bfd9                	j	80000a1c <uvmfree+0xe>

0000000080000a48 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    80000a48:	c679                	beqz	a2,80000b16 <uvmcopy+0xce>
{
    80000a4a:	715d                	addi	sp,sp,-80
    80000a4c:	e486                	sd	ra,72(sp)
    80000a4e:	e0a2                	sd	s0,64(sp)
    80000a50:	fc26                	sd	s1,56(sp)
    80000a52:	f84a                	sd	s2,48(sp)
    80000a54:	f44e                	sd	s3,40(sp)
    80000a56:	f052                	sd	s4,32(sp)
    80000a58:	ec56                	sd	s5,24(sp)
    80000a5a:	e85a                	sd	s6,16(sp)
    80000a5c:	e45e                	sd	s7,8(sp)
    80000a5e:	0880                	addi	s0,sp,80
    80000a60:	8b2a                	mv	s6,a0
    80000a62:	8aae                	mv	s5,a1
    80000a64:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    80000a66:	4981                	li	s3,0
    if((pte = walk(old, i, 0)) == 0)
    80000a68:	4601                	li	a2,0
    80000a6a:	85ce                	mv	a1,s3
    80000a6c:	855a                	mv	a0,s6
    80000a6e:	00000097          	auipc	ra,0x0
    80000a72:	9e8080e7          	jalr	-1560(ra) # 80000456 <walk>
    80000a76:	c531                	beqz	a0,80000ac2 <uvmcopy+0x7a>
      panic("uvmcopy: pte should exist");
    if((*pte & PTE_V) == 0)
    80000a78:	6118                	ld	a4,0(a0)
    80000a7a:	00177793          	andi	a5,a4,1
    80000a7e:	cbb1                	beqz	a5,80000ad2 <uvmcopy+0x8a>
      panic("uvmcopy: page not present");
    pa = PTE2PA(*pte);
    80000a80:	00a75593          	srli	a1,a4,0xa
    80000a84:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    80000a88:	3ff77493          	andi	s1,a4,1023
    if((mem = kalloc()) == 0)
    80000a8c:	fffff097          	auipc	ra,0xfffff
    80000a90:	68e080e7          	jalr	1678(ra) # 8000011a <kalloc>
    80000a94:	892a                	mv	s2,a0
    80000a96:	c939                	beqz	a0,80000aec <uvmcopy+0xa4>
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    80000a98:	6605                	lui	a2,0x1
    80000a9a:	85de                	mv	a1,s7
    80000a9c:	fffff097          	auipc	ra,0xfffff
    80000aa0:	73a080e7          	jalr	1850(ra) # 800001d6 <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    80000aa4:	8726                	mv	a4,s1
    80000aa6:	86ca                	mv	a3,s2
    80000aa8:	6605                	lui	a2,0x1
    80000aaa:	85ce                	mv	a1,s3
    80000aac:	8556                	mv	a0,s5
    80000aae:	00000097          	auipc	ra,0x0
    80000ab2:	a90080e7          	jalr	-1392(ra) # 8000053e <mappages>
    80000ab6:	e515                	bnez	a0,80000ae2 <uvmcopy+0x9a>
  for(i = 0; i < sz; i += PGSIZE){
    80000ab8:	6785                	lui	a5,0x1
    80000aba:	99be                	add	s3,s3,a5
    80000abc:	fb49e6e3          	bltu	s3,s4,80000a68 <uvmcopy+0x20>
    80000ac0:	a081                	j	80000b00 <uvmcopy+0xb8>
      panic("uvmcopy: pte should exist");
    80000ac2:	00007517          	auipc	a0,0x7
    80000ac6:	68650513          	addi	a0,a0,1670 # 80008148 <etext+0x148>
    80000aca:	00005097          	auipc	ra,0x5
    80000ace:	4c2080e7          	jalr	1218(ra) # 80005f8c <panic>
      panic("uvmcopy: page not present");
    80000ad2:	00007517          	auipc	a0,0x7
    80000ad6:	69650513          	addi	a0,a0,1686 # 80008168 <etext+0x168>
    80000ada:	00005097          	auipc	ra,0x5
    80000ade:	4b2080e7          	jalr	1202(ra) # 80005f8c <panic>
      kfree(mem);
    80000ae2:	854a                	mv	a0,s2
    80000ae4:	fffff097          	auipc	ra,0xfffff
    80000ae8:	538080e7          	jalr	1336(ra) # 8000001c <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    80000aec:	4685                	li	a3,1
    80000aee:	00c9d613          	srli	a2,s3,0xc
    80000af2:	4581                	li	a1,0
    80000af4:	8556                	mv	a0,s5
    80000af6:	00000097          	auipc	ra,0x0
    80000afa:	c32080e7          	jalr	-974(ra) # 80000728 <uvmunmap>
  return -1;
    80000afe:	557d                	li	a0,-1
}
    80000b00:	60a6                	ld	ra,72(sp)
    80000b02:	6406                	ld	s0,64(sp)
    80000b04:	74e2                	ld	s1,56(sp)
    80000b06:	7942                	ld	s2,48(sp)
    80000b08:	79a2                	ld	s3,40(sp)
    80000b0a:	7a02                	ld	s4,32(sp)
    80000b0c:	6ae2                	ld	s5,24(sp)
    80000b0e:	6b42                	ld	s6,16(sp)
    80000b10:	6ba2                	ld	s7,8(sp)
    80000b12:	6161                	addi	sp,sp,80
    80000b14:	8082                	ret
  return 0;
    80000b16:	4501                	li	a0,0
}
    80000b18:	8082                	ret

0000000080000b1a <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    80000b1a:	1141                	addi	sp,sp,-16
    80000b1c:	e406                	sd	ra,8(sp)
    80000b1e:	e022                	sd	s0,0(sp)
    80000b20:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    80000b22:	4601                	li	a2,0
    80000b24:	00000097          	auipc	ra,0x0
    80000b28:	932080e7          	jalr	-1742(ra) # 80000456 <walk>
  if(pte == 0)
    80000b2c:	c901                	beqz	a0,80000b3c <uvmclear+0x22>
    panic("uvmclear");
  *pte &= ~PTE_U;
    80000b2e:	611c                	ld	a5,0(a0)
    80000b30:	9bbd                	andi	a5,a5,-17
    80000b32:	e11c                	sd	a5,0(a0)
}
    80000b34:	60a2                	ld	ra,8(sp)
    80000b36:	6402                	ld	s0,0(sp)
    80000b38:	0141                	addi	sp,sp,16
    80000b3a:	8082                	ret
    panic("uvmclear");
    80000b3c:	00007517          	auipc	a0,0x7
    80000b40:	64c50513          	addi	a0,a0,1612 # 80008188 <etext+0x188>
    80000b44:	00005097          	auipc	ra,0x5
    80000b48:	448080e7          	jalr	1096(ra) # 80005f8c <panic>

0000000080000b4c <copyout>:
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;
  pte_t *pte;

  while(len > 0){
    80000b4c:	ced1                	beqz	a3,80000be8 <copyout+0x9c>
{
    80000b4e:	711d                	addi	sp,sp,-96
    80000b50:	ec86                	sd	ra,88(sp)
    80000b52:	e8a2                	sd	s0,80(sp)
    80000b54:	e4a6                	sd	s1,72(sp)
    80000b56:	fc4e                	sd	s3,56(sp)
    80000b58:	f456                	sd	s5,40(sp)
    80000b5a:	f05a                	sd	s6,32(sp)
    80000b5c:	ec5e                	sd	s7,24(sp)
    80000b5e:	1080                	addi	s0,sp,96
    80000b60:	8baa                	mv	s7,a0
    80000b62:	8aae                	mv	s5,a1
    80000b64:	8b32                	mv	s6,a2
    80000b66:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(dstva);
    80000b68:	74fd                	lui	s1,0xfffff
    80000b6a:	8ced                	and	s1,s1,a1
    if(va0 >= MAXVA)
    80000b6c:	57fd                	li	a5,-1
    80000b6e:	83e9                	srli	a5,a5,0x1a
    80000b70:	0697ee63          	bltu	a5,s1,80000bec <copyout+0xa0>
    80000b74:	e0ca                	sd	s2,64(sp)
    80000b76:	f852                	sd	s4,48(sp)
    80000b78:	e862                	sd	s8,16(sp)
    80000b7a:	e466                	sd	s9,8(sp)
    80000b7c:	e06a                	sd	s10,0(sp)
      return -1;
    pte = walk(pagetable, va0, 0);
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    80000b7e:	4cd5                	li	s9,21
    80000b80:	6d05                	lui	s10,0x1
    if(va0 >= MAXVA)
    80000b82:	8c3e                	mv	s8,a5
    80000b84:	a035                	j	80000bb0 <copyout+0x64>
       (*pte & PTE_W) == 0)
      return -1;
    pa0 = PTE2PA(*pte);
    80000b86:	83a9                	srli	a5,a5,0xa
    80000b88:	07b2                	slli	a5,a5,0xc
    n = PGSIZE - (dstva - va0);
    if(n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80000b8a:	409a8533          	sub	a0,s5,s1
    80000b8e:	0009061b          	sext.w	a2,s2
    80000b92:	85da                	mv	a1,s6
    80000b94:	953e                	add	a0,a0,a5
    80000b96:	fffff097          	auipc	ra,0xfffff
    80000b9a:	640080e7          	jalr	1600(ra) # 800001d6 <memmove>

    len -= n;
    80000b9e:	412989b3          	sub	s3,s3,s2
    src += n;
    80000ba2:	9b4a                	add	s6,s6,s2
  while(len > 0){
    80000ba4:	02098b63          	beqz	s3,80000bda <copyout+0x8e>
    if(va0 >= MAXVA)
    80000ba8:	054c6463          	bltu	s8,s4,80000bf0 <copyout+0xa4>
    80000bac:	84d2                	mv	s1,s4
    80000bae:	8ad2                	mv	s5,s4
    pte = walk(pagetable, va0, 0);
    80000bb0:	4601                	li	a2,0
    80000bb2:	85a6                	mv	a1,s1
    80000bb4:	855e                	mv	a0,s7
    80000bb6:	00000097          	auipc	ra,0x0
    80000bba:	8a0080e7          	jalr	-1888(ra) # 80000456 <walk>
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    80000bbe:	c121                	beqz	a0,80000bfe <copyout+0xb2>
    80000bc0:	611c                	ld	a5,0(a0)
    80000bc2:	0157f713          	andi	a4,a5,21
    80000bc6:	05971b63          	bne	a4,s9,80000c1c <copyout+0xd0>
    n = PGSIZE - (dstva - va0);
    80000bca:	01a48a33          	add	s4,s1,s10
    80000bce:	415a0933          	sub	s2,s4,s5
    if(n > len)
    80000bd2:	fb29fae3          	bgeu	s3,s2,80000b86 <copyout+0x3a>
    80000bd6:	894e                	mv	s2,s3
    80000bd8:	b77d                	j	80000b86 <copyout+0x3a>
    dstva = va0 + PGSIZE;
  }
  return 0;
    80000bda:	4501                	li	a0,0
    80000bdc:	6906                	ld	s2,64(sp)
    80000bde:	7a42                	ld	s4,48(sp)
    80000be0:	6c42                	ld	s8,16(sp)
    80000be2:	6ca2                	ld	s9,8(sp)
    80000be4:	6d02                	ld	s10,0(sp)
    80000be6:	a015                	j	80000c0a <copyout+0xbe>
    80000be8:	4501                	li	a0,0
}
    80000bea:	8082                	ret
      return -1;
    80000bec:	557d                	li	a0,-1
    80000bee:	a831                	j	80000c0a <copyout+0xbe>
    80000bf0:	557d                	li	a0,-1
    80000bf2:	6906                	ld	s2,64(sp)
    80000bf4:	7a42                	ld	s4,48(sp)
    80000bf6:	6c42                	ld	s8,16(sp)
    80000bf8:	6ca2                	ld	s9,8(sp)
    80000bfa:	6d02                	ld	s10,0(sp)
    80000bfc:	a039                	j	80000c0a <copyout+0xbe>
      return -1;
    80000bfe:	557d                	li	a0,-1
    80000c00:	6906                	ld	s2,64(sp)
    80000c02:	7a42                	ld	s4,48(sp)
    80000c04:	6c42                	ld	s8,16(sp)
    80000c06:	6ca2                	ld	s9,8(sp)
    80000c08:	6d02                	ld	s10,0(sp)
}
    80000c0a:	60e6                	ld	ra,88(sp)
    80000c0c:	6446                	ld	s0,80(sp)
    80000c0e:	64a6                	ld	s1,72(sp)
    80000c10:	79e2                	ld	s3,56(sp)
    80000c12:	7aa2                	ld	s5,40(sp)
    80000c14:	7b02                	ld	s6,32(sp)
    80000c16:	6be2                	ld	s7,24(sp)
    80000c18:	6125                	addi	sp,sp,96
    80000c1a:	8082                	ret
      return -1;
    80000c1c:	557d                	li	a0,-1
    80000c1e:	6906                	ld	s2,64(sp)
    80000c20:	7a42                	ld	s4,48(sp)
    80000c22:	6c42                	ld	s8,16(sp)
    80000c24:	6ca2                	ld	s9,8(sp)
    80000c26:	6d02                	ld	s10,0(sp)
    80000c28:	b7cd                	j	80000c0a <copyout+0xbe>

0000000080000c2a <copyin>:
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    80000c2a:	caa5                	beqz	a3,80000c9a <copyin+0x70>
{
    80000c2c:	715d                	addi	sp,sp,-80
    80000c2e:	e486                	sd	ra,72(sp)
    80000c30:	e0a2                	sd	s0,64(sp)
    80000c32:	fc26                	sd	s1,56(sp)
    80000c34:	f84a                	sd	s2,48(sp)
    80000c36:	f44e                	sd	s3,40(sp)
    80000c38:	f052                	sd	s4,32(sp)
    80000c3a:	ec56                	sd	s5,24(sp)
    80000c3c:	e85a                	sd	s6,16(sp)
    80000c3e:	e45e                	sd	s7,8(sp)
    80000c40:	e062                	sd	s8,0(sp)
    80000c42:	0880                	addi	s0,sp,80
    80000c44:	8b2a                	mv	s6,a0
    80000c46:	8a2e                	mv	s4,a1
    80000c48:	8c32                	mv	s8,a2
    80000c4a:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000c4c:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000c4e:	6a85                	lui	s5,0x1
    80000c50:	a01d                	j	80000c76 <copyin+0x4c>
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80000c52:	018505b3          	add	a1,a0,s8
    80000c56:	0004861b          	sext.w	a2,s1
    80000c5a:	412585b3          	sub	a1,a1,s2
    80000c5e:	8552                	mv	a0,s4
    80000c60:	fffff097          	auipc	ra,0xfffff
    80000c64:	576080e7          	jalr	1398(ra) # 800001d6 <memmove>

    len -= n;
    80000c68:	409989b3          	sub	s3,s3,s1
    dst += n;
    80000c6c:	9a26                	add	s4,s4,s1
    srcva = va0 + PGSIZE;
    80000c6e:	01590c33          	add	s8,s2,s5
  while(len > 0){
    80000c72:	02098263          	beqz	s3,80000c96 <copyin+0x6c>
    va0 = PGROUNDDOWN(srcva);
    80000c76:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    80000c7a:	85ca                	mv	a1,s2
    80000c7c:	855a                	mv	a0,s6
    80000c7e:	00000097          	auipc	ra,0x0
    80000c82:	87e080e7          	jalr	-1922(ra) # 800004fc <walkaddr>
    if(pa0 == 0)
    80000c86:	cd01                	beqz	a0,80000c9e <copyin+0x74>
    n = PGSIZE - (srcva - va0);
    80000c88:	418904b3          	sub	s1,s2,s8
    80000c8c:	94d6                	add	s1,s1,s5
    if(n > len)
    80000c8e:	fc99f2e3          	bgeu	s3,s1,80000c52 <copyin+0x28>
    80000c92:	84ce                	mv	s1,s3
    80000c94:	bf7d                	j	80000c52 <copyin+0x28>
  }
  return 0;
    80000c96:	4501                	li	a0,0
    80000c98:	a021                	j	80000ca0 <copyin+0x76>
    80000c9a:	4501                	li	a0,0
}
    80000c9c:	8082                	ret
      return -1;
    80000c9e:	557d                	li	a0,-1
}
    80000ca0:	60a6                	ld	ra,72(sp)
    80000ca2:	6406                	ld	s0,64(sp)
    80000ca4:	74e2                	ld	s1,56(sp)
    80000ca6:	7942                	ld	s2,48(sp)
    80000ca8:	79a2                	ld	s3,40(sp)
    80000caa:	7a02                	ld	s4,32(sp)
    80000cac:	6ae2                	ld	s5,24(sp)
    80000cae:	6b42                	ld	s6,16(sp)
    80000cb0:	6ba2                	ld	s7,8(sp)
    80000cb2:	6c02                	ld	s8,0(sp)
    80000cb4:	6161                	addi	sp,sp,80
    80000cb6:	8082                	ret

0000000080000cb8 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    80000cb8:	cacd                	beqz	a3,80000d6a <copyinstr+0xb2>
{
    80000cba:	715d                	addi	sp,sp,-80
    80000cbc:	e486                	sd	ra,72(sp)
    80000cbe:	e0a2                	sd	s0,64(sp)
    80000cc0:	fc26                	sd	s1,56(sp)
    80000cc2:	f84a                	sd	s2,48(sp)
    80000cc4:	f44e                	sd	s3,40(sp)
    80000cc6:	f052                	sd	s4,32(sp)
    80000cc8:	ec56                	sd	s5,24(sp)
    80000cca:	e85a                	sd	s6,16(sp)
    80000ccc:	e45e                	sd	s7,8(sp)
    80000cce:	0880                	addi	s0,sp,80
    80000cd0:	8a2a                	mv	s4,a0
    80000cd2:	8b2e                	mv	s6,a1
    80000cd4:	8bb2                	mv	s7,a2
    80000cd6:	8936                	mv	s2,a3
    va0 = PGROUNDDOWN(srcva);
    80000cd8:	7afd                	lui	s5,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000cda:	6985                	lui	s3,0x1
    80000cdc:	a825                	j	80000d14 <copyinstr+0x5c>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    80000cde:	00078023          	sb	zero,0(a5) # 1000 <_entry-0x7ffff000>
    80000ce2:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80000ce4:	37fd                	addiw	a5,a5,-1
    80000ce6:	0007851b          	sext.w	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    80000cea:	60a6                	ld	ra,72(sp)
    80000cec:	6406                	ld	s0,64(sp)
    80000cee:	74e2                	ld	s1,56(sp)
    80000cf0:	7942                	ld	s2,48(sp)
    80000cf2:	79a2                	ld	s3,40(sp)
    80000cf4:	7a02                	ld	s4,32(sp)
    80000cf6:	6ae2                	ld	s5,24(sp)
    80000cf8:	6b42                	ld	s6,16(sp)
    80000cfa:	6ba2                	ld	s7,8(sp)
    80000cfc:	6161                	addi	sp,sp,80
    80000cfe:	8082                	ret
    80000d00:	fff90713          	addi	a4,s2,-1 # fff <_entry-0x7ffff001>
    80000d04:	9742                	add	a4,a4,a6
      --max;
    80000d06:	40b70933          	sub	s2,a4,a1
    srcva = va0 + PGSIZE;
    80000d0a:	01348bb3          	add	s7,s1,s3
  while(got_null == 0 && max > 0){
    80000d0e:	04e58663          	beq	a1,a4,80000d5a <copyinstr+0xa2>
{
    80000d12:	8b3e                	mv	s6,a5
    va0 = PGROUNDDOWN(srcva);
    80000d14:	015bf4b3          	and	s1,s7,s5
    pa0 = walkaddr(pagetable, va0);
    80000d18:	85a6                	mv	a1,s1
    80000d1a:	8552                	mv	a0,s4
    80000d1c:	fffff097          	auipc	ra,0xfffff
    80000d20:	7e0080e7          	jalr	2016(ra) # 800004fc <walkaddr>
    if(pa0 == 0)
    80000d24:	cd0d                	beqz	a0,80000d5e <copyinstr+0xa6>
    n = PGSIZE - (srcva - va0);
    80000d26:	417486b3          	sub	a3,s1,s7
    80000d2a:	96ce                	add	a3,a3,s3
    if(n > max)
    80000d2c:	00d97363          	bgeu	s2,a3,80000d32 <copyinstr+0x7a>
    80000d30:	86ca                	mv	a3,s2
    char *p = (char *) (pa0 + (srcva - va0));
    80000d32:	955e                	add	a0,a0,s7
    80000d34:	8d05                	sub	a0,a0,s1
    while(n > 0){
    80000d36:	c695                	beqz	a3,80000d62 <copyinstr+0xaa>
    80000d38:	87da                	mv	a5,s6
    80000d3a:	885a                	mv	a6,s6
      if(*p == '\0'){
    80000d3c:	41650633          	sub	a2,a0,s6
    while(n > 0){
    80000d40:	96da                	add	a3,a3,s6
    80000d42:	85be                	mv	a1,a5
      if(*p == '\0'){
    80000d44:	00f60733          	add	a4,a2,a5
    80000d48:	00074703          	lbu	a4,0(a4)
    80000d4c:	db49                	beqz	a4,80000cde <copyinstr+0x26>
        *dst = *p;
    80000d4e:	00e78023          	sb	a4,0(a5)
      dst++;
    80000d52:	0785                	addi	a5,a5,1
    while(n > 0){
    80000d54:	fed797e3          	bne	a5,a3,80000d42 <copyinstr+0x8a>
    80000d58:	b765                	j	80000d00 <copyinstr+0x48>
    80000d5a:	4781                	li	a5,0
    80000d5c:	b761                	j	80000ce4 <copyinstr+0x2c>
      return -1;
    80000d5e:	557d                	li	a0,-1
    80000d60:	b769                	j	80000cea <copyinstr+0x32>
    srcva = va0 + PGSIZE;
    80000d62:	6b85                	lui	s7,0x1
    80000d64:	9ba6                	add	s7,s7,s1
    80000d66:	87da                	mv	a5,s6
    80000d68:	b76d                	j	80000d12 <copyinstr+0x5a>
  int got_null = 0;
    80000d6a:	4781                	li	a5,0
  if(got_null){
    80000d6c:	37fd                	addiw	a5,a5,-1
    80000d6e:	0007851b          	sext.w	a0,a5
}
    80000d72:	8082                	ret

0000000080000d74 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80000d74:	7139                	addi	sp,sp,-64
    80000d76:	fc06                	sd	ra,56(sp)
    80000d78:	f822                	sd	s0,48(sp)
    80000d7a:	f426                	sd	s1,40(sp)
    80000d7c:	f04a                	sd	s2,32(sp)
    80000d7e:	ec4e                	sd	s3,24(sp)
    80000d80:	e852                	sd	s4,16(sp)
    80000d82:	e456                	sd	s5,8(sp)
    80000d84:	e05a                	sd	s6,0(sp)
    80000d86:	0080                	addi	s0,sp,64
    80000d88:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80000d8a:	0000d497          	auipc	s1,0xd
    80000d8e:	51648493          	addi	s1,s1,1302 # 8000e2a0 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    80000d92:	8b26                	mv	s6,s1
    80000d94:	03eb2937          	lui	s2,0x3eb2
    80000d98:	a1f90913          	addi	s2,s2,-1505 # 3eb1a1f <_entry-0x7c14e5e1>
    80000d9c:	0932                	slli	s2,s2,0xc
    80000d9e:	58d90913          	addi	s2,s2,1421
    80000da2:	0932                	slli	s2,s2,0xc
    80000da4:	0fb90913          	addi	s2,s2,251
    80000da8:	0936                	slli	s2,s2,0xd
    80000daa:	8d190913          	addi	s2,s2,-1839
    80000dae:	040009b7          	lui	s3,0x4000
    80000db2:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80000db4:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80000db6:	00013a97          	auipc	s5,0x13
    80000dba:	6eaa8a93          	addi	s5,s5,1770 # 800144a0 <tickslock>
    char *pa = kalloc();
    80000dbe:	fffff097          	auipc	ra,0xfffff
    80000dc2:	35c080e7          	jalr	860(ra) # 8000011a <kalloc>
    80000dc6:	862a                	mv	a2,a0
    if(pa == 0)
    80000dc8:	c121                	beqz	a0,80000e08 <proc_mapstacks+0x94>
    uint64 va = KSTACK((int) (p - proc));
    80000dca:	416485b3          	sub	a1,s1,s6
    80000dce:	858d                	srai	a1,a1,0x3
    80000dd0:	032585b3          	mul	a1,a1,s2
    80000dd4:	2585                	addiw	a1,a1,1
    80000dd6:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000dda:	4719                	li	a4,6
    80000ddc:	6685                	lui	a3,0x1
    80000dde:	40b985b3          	sub	a1,s3,a1
    80000de2:	8552                	mv	a0,s4
    80000de4:	00000097          	auipc	ra,0x0
    80000de8:	81e080e7          	jalr	-2018(ra) # 80000602 <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000dec:	18848493          	addi	s1,s1,392
    80000df0:	fd5497e3          	bne	s1,s5,80000dbe <proc_mapstacks+0x4a>
  }
}
    80000df4:	70e2                	ld	ra,56(sp)
    80000df6:	7442                	ld	s0,48(sp)
    80000df8:	74a2                	ld	s1,40(sp)
    80000dfa:	7902                	ld	s2,32(sp)
    80000dfc:	69e2                	ld	s3,24(sp)
    80000dfe:	6a42                	ld	s4,16(sp)
    80000e00:	6aa2                	ld	s5,8(sp)
    80000e02:	6b02                	ld	s6,0(sp)
    80000e04:	6121                	addi	sp,sp,64
    80000e06:	8082                	ret
      panic("kalloc");
    80000e08:	00007517          	auipc	a0,0x7
    80000e0c:	39050513          	addi	a0,a0,912 # 80008198 <etext+0x198>
    80000e10:	00005097          	auipc	ra,0x5
    80000e14:	17c080e7          	jalr	380(ra) # 80005f8c <panic>

0000000080000e18 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80000e18:	7139                	addi	sp,sp,-64
    80000e1a:	fc06                	sd	ra,56(sp)
    80000e1c:	f822                	sd	s0,48(sp)
    80000e1e:	f426                	sd	s1,40(sp)
    80000e20:	f04a                	sd	s2,32(sp)
    80000e22:	ec4e                	sd	s3,24(sp)
    80000e24:	e852                	sd	s4,16(sp)
    80000e26:	e456                	sd	s5,8(sp)
    80000e28:	e05a                	sd	s6,0(sp)
    80000e2a:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80000e2c:	00007597          	auipc	a1,0x7
    80000e30:	37458593          	addi	a1,a1,884 # 800081a0 <etext+0x1a0>
    80000e34:	0000d517          	auipc	a0,0xd
    80000e38:	03c50513          	addi	a0,a0,60 # 8000de70 <pid_lock>
    80000e3c:	00005097          	auipc	ra,0x5
    80000e40:	642080e7          	jalr	1602(ra) # 8000647e <initlock>
  initlock(&wait_lock, "wait_lock");
    80000e44:	00007597          	auipc	a1,0x7
    80000e48:	36458593          	addi	a1,a1,868 # 800081a8 <etext+0x1a8>
    80000e4c:	0000d517          	auipc	a0,0xd
    80000e50:	03c50513          	addi	a0,a0,60 # 8000de88 <wait_lock>
    80000e54:	00005097          	auipc	ra,0x5
    80000e58:	62a080e7          	jalr	1578(ra) # 8000647e <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000e5c:	0000d497          	auipc	s1,0xd
    80000e60:	44448493          	addi	s1,s1,1092 # 8000e2a0 <proc>
      initlock(&p->lock, "proc");
    80000e64:	00007b17          	auipc	s6,0x7
    80000e68:	354b0b13          	addi	s6,s6,852 # 800081b8 <etext+0x1b8>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80000e6c:	8aa6                	mv	s5,s1
    80000e6e:	03eb2937          	lui	s2,0x3eb2
    80000e72:	a1f90913          	addi	s2,s2,-1505 # 3eb1a1f <_entry-0x7c14e5e1>
    80000e76:	0932                	slli	s2,s2,0xc
    80000e78:	58d90913          	addi	s2,s2,1421
    80000e7c:	0932                	slli	s2,s2,0xc
    80000e7e:	0fb90913          	addi	s2,s2,251
    80000e82:	0936                	slli	s2,s2,0xd
    80000e84:	8d190913          	addi	s2,s2,-1839
    80000e88:	040009b7          	lui	s3,0x4000
    80000e8c:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80000e8e:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80000e90:	00013a17          	auipc	s4,0x13
    80000e94:	610a0a13          	addi	s4,s4,1552 # 800144a0 <tickslock>
      initlock(&p->lock, "proc");
    80000e98:	85da                	mv	a1,s6
    80000e9a:	8526                	mv	a0,s1
    80000e9c:	00005097          	auipc	ra,0x5
    80000ea0:	5e2080e7          	jalr	1506(ra) # 8000647e <initlock>
      p->state = UNUSED;
    80000ea4:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80000ea8:	415487b3          	sub	a5,s1,s5
    80000eac:	878d                	srai	a5,a5,0x3
    80000eae:	032787b3          	mul	a5,a5,s2
    80000eb2:	2785                	addiw	a5,a5,1
    80000eb4:	00d7979b          	slliw	a5,a5,0xd
    80000eb8:	40f987b3          	sub	a5,s3,a5
    80000ebc:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80000ebe:	18848493          	addi	s1,s1,392
    80000ec2:	fd449be3          	bne	s1,s4,80000e98 <procinit+0x80>
  }
}
    80000ec6:	70e2                	ld	ra,56(sp)
    80000ec8:	7442                	ld	s0,48(sp)
    80000eca:	74a2                	ld	s1,40(sp)
    80000ecc:	7902                	ld	s2,32(sp)
    80000ece:	69e2                	ld	s3,24(sp)
    80000ed0:	6a42                	ld	s4,16(sp)
    80000ed2:	6aa2                	ld	s5,8(sp)
    80000ed4:	6b02                	ld	s6,0(sp)
    80000ed6:	6121                	addi	sp,sp,64
    80000ed8:	8082                	ret

0000000080000eda <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80000eda:	1141                	addi	sp,sp,-16
    80000edc:	e422                	sd	s0,8(sp)
    80000ede:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80000ee0:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80000ee2:	2501                	sext.w	a0,a0
    80000ee4:	6422                	ld	s0,8(sp)
    80000ee6:	0141                	addi	sp,sp,16
    80000ee8:	8082                	ret

0000000080000eea <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80000eea:	1141                	addi	sp,sp,-16
    80000eec:	e422                	sd	s0,8(sp)
    80000eee:	0800                	addi	s0,sp,16
    80000ef0:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80000ef2:	2781                	sext.w	a5,a5
    80000ef4:	079e                	slli	a5,a5,0x7
  return c;
}
    80000ef6:	0000d517          	auipc	a0,0xd
    80000efa:	faa50513          	addi	a0,a0,-86 # 8000dea0 <cpus>
    80000efe:	953e                	add	a0,a0,a5
    80000f00:	6422                	ld	s0,8(sp)
    80000f02:	0141                	addi	sp,sp,16
    80000f04:	8082                	ret

0000000080000f06 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80000f06:	1101                	addi	sp,sp,-32
    80000f08:	ec06                	sd	ra,24(sp)
    80000f0a:	e822                	sd	s0,16(sp)
    80000f0c:	e426                	sd	s1,8(sp)
    80000f0e:	1000                	addi	s0,sp,32
  push_off();
    80000f10:	00005097          	auipc	ra,0x5
    80000f14:	5b2080e7          	jalr	1458(ra) # 800064c2 <push_off>
    80000f18:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80000f1a:	2781                	sext.w	a5,a5
    80000f1c:	079e                	slli	a5,a5,0x7
    80000f1e:	0000d717          	auipc	a4,0xd
    80000f22:	f5270713          	addi	a4,a4,-174 # 8000de70 <pid_lock>
    80000f26:	97ba                	add	a5,a5,a4
    80000f28:	7b84                	ld	s1,48(a5)
  pop_off();
    80000f2a:	00005097          	auipc	ra,0x5
    80000f2e:	638080e7          	jalr	1592(ra) # 80006562 <pop_off>
  return p;
}
    80000f32:	8526                	mv	a0,s1
    80000f34:	60e2                	ld	ra,24(sp)
    80000f36:	6442                	ld	s0,16(sp)
    80000f38:	64a2                	ld	s1,8(sp)
    80000f3a:	6105                	addi	sp,sp,32
    80000f3c:	8082                	ret

0000000080000f3e <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80000f3e:	1141                	addi	sp,sp,-16
    80000f40:	e406                	sd	ra,8(sp)
    80000f42:	e022                	sd	s0,0(sp)
    80000f44:	0800                	addi	s0,sp,16


  //lab4.3注释掉的代码
  // 调度器在 swtch 进入进程前已持有 p->lock，
  // 需要在此释放，否则进程将带着锁进入用户态。
  release(&myproc()->lock);
    80000f46:	00000097          	auipc	ra,0x0
    80000f4a:	fc0080e7          	jalr	-64(ra) # 80000f06 <myproc>
    80000f4e:	00005097          	auipc	ra,0x5
    80000f52:	674080e7          	jalr	1652(ra) # 800065c2 <release>





  if (first) {
    80000f56:	0000d797          	auipc	a5,0xd
    80000f5a:	e5a7a783          	lw	a5,-422(a5) # 8000ddb0 <first.1>
    80000f5e:	eb89                	bnez	a5,80000f70 <forkret+0x32>
    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();
  }

  usertrapret();
    80000f60:	00001097          	auipc	ra,0x1
    80000f64:	cb4080e7          	jalr	-844(ra) # 80001c14 <usertrapret>
}
    80000f68:	60a2                	ld	ra,8(sp)
    80000f6a:	6402                	ld	s0,0(sp)
    80000f6c:	0141                	addi	sp,sp,16
    80000f6e:	8082                	ret
    fsinit(ROOTDEV);
    80000f70:	4505                	li	a0,1
    80000f72:	00002097          	auipc	ra,0x2
    80000f76:	af8080e7          	jalr	-1288(ra) # 80002a6a <fsinit>
    first = 0;
    80000f7a:	0000d797          	auipc	a5,0xd
    80000f7e:	e207ab23          	sw	zero,-458(a5) # 8000ddb0 <first.1>
    __sync_synchronize();
    80000f82:	0330000f          	fence	rw,rw
    80000f86:	bfe9                	j	80000f60 <forkret+0x22>

0000000080000f88 <allocpid>:
{
    80000f88:	1101                	addi	sp,sp,-32
    80000f8a:	ec06                	sd	ra,24(sp)
    80000f8c:	e822                	sd	s0,16(sp)
    80000f8e:	e426                	sd	s1,8(sp)
    80000f90:	e04a                	sd	s2,0(sp)
    80000f92:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80000f94:	0000d917          	auipc	s2,0xd
    80000f98:	edc90913          	addi	s2,s2,-292 # 8000de70 <pid_lock>
    80000f9c:	854a                	mv	a0,s2
    80000f9e:	00005097          	auipc	ra,0x5
    80000fa2:	570080e7          	jalr	1392(ra) # 8000650e <acquire>
  pid = nextpid;
    80000fa6:	0000d797          	auipc	a5,0xd
    80000faa:	e0e78793          	addi	a5,a5,-498 # 8000ddb4 <nextpid>
    80000fae:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80000fb0:	0014871b          	addiw	a4,s1,1
    80000fb4:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80000fb6:	854a                	mv	a0,s2
    80000fb8:	00005097          	auipc	ra,0x5
    80000fbc:	60a080e7          	jalr	1546(ra) # 800065c2 <release>
}
    80000fc0:	8526                	mv	a0,s1
    80000fc2:	60e2                	ld	ra,24(sp)
    80000fc4:	6442                	ld	s0,16(sp)
    80000fc6:	64a2                	ld	s1,8(sp)
    80000fc8:	6902                	ld	s2,0(sp)
    80000fca:	6105                	addi	sp,sp,32
    80000fcc:	8082                	ret

0000000080000fce <proc_pagetable>:
{
    80000fce:	1101                	addi	sp,sp,-32
    80000fd0:	ec06                	sd	ra,24(sp)
    80000fd2:	e822                	sd	s0,16(sp)
    80000fd4:	e426                	sd	s1,8(sp)
    80000fd6:	e04a                	sd	s2,0(sp)
    80000fd8:	1000                	addi	s0,sp,32
    80000fda:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80000fdc:	00000097          	auipc	ra,0x0
    80000fe0:	820080e7          	jalr	-2016(ra) # 800007fc <uvmcreate>
    80000fe4:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80000fe6:	c121                	beqz	a0,80001026 <proc_pagetable+0x58>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80000fe8:	4729                	li	a4,10
    80000fea:	00006697          	auipc	a3,0x6
    80000fee:	01668693          	addi	a3,a3,22 # 80007000 <_trampoline>
    80000ff2:	6605                	lui	a2,0x1
    80000ff4:	040005b7          	lui	a1,0x4000
    80000ff8:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80000ffa:	05b2                	slli	a1,a1,0xc
    80000ffc:	fffff097          	auipc	ra,0xfffff
    80001000:	542080e7          	jalr	1346(ra) # 8000053e <mappages>
    80001004:	02054863          	bltz	a0,80001034 <proc_pagetable+0x66>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001008:	4719                	li	a4,6
    8000100a:	05893683          	ld	a3,88(s2)
    8000100e:	6605                	lui	a2,0x1
    80001010:	020005b7          	lui	a1,0x2000
    80001014:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001016:	05b6                	slli	a1,a1,0xd
    80001018:	8526                	mv	a0,s1
    8000101a:	fffff097          	auipc	ra,0xfffff
    8000101e:	524080e7          	jalr	1316(ra) # 8000053e <mappages>
    80001022:	02054163          	bltz	a0,80001044 <proc_pagetable+0x76>
}
    80001026:	8526                	mv	a0,s1
    80001028:	60e2                	ld	ra,24(sp)
    8000102a:	6442                	ld	s0,16(sp)
    8000102c:	64a2                	ld	s1,8(sp)
    8000102e:	6902                	ld	s2,0(sp)
    80001030:	6105                	addi	sp,sp,32
    80001032:	8082                	ret
    uvmfree(pagetable, 0);
    80001034:	4581                	li	a1,0
    80001036:	8526                	mv	a0,s1
    80001038:	00000097          	auipc	ra,0x0
    8000103c:	9d6080e7          	jalr	-1578(ra) # 80000a0e <uvmfree>
    return 0;
    80001040:	4481                	li	s1,0
    80001042:	b7d5                	j	80001026 <proc_pagetable+0x58>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001044:	4681                	li	a3,0
    80001046:	4605                	li	a2,1
    80001048:	040005b7          	lui	a1,0x4000
    8000104c:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    8000104e:	05b2                	slli	a1,a1,0xc
    80001050:	8526                	mv	a0,s1
    80001052:	fffff097          	auipc	ra,0xfffff
    80001056:	6d6080e7          	jalr	1750(ra) # 80000728 <uvmunmap>
    uvmfree(pagetable, 0);
    8000105a:	4581                	li	a1,0
    8000105c:	8526                	mv	a0,s1
    8000105e:	00000097          	auipc	ra,0x0
    80001062:	9b0080e7          	jalr	-1616(ra) # 80000a0e <uvmfree>
    return 0;
    80001066:	4481                	li	s1,0
    80001068:	bf7d                	j	80001026 <proc_pagetable+0x58>

000000008000106a <proc_freepagetable>:
{
    8000106a:	1101                	addi	sp,sp,-32
    8000106c:	ec06                	sd	ra,24(sp)
    8000106e:	e822                	sd	s0,16(sp)
    80001070:	e426                	sd	s1,8(sp)
    80001072:	e04a                	sd	s2,0(sp)
    80001074:	1000                	addi	s0,sp,32
    80001076:	84aa                	mv	s1,a0
    80001078:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    8000107a:	4681                	li	a3,0
    8000107c:	4605                	li	a2,1
    8000107e:	040005b7          	lui	a1,0x4000
    80001082:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001084:	05b2                	slli	a1,a1,0xc
    80001086:	fffff097          	auipc	ra,0xfffff
    8000108a:	6a2080e7          	jalr	1698(ra) # 80000728 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    8000108e:	4681                	li	a3,0
    80001090:	4605                	li	a2,1
    80001092:	020005b7          	lui	a1,0x2000
    80001096:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001098:	05b6                	slli	a1,a1,0xd
    8000109a:	8526                	mv	a0,s1
    8000109c:	fffff097          	auipc	ra,0xfffff
    800010a0:	68c080e7          	jalr	1676(ra) # 80000728 <uvmunmap>
  uvmfree(pagetable, sz);
    800010a4:	85ca                	mv	a1,s2
    800010a6:	8526                	mv	a0,s1
    800010a8:	00000097          	auipc	ra,0x0
    800010ac:	966080e7          	jalr	-1690(ra) # 80000a0e <uvmfree>
}
    800010b0:	60e2                	ld	ra,24(sp)
    800010b2:	6442                	ld	s0,16(sp)
    800010b4:	64a2                	ld	s1,8(sp)
    800010b6:	6902                	ld	s2,0(sp)
    800010b8:	6105                	addi	sp,sp,32
    800010ba:	8082                	ret

00000000800010bc <freeproc>:
{
    800010bc:	1101                	addi	sp,sp,-32
    800010be:	ec06                	sd	ra,24(sp)
    800010c0:	e822                	sd	s0,16(sp)
    800010c2:	e426                	sd	s1,8(sp)
    800010c4:	1000                	addi	s0,sp,32
    800010c6:	84aa                	mv	s1,a0
  if(p->trapframe)
    800010c8:	6d28                	ld	a0,88(a0)
    800010ca:	c509                	beqz	a0,800010d4 <freeproc+0x18>
    kfree((void*)p->trapframe);
    800010cc:	fffff097          	auipc	ra,0xfffff
    800010d0:	f50080e7          	jalr	-176(ra) # 8000001c <kfree>
  p->trapframe = 0;
    800010d4:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    800010d8:	68a8                	ld	a0,80(s1)
    800010da:	c511                	beqz	a0,800010e6 <freeproc+0x2a>
    proc_freepagetable(p->pagetable, p->sz);
    800010dc:	64ac                	ld	a1,72(s1)
    800010de:	00000097          	auipc	ra,0x0
    800010e2:	f8c080e7          	jalr	-116(ra) # 8000106a <proc_freepagetable>
  p->pagetable = 0;
    800010e6:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    800010ea:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    800010ee:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    800010f2:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    800010f6:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    800010fa:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    800010fe:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001102:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001106:	0004ac23          	sw	zero,24(s1)
  if(p->alarm_trapframe)          
    8000110a:	1804b503          	ld	a0,384(s1)
    8000110e:	c509                	beqz	a0,80001118 <freeproc+0x5c>
    kfree((void*)p->alarm_trapframe);
    80001110:	fffff097          	auipc	ra,0xfffff
    80001114:	f0c080e7          	jalr	-244(ra) # 8000001c <kfree>
  p->alarm_inteval = 0;
    80001118:	1604a423          	sw	zero,360(s1)
  p->alarm_ticks = 0;
    8000111c:	1604a623          	sw	zero,364(s1)
  p->alarm_handler = 0;
    80001120:	1604bc23          	sd	zero,376(s1)
  p->alarm_armed = 0;
    80001124:	1604a823          	sw	zero,368(s1)
}
    80001128:	60e2                	ld	ra,24(sp)
    8000112a:	6442                	ld	s0,16(sp)
    8000112c:	64a2                	ld	s1,8(sp)
    8000112e:	6105                	addi	sp,sp,32
    80001130:	8082                	ret

0000000080001132 <allocproc>:
{
    80001132:	1101                	addi	sp,sp,-32
    80001134:	ec06                	sd	ra,24(sp)
    80001136:	e822                	sd	s0,16(sp)
    80001138:	e426                	sd	s1,8(sp)
    8000113a:	e04a                	sd	s2,0(sp)
    8000113c:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    8000113e:	0000d497          	auipc	s1,0xd
    80001142:	16248493          	addi	s1,s1,354 # 8000e2a0 <proc>
    80001146:	00013917          	auipc	s2,0x13
    8000114a:	35a90913          	addi	s2,s2,858 # 800144a0 <tickslock>
    acquire(&p->lock);
    8000114e:	8526                	mv	a0,s1
    80001150:	00005097          	auipc	ra,0x5
    80001154:	3be080e7          	jalr	958(ra) # 8000650e <acquire>
    if(p->state == UNUSED) {
    80001158:	4c9c                	lw	a5,24(s1)
    8000115a:	cf81                	beqz	a5,80001172 <allocproc+0x40>
      release(&p->lock);
    8000115c:	8526                	mv	a0,s1
    8000115e:	00005097          	auipc	ra,0x5
    80001162:	464080e7          	jalr	1124(ra) # 800065c2 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001166:	18848493          	addi	s1,s1,392
    8000116a:	ff2492e3          	bne	s1,s2,8000114e <allocproc+0x1c>
  return 0;
    8000116e:	4481                	li	s1,0
    80001170:	a0bd                	j	800011de <allocproc+0xac>
  p->pid = allocpid();
    80001172:	00000097          	auipc	ra,0x0
    80001176:	e16080e7          	jalr	-490(ra) # 80000f88 <allocpid>
    8000117a:	d888                	sw	a0,48(s1)
  if((p->alarm_trapframe = (struct trapframe *)kalloc()) == 0){
    8000117c:	fffff097          	auipc	ra,0xfffff
    80001180:	f9e080e7          	jalr	-98(ra) # 8000011a <kalloc>
    80001184:	892a                	mv	s2,a0
    80001186:	18a4b023          	sd	a0,384(s1)
    8000118a:	c12d                	beqz	a0,800011ec <allocproc+0xba>
  p->alarm_inteval = 0;
    8000118c:	1604a423          	sw	zero,360(s1)
  p->alarm_ticks = 0;
    80001190:	1604a623          	sw	zero,364(s1)
  p->alarm_handler = 0;
    80001194:	1604bc23          	sd	zero,376(s1)
  p->alarm_armed = 0;
    80001198:	1604a823          	sw	zero,368(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    8000119c:	fffff097          	auipc	ra,0xfffff
    800011a0:	f7e080e7          	jalr	-130(ra) # 8000011a <kalloc>
    800011a4:	892a                	mv	s2,a0
    800011a6:	eca8                	sd	a0,88(s1)
    800011a8:	cd31                	beqz	a0,80001204 <allocproc+0xd2>
  p->pagetable = proc_pagetable(p);
    800011aa:	8526                	mv	a0,s1
    800011ac:	00000097          	auipc	ra,0x0
    800011b0:	e22080e7          	jalr	-478(ra) # 80000fce <proc_pagetable>
    800011b4:	892a                	mv	s2,a0
    800011b6:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    800011b8:	c135                	beqz	a0,8000121c <allocproc+0xea>
  memset(&p->context, 0, sizeof(p->context));
    800011ba:	07000613          	li	a2,112
    800011be:	4581                	li	a1,0
    800011c0:	06048513          	addi	a0,s1,96
    800011c4:	fffff097          	auipc	ra,0xfffff
    800011c8:	fb6080e7          	jalr	-74(ra) # 8000017a <memset>
  p->context.ra = (uint64)forkret;
    800011cc:	00000797          	auipc	a5,0x0
    800011d0:	d7278793          	addi	a5,a5,-654 # 80000f3e <forkret>
    800011d4:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    800011d6:	60bc                	ld	a5,64(s1)
    800011d8:	6705                	lui	a4,0x1
    800011da:	97ba                	add	a5,a5,a4
    800011dc:	f4bc                	sd	a5,104(s1)
}
    800011de:	8526                	mv	a0,s1
    800011e0:	60e2                	ld	ra,24(sp)
    800011e2:	6442                	ld	s0,16(sp)
    800011e4:	64a2                	ld	s1,8(sp)
    800011e6:	6902                	ld	s2,0(sp)
    800011e8:	6105                	addi	sp,sp,32
    800011ea:	8082                	ret
    freeproc(p);
    800011ec:	8526                	mv	a0,s1
    800011ee:	00000097          	auipc	ra,0x0
    800011f2:	ece080e7          	jalr	-306(ra) # 800010bc <freeproc>
    release(&p->lock);
    800011f6:	8526                	mv	a0,s1
    800011f8:	00005097          	auipc	ra,0x5
    800011fc:	3ca080e7          	jalr	970(ra) # 800065c2 <release>
    return 0;
    80001200:	84ca                	mv	s1,s2
    80001202:	bff1                	j	800011de <allocproc+0xac>
    freeproc(p);
    80001204:	8526                	mv	a0,s1
    80001206:	00000097          	auipc	ra,0x0
    8000120a:	eb6080e7          	jalr	-330(ra) # 800010bc <freeproc>
    release(&p->lock);
    8000120e:	8526                	mv	a0,s1
    80001210:	00005097          	auipc	ra,0x5
    80001214:	3b2080e7          	jalr	946(ra) # 800065c2 <release>
    return 0;
    80001218:	84ca                	mv	s1,s2
    8000121a:	b7d1                	j	800011de <allocproc+0xac>
    freeproc(p);
    8000121c:	8526                	mv	a0,s1
    8000121e:	00000097          	auipc	ra,0x0
    80001222:	e9e080e7          	jalr	-354(ra) # 800010bc <freeproc>
    release(&p->lock);
    80001226:	8526                	mv	a0,s1
    80001228:	00005097          	auipc	ra,0x5
    8000122c:	39a080e7          	jalr	922(ra) # 800065c2 <release>
    return 0;
    80001230:	84ca                	mv	s1,s2
    80001232:	b775                	j	800011de <allocproc+0xac>

0000000080001234 <userinit>:
{
    80001234:	1101                	addi	sp,sp,-32
    80001236:	ec06                	sd	ra,24(sp)
    80001238:	e822                	sd	s0,16(sp)
    8000123a:	e426                	sd	s1,8(sp)
    8000123c:	1000                	addi	s0,sp,32
  p = allocproc();
    8000123e:	00000097          	auipc	ra,0x0
    80001242:	ef4080e7          	jalr	-268(ra) # 80001132 <allocproc>
    80001246:	84aa                	mv	s1,a0
  initproc = p;
    80001248:	0000d797          	auipc	a5,0xd
    8000124c:	bea7b423          	sd	a0,-1048(a5) # 8000de30 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    80001250:	03400613          	li	a2,52
    80001254:	0000d597          	auipc	a1,0xd
    80001258:	b6c58593          	addi	a1,a1,-1172 # 8000ddc0 <initcode>
    8000125c:	6928                	ld	a0,80(a0)
    8000125e:	fffff097          	auipc	ra,0xfffff
    80001262:	5cc080e7          	jalr	1484(ra) # 8000082a <uvmfirst>
  p->sz = PGSIZE;
    80001266:	6785                	lui	a5,0x1
    80001268:	e4bc                	sd	a5,72(s1)
  p->trapframe->epc = 0;      // user program counter
    8000126a:	6cb8                	ld	a4,88(s1)
    8000126c:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    80001270:	6cb8                	ld	a4,88(s1)
    80001272:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    80001274:	4641                	li	a2,16
    80001276:	00007597          	auipc	a1,0x7
    8000127a:	f4a58593          	addi	a1,a1,-182 # 800081c0 <etext+0x1c0>
    8000127e:	15848513          	addi	a0,s1,344
    80001282:	fffff097          	auipc	ra,0xfffff
    80001286:	03a080e7          	jalr	58(ra) # 800002bc <safestrcpy>
  p->cwd = namei("/");
    8000128a:	00007517          	auipc	a0,0x7
    8000128e:	f4650513          	addi	a0,a0,-186 # 800081d0 <etext+0x1d0>
    80001292:	00002097          	auipc	ra,0x2
    80001296:	22a080e7          	jalr	554(ra) # 800034bc <namei>
    8000129a:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    8000129e:	478d                	li	a5,3
    800012a0:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    800012a2:	8526                	mv	a0,s1
    800012a4:	00005097          	auipc	ra,0x5
    800012a8:	31e080e7          	jalr	798(ra) # 800065c2 <release>
}
    800012ac:	60e2                	ld	ra,24(sp)
    800012ae:	6442                	ld	s0,16(sp)
    800012b0:	64a2                	ld	s1,8(sp)
    800012b2:	6105                	addi	sp,sp,32
    800012b4:	8082                	ret

00000000800012b6 <growproc>:
{
    800012b6:	1101                	addi	sp,sp,-32
    800012b8:	ec06                	sd	ra,24(sp)
    800012ba:	e822                	sd	s0,16(sp)
    800012bc:	e426                	sd	s1,8(sp)
    800012be:	e04a                	sd	s2,0(sp)
    800012c0:	1000                	addi	s0,sp,32
    800012c2:	892a                	mv	s2,a0
  struct proc *p = myproc();
    800012c4:	00000097          	auipc	ra,0x0
    800012c8:	c42080e7          	jalr	-958(ra) # 80000f06 <myproc>
    800012cc:	84aa                	mv	s1,a0
  sz = p->sz;
    800012ce:	652c                	ld	a1,72(a0)
  if(n > 0){
    800012d0:	01204c63          	bgtz	s2,800012e8 <growproc+0x32>
  } else if(n < 0){
    800012d4:	02094663          	bltz	s2,80001300 <growproc+0x4a>
  p->sz = sz;
    800012d8:	e4ac                	sd	a1,72(s1)
  return 0;
    800012da:	4501                	li	a0,0
}
    800012dc:	60e2                	ld	ra,24(sp)
    800012de:	6442                	ld	s0,16(sp)
    800012e0:	64a2                	ld	s1,8(sp)
    800012e2:	6902                	ld	s2,0(sp)
    800012e4:	6105                	addi	sp,sp,32
    800012e6:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    800012e8:	4691                	li	a3,4
    800012ea:	00b90633          	add	a2,s2,a1
    800012ee:	6928                	ld	a0,80(a0)
    800012f0:	fffff097          	auipc	ra,0xfffff
    800012f4:	5f4080e7          	jalr	1524(ra) # 800008e4 <uvmalloc>
    800012f8:	85aa                	mv	a1,a0
    800012fa:	fd79                	bnez	a0,800012d8 <growproc+0x22>
      return -1;
    800012fc:	557d                	li	a0,-1
    800012fe:	bff9                	j	800012dc <growproc+0x26>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001300:	00b90633          	add	a2,s2,a1
    80001304:	6928                	ld	a0,80(a0)
    80001306:	fffff097          	auipc	ra,0xfffff
    8000130a:	596080e7          	jalr	1430(ra) # 8000089c <uvmdealloc>
    8000130e:	85aa                	mv	a1,a0
    80001310:	b7e1                	j	800012d8 <growproc+0x22>

0000000080001312 <fork>:
{
    80001312:	7139                	addi	sp,sp,-64
    80001314:	fc06                	sd	ra,56(sp)
    80001316:	f822                	sd	s0,48(sp)
    80001318:	f04a                	sd	s2,32(sp)
    8000131a:	e456                	sd	s5,8(sp)
    8000131c:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    8000131e:	00000097          	auipc	ra,0x0
    80001322:	be8080e7          	jalr	-1048(ra) # 80000f06 <myproc>
    80001326:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001328:	00000097          	auipc	ra,0x0
    8000132c:	e0a080e7          	jalr	-502(ra) # 80001132 <allocproc>
    80001330:	12050063          	beqz	a0,80001450 <fork+0x13e>
    80001334:	e852                	sd	s4,16(sp)
    80001336:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001338:	048ab603          	ld	a2,72(s5)
    8000133c:	692c                	ld	a1,80(a0)
    8000133e:	050ab503          	ld	a0,80(s5)
    80001342:	fffff097          	auipc	ra,0xfffff
    80001346:	706080e7          	jalr	1798(ra) # 80000a48 <uvmcopy>
    8000134a:	04054a63          	bltz	a0,8000139e <fork+0x8c>
    8000134e:	f426                	sd	s1,40(sp)
    80001350:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001352:	048ab783          	ld	a5,72(s5)
    80001356:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    8000135a:	058ab683          	ld	a3,88(s5)
    8000135e:	87b6                	mv	a5,a3
    80001360:	058a3703          	ld	a4,88(s4)
    80001364:	12068693          	addi	a3,a3,288
    80001368:	0007b803          	ld	a6,0(a5) # 1000 <_entry-0x7ffff000>
    8000136c:	6788                	ld	a0,8(a5)
    8000136e:	6b8c                	ld	a1,16(a5)
    80001370:	6f90                	ld	a2,24(a5)
    80001372:	01073023          	sd	a6,0(a4)
    80001376:	e708                	sd	a0,8(a4)
    80001378:	eb0c                	sd	a1,16(a4)
    8000137a:	ef10                	sd	a2,24(a4)
    8000137c:	02078793          	addi	a5,a5,32
    80001380:	02070713          	addi	a4,a4,32
    80001384:	fed792e3          	bne	a5,a3,80001368 <fork+0x56>
  np->trapframe->a0 = 0;
    80001388:	058a3783          	ld	a5,88(s4)
    8000138c:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001390:	0d0a8493          	addi	s1,s5,208
    80001394:	0d0a0913          	addi	s2,s4,208
    80001398:	150a8993          	addi	s3,s5,336
    8000139c:	a015                	j	800013c0 <fork+0xae>
    freeproc(np);
    8000139e:	8552                	mv	a0,s4
    800013a0:	00000097          	auipc	ra,0x0
    800013a4:	d1c080e7          	jalr	-740(ra) # 800010bc <freeproc>
    release(&np->lock);
    800013a8:	8552                	mv	a0,s4
    800013aa:	00005097          	auipc	ra,0x5
    800013ae:	218080e7          	jalr	536(ra) # 800065c2 <release>
    return -1;
    800013b2:	597d                	li	s2,-1
    800013b4:	6a42                	ld	s4,16(sp)
    800013b6:	a071                	j	80001442 <fork+0x130>
  for(i = 0; i < NOFILE; i++)
    800013b8:	04a1                	addi	s1,s1,8
    800013ba:	0921                	addi	s2,s2,8
    800013bc:	01348b63          	beq	s1,s3,800013d2 <fork+0xc0>
    if(p->ofile[i])
    800013c0:	6088                	ld	a0,0(s1)
    800013c2:	d97d                	beqz	a0,800013b8 <fork+0xa6>
      np->ofile[i] = filedup(p->ofile[i]);
    800013c4:	00002097          	auipc	ra,0x2
    800013c8:	770080e7          	jalr	1904(ra) # 80003b34 <filedup>
    800013cc:	00a93023          	sd	a0,0(s2)
    800013d0:	b7e5                	j	800013b8 <fork+0xa6>
  np->cwd = idup(p->cwd);
    800013d2:	150ab503          	ld	a0,336(s5)
    800013d6:	00002097          	auipc	ra,0x2
    800013da:	8da080e7          	jalr	-1830(ra) # 80002cb0 <idup>
    800013de:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    800013e2:	4641                	li	a2,16
    800013e4:	158a8593          	addi	a1,s5,344
    800013e8:	158a0513          	addi	a0,s4,344
    800013ec:	fffff097          	auipc	ra,0xfffff
    800013f0:	ed0080e7          	jalr	-304(ra) # 800002bc <safestrcpy>
  pid = np->pid;
    800013f4:	030a2903          	lw	s2,48(s4)
  release(&np->lock);
    800013f8:	8552                	mv	a0,s4
    800013fa:	00005097          	auipc	ra,0x5
    800013fe:	1c8080e7          	jalr	456(ra) # 800065c2 <release>
  acquire(&wait_lock);
    80001402:	0000d497          	auipc	s1,0xd
    80001406:	a8648493          	addi	s1,s1,-1402 # 8000de88 <wait_lock>
    8000140a:	8526                	mv	a0,s1
    8000140c:	00005097          	auipc	ra,0x5
    80001410:	102080e7          	jalr	258(ra) # 8000650e <acquire>
  np->parent = p;
    80001414:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001418:	8526                	mv	a0,s1
    8000141a:	00005097          	auipc	ra,0x5
    8000141e:	1a8080e7          	jalr	424(ra) # 800065c2 <release>
  acquire(&np->lock);
    80001422:	8552                	mv	a0,s4
    80001424:	00005097          	auipc	ra,0x5
    80001428:	0ea080e7          	jalr	234(ra) # 8000650e <acquire>
  np->state = RUNNABLE;
    8000142c:	478d                	li	a5,3
    8000142e:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001432:	8552                	mv	a0,s4
    80001434:	00005097          	auipc	ra,0x5
    80001438:	18e080e7          	jalr	398(ra) # 800065c2 <release>
  return pid;
    8000143c:	74a2                	ld	s1,40(sp)
    8000143e:	69e2                	ld	s3,24(sp)
    80001440:	6a42                	ld	s4,16(sp)
}
    80001442:	854a                	mv	a0,s2
    80001444:	70e2                	ld	ra,56(sp)
    80001446:	7442                	ld	s0,48(sp)
    80001448:	7902                	ld	s2,32(sp)
    8000144a:	6aa2                	ld	s5,8(sp)
    8000144c:	6121                	addi	sp,sp,64
    8000144e:	8082                	ret
    return -1;
    80001450:	597d                	li	s2,-1
    80001452:	bfc5                	j	80001442 <fork+0x130>

0000000080001454 <scheduler>:
{
    80001454:	7139                	addi	sp,sp,-64
    80001456:	fc06                	sd	ra,56(sp)
    80001458:	f822                	sd	s0,48(sp)
    8000145a:	f426                	sd	s1,40(sp)
    8000145c:	f04a                	sd	s2,32(sp)
    8000145e:	ec4e                	sd	s3,24(sp)
    80001460:	e852                	sd	s4,16(sp)
    80001462:	e456                	sd	s5,8(sp)
    80001464:	e05a                	sd	s6,0(sp)
    80001466:	0080                	addi	s0,sp,64
    80001468:	8792                	mv	a5,tp
  int id = r_tp();
    8000146a:	2781                	sext.w	a5,a5
  c->proc = 0;
    8000146c:	00779a93          	slli	s5,a5,0x7
    80001470:	0000d717          	auipc	a4,0xd
    80001474:	a0070713          	addi	a4,a4,-1536 # 8000de70 <pid_lock>
    80001478:	9756                	add	a4,a4,s5
    8000147a:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    8000147e:	0000d717          	auipc	a4,0xd
    80001482:	a2a70713          	addi	a4,a4,-1494 # 8000dea8 <cpus+0x8>
    80001486:	9aba                	add	s5,s5,a4
      if(p->state == RUNNABLE) {
    80001488:	498d                	li	s3,3
        p->state = RUNNING;
    8000148a:	4b11                	li	s6,4
        c->proc = p;
    8000148c:	079e                	slli	a5,a5,0x7
    8000148e:	0000da17          	auipc	s4,0xd
    80001492:	9e2a0a13          	addi	s4,s4,-1566 # 8000de70 <pid_lock>
    80001496:	9a3e                	add	s4,s4,a5
    for(p = proc; p < &proc[NPROC]; p++) {
    80001498:	00013917          	auipc	s2,0x13
    8000149c:	00890913          	addi	s2,s2,8 # 800144a0 <tickslock>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800014a0:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    800014a4:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800014a8:	10079073          	csrw	sstatus,a5
    800014ac:	0000d497          	auipc	s1,0xd
    800014b0:	df448493          	addi	s1,s1,-524 # 8000e2a0 <proc>
    800014b4:	a811                	j	800014c8 <scheduler+0x74>
      release(&p->lock);
    800014b6:	8526                	mv	a0,s1
    800014b8:	00005097          	auipc	ra,0x5
    800014bc:	10a080e7          	jalr	266(ra) # 800065c2 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    800014c0:	18848493          	addi	s1,s1,392
    800014c4:	fd248ee3          	beq	s1,s2,800014a0 <scheduler+0x4c>
      acquire(&p->lock);
    800014c8:	8526                	mv	a0,s1
    800014ca:	00005097          	auipc	ra,0x5
    800014ce:	044080e7          	jalr	68(ra) # 8000650e <acquire>
      if(p->state == RUNNABLE) {
    800014d2:	4c9c                	lw	a5,24(s1)
    800014d4:	ff3791e3          	bne	a5,s3,800014b6 <scheduler+0x62>
        p->state = RUNNING;
    800014d8:	0164ac23          	sw	s6,24(s1)
        c->proc = p;
    800014dc:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    800014e0:	06048593          	addi	a1,s1,96
    800014e4:	8556                	mv	a0,s5
    800014e6:	00000097          	auipc	ra,0x0
    800014ea:	684080e7          	jalr	1668(ra) # 80001b6a <swtch>
        c->proc = 0;
    800014ee:	020a3823          	sd	zero,48(s4)
    800014f2:	b7d1                	j	800014b6 <scheduler+0x62>

00000000800014f4 <sched>:
{
    800014f4:	7179                	addi	sp,sp,-48
    800014f6:	f406                	sd	ra,40(sp)
    800014f8:	f022                	sd	s0,32(sp)
    800014fa:	ec26                	sd	s1,24(sp)
    800014fc:	e84a                	sd	s2,16(sp)
    800014fe:	e44e                	sd	s3,8(sp)
    80001500:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001502:	00000097          	auipc	ra,0x0
    80001506:	a04080e7          	jalr	-1532(ra) # 80000f06 <myproc>
    8000150a:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    8000150c:	00005097          	auipc	ra,0x5
    80001510:	f88080e7          	jalr	-120(ra) # 80006494 <holding>
    80001514:	c93d                	beqz	a0,8000158a <sched+0x96>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001516:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80001518:	2781                	sext.w	a5,a5
    8000151a:	079e                	slli	a5,a5,0x7
    8000151c:	0000d717          	auipc	a4,0xd
    80001520:	95470713          	addi	a4,a4,-1708 # 8000de70 <pid_lock>
    80001524:	97ba                	add	a5,a5,a4
    80001526:	0a87a703          	lw	a4,168(a5)
    8000152a:	4785                	li	a5,1
    8000152c:	06f71763          	bne	a4,a5,8000159a <sched+0xa6>
  if(p->state == RUNNING)
    80001530:	4c98                	lw	a4,24(s1)
    80001532:	4791                	li	a5,4
    80001534:	06f70b63          	beq	a4,a5,800015aa <sched+0xb6>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001538:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000153c:	8b89                	andi	a5,a5,2
  if(intr_get())
    8000153e:	efb5                	bnez	a5,800015ba <sched+0xc6>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001540:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001542:	0000d917          	auipc	s2,0xd
    80001546:	92e90913          	addi	s2,s2,-1746 # 8000de70 <pid_lock>
    8000154a:	2781                	sext.w	a5,a5
    8000154c:	079e                	slli	a5,a5,0x7
    8000154e:	97ca                	add	a5,a5,s2
    80001550:	0ac7a983          	lw	s3,172(a5)
    80001554:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001556:	2781                	sext.w	a5,a5
    80001558:	079e                	slli	a5,a5,0x7
    8000155a:	0000d597          	auipc	a1,0xd
    8000155e:	94e58593          	addi	a1,a1,-1714 # 8000dea8 <cpus+0x8>
    80001562:	95be                	add	a1,a1,a5
    80001564:	06048513          	addi	a0,s1,96
    80001568:	00000097          	auipc	ra,0x0
    8000156c:	602080e7          	jalr	1538(ra) # 80001b6a <swtch>
    80001570:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001572:	2781                	sext.w	a5,a5
    80001574:	079e                	slli	a5,a5,0x7
    80001576:	993e                	add	s2,s2,a5
    80001578:	0b392623          	sw	s3,172(s2)
}
    8000157c:	70a2                	ld	ra,40(sp)
    8000157e:	7402                	ld	s0,32(sp)
    80001580:	64e2                	ld	s1,24(sp)
    80001582:	6942                	ld	s2,16(sp)
    80001584:	69a2                	ld	s3,8(sp)
    80001586:	6145                	addi	sp,sp,48
    80001588:	8082                	ret
    panic("sched p->lock");
    8000158a:	00007517          	auipc	a0,0x7
    8000158e:	c4e50513          	addi	a0,a0,-946 # 800081d8 <etext+0x1d8>
    80001592:	00005097          	auipc	ra,0x5
    80001596:	9fa080e7          	jalr	-1542(ra) # 80005f8c <panic>
    panic("sched locks");
    8000159a:	00007517          	auipc	a0,0x7
    8000159e:	c4e50513          	addi	a0,a0,-946 # 800081e8 <etext+0x1e8>
    800015a2:	00005097          	auipc	ra,0x5
    800015a6:	9ea080e7          	jalr	-1558(ra) # 80005f8c <panic>
    panic("sched running");
    800015aa:	00007517          	auipc	a0,0x7
    800015ae:	c4e50513          	addi	a0,a0,-946 # 800081f8 <etext+0x1f8>
    800015b2:	00005097          	auipc	ra,0x5
    800015b6:	9da080e7          	jalr	-1574(ra) # 80005f8c <panic>
    panic("sched interruptible");
    800015ba:	00007517          	auipc	a0,0x7
    800015be:	c4e50513          	addi	a0,a0,-946 # 80008208 <etext+0x208>
    800015c2:	00005097          	auipc	ra,0x5
    800015c6:	9ca080e7          	jalr	-1590(ra) # 80005f8c <panic>

00000000800015ca <yield>:
{
    800015ca:	1101                	addi	sp,sp,-32
    800015cc:	ec06                	sd	ra,24(sp)
    800015ce:	e822                	sd	s0,16(sp)
    800015d0:	e426                	sd	s1,8(sp)
    800015d2:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    800015d4:	00000097          	auipc	ra,0x0
    800015d8:	932080e7          	jalr	-1742(ra) # 80000f06 <myproc>
    800015dc:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800015de:	00005097          	auipc	ra,0x5
    800015e2:	f30080e7          	jalr	-208(ra) # 8000650e <acquire>
  p->state = RUNNABLE;
    800015e6:	478d                	li	a5,3
    800015e8:	cc9c                	sw	a5,24(s1)
  sched();
    800015ea:	00000097          	auipc	ra,0x0
    800015ee:	f0a080e7          	jalr	-246(ra) # 800014f4 <sched>
  release(&p->lock);
    800015f2:	8526                	mv	a0,s1
    800015f4:	00005097          	auipc	ra,0x5
    800015f8:	fce080e7          	jalr	-50(ra) # 800065c2 <release>
}
    800015fc:	60e2                	ld	ra,24(sp)
    800015fe:	6442                	ld	s0,16(sp)
    80001600:	64a2                	ld	s1,8(sp)
    80001602:	6105                	addi	sp,sp,32
    80001604:	8082                	ret

0000000080001606 <sleep>:

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001606:	7179                	addi	sp,sp,-48
    80001608:	f406                	sd	ra,40(sp)
    8000160a:	f022                	sd	s0,32(sp)
    8000160c:	ec26                	sd	s1,24(sp)
    8000160e:	e84a                	sd	s2,16(sp)
    80001610:	e44e                	sd	s3,8(sp)
    80001612:	1800                	addi	s0,sp,48
    80001614:	89aa                	mv	s3,a0
    80001616:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001618:	00000097          	auipc	ra,0x0
    8000161c:	8ee080e7          	jalr	-1810(ra) # 80000f06 <myproc>
    80001620:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80001622:	00005097          	auipc	ra,0x5
    80001626:	eec080e7          	jalr	-276(ra) # 8000650e <acquire>
  release(lk);
    8000162a:	854a                	mv	a0,s2
    8000162c:	00005097          	auipc	ra,0x5
    80001630:	f96080e7          	jalr	-106(ra) # 800065c2 <release>

  // Go to sleep.
  p->chan = chan;
    80001634:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80001638:	4789                	li	a5,2
    8000163a:	cc9c                	sw	a5,24(s1)

  sched();
    8000163c:	00000097          	auipc	ra,0x0
    80001640:	eb8080e7          	jalr	-328(ra) # 800014f4 <sched>

  // Tidy up.
  p->chan = 0;
    80001644:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80001648:	8526                	mv	a0,s1
    8000164a:	00005097          	auipc	ra,0x5
    8000164e:	f78080e7          	jalr	-136(ra) # 800065c2 <release>
  acquire(lk);
    80001652:	854a                	mv	a0,s2
    80001654:	00005097          	auipc	ra,0x5
    80001658:	eba080e7          	jalr	-326(ra) # 8000650e <acquire>
}
    8000165c:	70a2                	ld	ra,40(sp)
    8000165e:	7402                	ld	s0,32(sp)
    80001660:	64e2                	ld	s1,24(sp)
    80001662:	6942                	ld	s2,16(sp)
    80001664:	69a2                	ld	s3,8(sp)
    80001666:	6145                	addi	sp,sp,48
    80001668:	8082                	ret

000000008000166a <wakeup>:

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
    8000166a:	7139                	addi	sp,sp,-64
    8000166c:	fc06                	sd	ra,56(sp)
    8000166e:	f822                	sd	s0,48(sp)
    80001670:	f426                	sd	s1,40(sp)
    80001672:	f04a                	sd	s2,32(sp)
    80001674:	ec4e                	sd	s3,24(sp)
    80001676:	e852                	sd	s4,16(sp)
    80001678:	e456                	sd	s5,8(sp)
    8000167a:	0080                	addi	s0,sp,64
    8000167c:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    8000167e:	0000d497          	auipc	s1,0xd
    80001682:	c2248493          	addi	s1,s1,-990 # 8000e2a0 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80001686:	4989                	li	s3,2
        p->state = RUNNABLE;
    80001688:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    8000168a:	00013917          	auipc	s2,0x13
    8000168e:	e1690913          	addi	s2,s2,-490 # 800144a0 <tickslock>
    80001692:	a811                	j	800016a6 <wakeup+0x3c>
      }
      release(&p->lock);
    80001694:	8526                	mv	a0,s1
    80001696:	00005097          	auipc	ra,0x5
    8000169a:	f2c080e7          	jalr	-212(ra) # 800065c2 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000169e:	18848493          	addi	s1,s1,392
    800016a2:	03248663          	beq	s1,s2,800016ce <wakeup+0x64>
    if(p != myproc()){
    800016a6:	00000097          	auipc	ra,0x0
    800016aa:	860080e7          	jalr	-1952(ra) # 80000f06 <myproc>
    800016ae:	fea488e3          	beq	s1,a0,8000169e <wakeup+0x34>
      acquire(&p->lock);
    800016b2:	8526                	mv	a0,s1
    800016b4:	00005097          	auipc	ra,0x5
    800016b8:	e5a080e7          	jalr	-422(ra) # 8000650e <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    800016bc:	4c9c                	lw	a5,24(s1)
    800016be:	fd379be3          	bne	a5,s3,80001694 <wakeup+0x2a>
    800016c2:	709c                	ld	a5,32(s1)
    800016c4:	fd4798e3          	bne	a5,s4,80001694 <wakeup+0x2a>
        p->state = RUNNABLE;
    800016c8:	0154ac23          	sw	s5,24(s1)
    800016cc:	b7e1                	j	80001694 <wakeup+0x2a>
    }
  }
}
    800016ce:	70e2                	ld	ra,56(sp)
    800016d0:	7442                	ld	s0,48(sp)
    800016d2:	74a2                	ld	s1,40(sp)
    800016d4:	7902                	ld	s2,32(sp)
    800016d6:	69e2                	ld	s3,24(sp)
    800016d8:	6a42                	ld	s4,16(sp)
    800016da:	6aa2                	ld	s5,8(sp)
    800016dc:	6121                	addi	sp,sp,64
    800016de:	8082                	ret

00000000800016e0 <reparent>:
{
    800016e0:	7179                	addi	sp,sp,-48
    800016e2:	f406                	sd	ra,40(sp)
    800016e4:	f022                	sd	s0,32(sp)
    800016e6:	ec26                	sd	s1,24(sp)
    800016e8:	e84a                	sd	s2,16(sp)
    800016ea:	e44e                	sd	s3,8(sp)
    800016ec:	e052                	sd	s4,0(sp)
    800016ee:	1800                	addi	s0,sp,48
    800016f0:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    800016f2:	0000d497          	auipc	s1,0xd
    800016f6:	bae48493          	addi	s1,s1,-1106 # 8000e2a0 <proc>
      pp->parent = initproc;
    800016fa:	0000ca17          	auipc	s4,0xc
    800016fe:	736a0a13          	addi	s4,s4,1846 # 8000de30 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001702:	00013997          	auipc	s3,0x13
    80001706:	d9e98993          	addi	s3,s3,-610 # 800144a0 <tickslock>
    8000170a:	a029                	j	80001714 <reparent+0x34>
    8000170c:	18848493          	addi	s1,s1,392
    80001710:	01348d63          	beq	s1,s3,8000172a <reparent+0x4a>
    if(pp->parent == p){
    80001714:	7c9c                	ld	a5,56(s1)
    80001716:	ff279be3          	bne	a5,s2,8000170c <reparent+0x2c>
      pp->parent = initproc;
    8000171a:	000a3503          	ld	a0,0(s4)
    8000171e:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80001720:	00000097          	auipc	ra,0x0
    80001724:	f4a080e7          	jalr	-182(ra) # 8000166a <wakeup>
    80001728:	b7d5                	j	8000170c <reparent+0x2c>
}
    8000172a:	70a2                	ld	ra,40(sp)
    8000172c:	7402                	ld	s0,32(sp)
    8000172e:	64e2                	ld	s1,24(sp)
    80001730:	6942                	ld	s2,16(sp)
    80001732:	69a2                	ld	s3,8(sp)
    80001734:	6a02                	ld	s4,0(sp)
    80001736:	6145                	addi	sp,sp,48
    80001738:	8082                	ret

000000008000173a <exit>:
{
    8000173a:	7179                	addi	sp,sp,-48
    8000173c:	f406                	sd	ra,40(sp)
    8000173e:	f022                	sd	s0,32(sp)
    80001740:	ec26                	sd	s1,24(sp)
    80001742:	e84a                	sd	s2,16(sp)
    80001744:	e44e                	sd	s3,8(sp)
    80001746:	e052                	sd	s4,0(sp)
    80001748:	1800                	addi	s0,sp,48
    8000174a:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    8000174c:	fffff097          	auipc	ra,0xfffff
    80001750:	7ba080e7          	jalr	1978(ra) # 80000f06 <myproc>
    80001754:	89aa                	mv	s3,a0
  if(p == initproc)
    80001756:	0000c797          	auipc	a5,0xc
    8000175a:	6da7b783          	ld	a5,1754(a5) # 8000de30 <initproc>
    8000175e:	0d050493          	addi	s1,a0,208
    80001762:	15050913          	addi	s2,a0,336
    80001766:	02a79363          	bne	a5,a0,8000178c <exit+0x52>
    panic("init exiting");
    8000176a:	00007517          	auipc	a0,0x7
    8000176e:	ab650513          	addi	a0,a0,-1354 # 80008220 <etext+0x220>
    80001772:	00005097          	auipc	ra,0x5
    80001776:	81a080e7          	jalr	-2022(ra) # 80005f8c <panic>
      fileclose(f);
    8000177a:	00002097          	auipc	ra,0x2
    8000177e:	40c080e7          	jalr	1036(ra) # 80003b86 <fileclose>
      p->ofile[fd] = 0;
    80001782:	0004b023          	sd	zero,0(s1)
  for(int fd = 0; fd < NOFILE; fd++){
    80001786:	04a1                	addi	s1,s1,8
    80001788:	01248563          	beq	s1,s2,80001792 <exit+0x58>
    if(p->ofile[fd]){
    8000178c:	6088                	ld	a0,0(s1)
    8000178e:	f575                	bnez	a0,8000177a <exit+0x40>
    80001790:	bfdd                	j	80001786 <exit+0x4c>
  begin_op();
    80001792:	00002097          	auipc	ra,0x2
    80001796:	f2a080e7          	jalr	-214(ra) # 800036bc <begin_op>
  iput(p->cwd);
    8000179a:	1509b503          	ld	a0,336(s3)
    8000179e:	00001097          	auipc	ra,0x1
    800017a2:	70e080e7          	jalr	1806(ra) # 80002eac <iput>
  end_op();
    800017a6:	00002097          	auipc	ra,0x2
    800017aa:	f90080e7          	jalr	-112(ra) # 80003736 <end_op>
  p->cwd = 0;
    800017ae:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    800017b2:	0000c497          	auipc	s1,0xc
    800017b6:	6d648493          	addi	s1,s1,1750 # 8000de88 <wait_lock>
    800017ba:	8526                	mv	a0,s1
    800017bc:	00005097          	auipc	ra,0x5
    800017c0:	d52080e7          	jalr	-686(ra) # 8000650e <acquire>
  reparent(p);
    800017c4:	854e                	mv	a0,s3
    800017c6:	00000097          	auipc	ra,0x0
    800017ca:	f1a080e7          	jalr	-230(ra) # 800016e0 <reparent>
  wakeup(p->parent);
    800017ce:	0389b503          	ld	a0,56(s3)
    800017d2:	00000097          	auipc	ra,0x0
    800017d6:	e98080e7          	jalr	-360(ra) # 8000166a <wakeup>
  acquire(&p->lock);
    800017da:	854e                	mv	a0,s3
    800017dc:	00005097          	auipc	ra,0x5
    800017e0:	d32080e7          	jalr	-718(ra) # 8000650e <acquire>
  p->xstate = status;
    800017e4:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    800017e8:	4795                	li	a5,5
    800017ea:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    800017ee:	8526                	mv	a0,s1
    800017f0:	00005097          	auipc	ra,0x5
    800017f4:	dd2080e7          	jalr	-558(ra) # 800065c2 <release>
  sched();
    800017f8:	00000097          	auipc	ra,0x0
    800017fc:	cfc080e7          	jalr	-772(ra) # 800014f4 <sched>
  panic("zombie exit");
    80001800:	00007517          	auipc	a0,0x7
    80001804:	a3050513          	addi	a0,a0,-1488 # 80008230 <etext+0x230>
    80001808:	00004097          	auipc	ra,0x4
    8000180c:	784080e7          	jalr	1924(ra) # 80005f8c <panic>

0000000080001810 <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    80001810:	7179                	addi	sp,sp,-48
    80001812:	f406                	sd	ra,40(sp)
    80001814:	f022                	sd	s0,32(sp)
    80001816:	ec26                	sd	s1,24(sp)
    80001818:	e84a                	sd	s2,16(sp)
    8000181a:	e44e                	sd	s3,8(sp)
    8000181c:	1800                	addi	s0,sp,48
    8000181e:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    80001820:	0000d497          	auipc	s1,0xd
    80001824:	a8048493          	addi	s1,s1,-1408 # 8000e2a0 <proc>
    80001828:	00013997          	auipc	s3,0x13
    8000182c:	c7898993          	addi	s3,s3,-904 # 800144a0 <tickslock>
    acquire(&p->lock);
    80001830:	8526                	mv	a0,s1
    80001832:	00005097          	auipc	ra,0x5
    80001836:	cdc080e7          	jalr	-804(ra) # 8000650e <acquire>
    if(p->pid == pid){
    8000183a:	589c                	lw	a5,48(s1)
    8000183c:	01278d63          	beq	a5,s2,80001856 <kill+0x46>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80001840:	8526                	mv	a0,s1
    80001842:	00005097          	auipc	ra,0x5
    80001846:	d80080e7          	jalr	-640(ra) # 800065c2 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    8000184a:	18848493          	addi	s1,s1,392
    8000184e:	ff3491e3          	bne	s1,s3,80001830 <kill+0x20>
  }
  return -1;
    80001852:	557d                	li	a0,-1
    80001854:	a829                	j	8000186e <kill+0x5e>
      p->killed = 1;
    80001856:	4785                	li	a5,1
    80001858:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    8000185a:	4c98                	lw	a4,24(s1)
    8000185c:	4789                	li	a5,2
    8000185e:	00f70f63          	beq	a4,a5,8000187c <kill+0x6c>
      release(&p->lock);
    80001862:	8526                	mv	a0,s1
    80001864:	00005097          	auipc	ra,0x5
    80001868:	d5e080e7          	jalr	-674(ra) # 800065c2 <release>
      return 0;
    8000186c:	4501                	li	a0,0
}
    8000186e:	70a2                	ld	ra,40(sp)
    80001870:	7402                	ld	s0,32(sp)
    80001872:	64e2                	ld	s1,24(sp)
    80001874:	6942                	ld	s2,16(sp)
    80001876:	69a2                	ld	s3,8(sp)
    80001878:	6145                	addi	sp,sp,48
    8000187a:	8082                	ret
        p->state = RUNNABLE;
    8000187c:	478d                	li	a5,3
    8000187e:	cc9c                	sw	a5,24(s1)
    80001880:	b7cd                	j	80001862 <kill+0x52>

0000000080001882 <setkilled>:

void
setkilled(struct proc *p)
{
    80001882:	1101                	addi	sp,sp,-32
    80001884:	ec06                	sd	ra,24(sp)
    80001886:	e822                	sd	s0,16(sp)
    80001888:	e426                	sd	s1,8(sp)
    8000188a:	1000                	addi	s0,sp,32
    8000188c:	84aa                	mv	s1,a0
  acquire(&p->lock);
    8000188e:	00005097          	auipc	ra,0x5
    80001892:	c80080e7          	jalr	-896(ra) # 8000650e <acquire>
  p->killed = 1;
    80001896:	4785                	li	a5,1
    80001898:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    8000189a:	8526                	mv	a0,s1
    8000189c:	00005097          	auipc	ra,0x5
    800018a0:	d26080e7          	jalr	-730(ra) # 800065c2 <release>
}
    800018a4:	60e2                	ld	ra,24(sp)
    800018a6:	6442                	ld	s0,16(sp)
    800018a8:	64a2                	ld	s1,8(sp)
    800018aa:	6105                	addi	sp,sp,32
    800018ac:	8082                	ret

00000000800018ae <killed>:

int
killed(struct proc *p)
{
    800018ae:	1101                	addi	sp,sp,-32
    800018b0:	ec06                	sd	ra,24(sp)
    800018b2:	e822                	sd	s0,16(sp)
    800018b4:	e426                	sd	s1,8(sp)
    800018b6:	e04a                	sd	s2,0(sp)
    800018b8:	1000                	addi	s0,sp,32
    800018ba:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    800018bc:	00005097          	auipc	ra,0x5
    800018c0:	c52080e7          	jalr	-942(ra) # 8000650e <acquire>
  k = p->killed;
    800018c4:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    800018c8:	8526                	mv	a0,s1
    800018ca:	00005097          	auipc	ra,0x5
    800018ce:	cf8080e7          	jalr	-776(ra) # 800065c2 <release>
  return k;
}
    800018d2:	854a                	mv	a0,s2
    800018d4:	60e2                	ld	ra,24(sp)
    800018d6:	6442                	ld	s0,16(sp)
    800018d8:	64a2                	ld	s1,8(sp)
    800018da:	6902                	ld	s2,0(sp)
    800018dc:	6105                	addi	sp,sp,32
    800018de:	8082                	ret

00000000800018e0 <wait>:
{
    800018e0:	715d                	addi	sp,sp,-80
    800018e2:	e486                	sd	ra,72(sp)
    800018e4:	e0a2                	sd	s0,64(sp)
    800018e6:	fc26                	sd	s1,56(sp)
    800018e8:	f84a                	sd	s2,48(sp)
    800018ea:	f44e                	sd	s3,40(sp)
    800018ec:	f052                	sd	s4,32(sp)
    800018ee:	ec56                	sd	s5,24(sp)
    800018f0:	e85a                	sd	s6,16(sp)
    800018f2:	e45e                	sd	s7,8(sp)
    800018f4:	e062                	sd	s8,0(sp)
    800018f6:	0880                	addi	s0,sp,80
    800018f8:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    800018fa:	fffff097          	auipc	ra,0xfffff
    800018fe:	60c080e7          	jalr	1548(ra) # 80000f06 <myproc>
    80001902:	892a                	mv	s2,a0
  acquire(&wait_lock);
    80001904:	0000c517          	auipc	a0,0xc
    80001908:	58450513          	addi	a0,a0,1412 # 8000de88 <wait_lock>
    8000190c:	00005097          	auipc	ra,0x5
    80001910:	c02080e7          	jalr	-1022(ra) # 8000650e <acquire>
    havekids = 0;
    80001914:	4b81                	li	s7,0
        if(pp->state == ZOMBIE){
    80001916:	4a15                	li	s4,5
        havekids = 1;
    80001918:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000191a:	00013997          	auipc	s3,0x13
    8000191e:	b8698993          	addi	s3,s3,-1146 # 800144a0 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80001922:	0000cc17          	auipc	s8,0xc
    80001926:	566c0c13          	addi	s8,s8,1382 # 8000de88 <wait_lock>
    8000192a:	a0d1                	j	800019ee <wait+0x10e>
          pid = pp->pid;
    8000192c:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    80001930:	000b0e63          	beqz	s6,8000194c <wait+0x6c>
    80001934:	4691                	li	a3,4
    80001936:	02c48613          	addi	a2,s1,44
    8000193a:	85da                	mv	a1,s6
    8000193c:	05093503          	ld	a0,80(s2)
    80001940:	fffff097          	auipc	ra,0xfffff
    80001944:	20c080e7          	jalr	524(ra) # 80000b4c <copyout>
    80001948:	04054163          	bltz	a0,8000198a <wait+0xaa>
          freeproc(pp);
    8000194c:	8526                	mv	a0,s1
    8000194e:	fffff097          	auipc	ra,0xfffff
    80001952:	76e080e7          	jalr	1902(ra) # 800010bc <freeproc>
          release(&pp->lock);
    80001956:	8526                	mv	a0,s1
    80001958:	00005097          	auipc	ra,0x5
    8000195c:	c6a080e7          	jalr	-918(ra) # 800065c2 <release>
          release(&wait_lock);
    80001960:	0000c517          	auipc	a0,0xc
    80001964:	52850513          	addi	a0,a0,1320 # 8000de88 <wait_lock>
    80001968:	00005097          	auipc	ra,0x5
    8000196c:	c5a080e7          	jalr	-934(ra) # 800065c2 <release>
}
    80001970:	854e                	mv	a0,s3
    80001972:	60a6                	ld	ra,72(sp)
    80001974:	6406                	ld	s0,64(sp)
    80001976:	74e2                	ld	s1,56(sp)
    80001978:	7942                	ld	s2,48(sp)
    8000197a:	79a2                	ld	s3,40(sp)
    8000197c:	7a02                	ld	s4,32(sp)
    8000197e:	6ae2                	ld	s5,24(sp)
    80001980:	6b42                	ld	s6,16(sp)
    80001982:	6ba2                	ld	s7,8(sp)
    80001984:	6c02                	ld	s8,0(sp)
    80001986:	6161                	addi	sp,sp,80
    80001988:	8082                	ret
            release(&pp->lock);
    8000198a:	8526                	mv	a0,s1
    8000198c:	00005097          	auipc	ra,0x5
    80001990:	c36080e7          	jalr	-970(ra) # 800065c2 <release>
            release(&wait_lock);
    80001994:	0000c517          	auipc	a0,0xc
    80001998:	4f450513          	addi	a0,a0,1268 # 8000de88 <wait_lock>
    8000199c:	00005097          	auipc	ra,0x5
    800019a0:	c26080e7          	jalr	-986(ra) # 800065c2 <release>
            return -1;
    800019a4:	59fd                	li	s3,-1
    800019a6:	b7e9                	j	80001970 <wait+0x90>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800019a8:	18848493          	addi	s1,s1,392
    800019ac:	03348463          	beq	s1,s3,800019d4 <wait+0xf4>
      if(pp->parent == p){
    800019b0:	7c9c                	ld	a5,56(s1)
    800019b2:	ff279be3          	bne	a5,s2,800019a8 <wait+0xc8>
        acquire(&pp->lock);
    800019b6:	8526                	mv	a0,s1
    800019b8:	00005097          	auipc	ra,0x5
    800019bc:	b56080e7          	jalr	-1194(ra) # 8000650e <acquire>
        if(pp->state == ZOMBIE){
    800019c0:	4c9c                	lw	a5,24(s1)
    800019c2:	f74785e3          	beq	a5,s4,8000192c <wait+0x4c>
        release(&pp->lock);
    800019c6:	8526                	mv	a0,s1
    800019c8:	00005097          	auipc	ra,0x5
    800019cc:	bfa080e7          	jalr	-1030(ra) # 800065c2 <release>
        havekids = 1;
    800019d0:	8756                	mv	a4,s5
    800019d2:	bfd9                	j	800019a8 <wait+0xc8>
    if(!havekids || killed(p)){
    800019d4:	c31d                	beqz	a4,800019fa <wait+0x11a>
    800019d6:	854a                	mv	a0,s2
    800019d8:	00000097          	auipc	ra,0x0
    800019dc:	ed6080e7          	jalr	-298(ra) # 800018ae <killed>
    800019e0:	ed09                	bnez	a0,800019fa <wait+0x11a>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800019e2:	85e2                	mv	a1,s8
    800019e4:	854a                	mv	a0,s2
    800019e6:	00000097          	auipc	ra,0x0
    800019ea:	c20080e7          	jalr	-992(ra) # 80001606 <sleep>
    havekids = 0;
    800019ee:	875e                	mv	a4,s7
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800019f0:	0000d497          	auipc	s1,0xd
    800019f4:	8b048493          	addi	s1,s1,-1872 # 8000e2a0 <proc>
    800019f8:	bf65                	j	800019b0 <wait+0xd0>
      release(&wait_lock);
    800019fa:	0000c517          	auipc	a0,0xc
    800019fe:	48e50513          	addi	a0,a0,1166 # 8000de88 <wait_lock>
    80001a02:	00005097          	auipc	ra,0x5
    80001a06:	bc0080e7          	jalr	-1088(ra) # 800065c2 <release>
      return -1;
    80001a0a:	59fd                	li	s3,-1
    80001a0c:	b795                	j	80001970 <wait+0x90>

0000000080001a0e <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80001a0e:	7179                	addi	sp,sp,-48
    80001a10:	f406                	sd	ra,40(sp)
    80001a12:	f022                	sd	s0,32(sp)
    80001a14:	ec26                	sd	s1,24(sp)
    80001a16:	e84a                	sd	s2,16(sp)
    80001a18:	e44e                	sd	s3,8(sp)
    80001a1a:	e052                	sd	s4,0(sp)
    80001a1c:	1800                	addi	s0,sp,48
    80001a1e:	84aa                	mv	s1,a0
    80001a20:	892e                	mv	s2,a1
    80001a22:	89b2                	mv	s3,a2
    80001a24:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    80001a26:	fffff097          	auipc	ra,0xfffff
    80001a2a:	4e0080e7          	jalr	1248(ra) # 80000f06 <myproc>
  if(user_dst){
    80001a2e:	c08d                	beqz	s1,80001a50 <either_copyout+0x42>
    return copyout(p->pagetable, dst, src, len);
    80001a30:	86d2                	mv	a3,s4
    80001a32:	864e                	mv	a2,s3
    80001a34:	85ca                	mv	a1,s2
    80001a36:	6928                	ld	a0,80(a0)
    80001a38:	fffff097          	auipc	ra,0xfffff
    80001a3c:	114080e7          	jalr	276(ra) # 80000b4c <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80001a40:	70a2                	ld	ra,40(sp)
    80001a42:	7402                	ld	s0,32(sp)
    80001a44:	64e2                	ld	s1,24(sp)
    80001a46:	6942                	ld	s2,16(sp)
    80001a48:	69a2                	ld	s3,8(sp)
    80001a4a:	6a02                	ld	s4,0(sp)
    80001a4c:	6145                	addi	sp,sp,48
    80001a4e:	8082                	ret
    memmove((char *)dst, src, len);
    80001a50:	000a061b          	sext.w	a2,s4
    80001a54:	85ce                	mv	a1,s3
    80001a56:	854a                	mv	a0,s2
    80001a58:	ffffe097          	auipc	ra,0xffffe
    80001a5c:	77e080e7          	jalr	1918(ra) # 800001d6 <memmove>
    return 0;
    80001a60:	8526                	mv	a0,s1
    80001a62:	bff9                	j	80001a40 <either_copyout+0x32>

0000000080001a64 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    80001a64:	7179                	addi	sp,sp,-48
    80001a66:	f406                	sd	ra,40(sp)
    80001a68:	f022                	sd	s0,32(sp)
    80001a6a:	ec26                	sd	s1,24(sp)
    80001a6c:	e84a                	sd	s2,16(sp)
    80001a6e:	e44e                	sd	s3,8(sp)
    80001a70:	e052                	sd	s4,0(sp)
    80001a72:	1800                	addi	s0,sp,48
    80001a74:	892a                	mv	s2,a0
    80001a76:	84ae                	mv	s1,a1
    80001a78:	89b2                	mv	s3,a2
    80001a7a:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    80001a7c:	fffff097          	auipc	ra,0xfffff
    80001a80:	48a080e7          	jalr	1162(ra) # 80000f06 <myproc>
  if(user_src){
    80001a84:	c08d                	beqz	s1,80001aa6 <either_copyin+0x42>
    return copyin(p->pagetable, dst, src, len);
    80001a86:	86d2                	mv	a3,s4
    80001a88:	864e                	mv	a2,s3
    80001a8a:	85ca                	mv	a1,s2
    80001a8c:	6928                	ld	a0,80(a0)
    80001a8e:	fffff097          	auipc	ra,0xfffff
    80001a92:	19c080e7          	jalr	412(ra) # 80000c2a <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    80001a96:	70a2                	ld	ra,40(sp)
    80001a98:	7402                	ld	s0,32(sp)
    80001a9a:	64e2                	ld	s1,24(sp)
    80001a9c:	6942                	ld	s2,16(sp)
    80001a9e:	69a2                	ld	s3,8(sp)
    80001aa0:	6a02                	ld	s4,0(sp)
    80001aa2:	6145                	addi	sp,sp,48
    80001aa4:	8082                	ret
    memmove(dst, (char*)src, len);
    80001aa6:	000a061b          	sext.w	a2,s4
    80001aaa:	85ce                	mv	a1,s3
    80001aac:	854a                	mv	a0,s2
    80001aae:	ffffe097          	auipc	ra,0xffffe
    80001ab2:	728080e7          	jalr	1832(ra) # 800001d6 <memmove>
    return 0;
    80001ab6:	8526                	mv	a0,s1
    80001ab8:	bff9                	j	80001a96 <either_copyin+0x32>

0000000080001aba <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    80001aba:	715d                	addi	sp,sp,-80
    80001abc:	e486                	sd	ra,72(sp)
    80001abe:	e0a2                	sd	s0,64(sp)
    80001ac0:	fc26                	sd	s1,56(sp)
    80001ac2:	f84a                	sd	s2,48(sp)
    80001ac4:	f44e                	sd	s3,40(sp)
    80001ac6:	f052                	sd	s4,32(sp)
    80001ac8:	ec56                	sd	s5,24(sp)
    80001aca:	e85a                	sd	s6,16(sp)
    80001acc:	e45e                	sd	s7,8(sp)
    80001ace:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    80001ad0:	00006517          	auipc	a0,0x6
    80001ad4:	54850513          	addi	a0,a0,1352 # 80008018 <etext+0x18>
    80001ad8:	00004097          	auipc	ra,0x4
    80001adc:	506080e7          	jalr	1286(ra) # 80005fde <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80001ae0:	0000d497          	auipc	s1,0xd
    80001ae4:	91848493          	addi	s1,s1,-1768 # 8000e3f8 <proc+0x158>
    80001ae8:	00013917          	auipc	s2,0x13
    80001aec:	b1090913          	addi	s2,s2,-1264 # 800145f8 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80001af0:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80001af2:	00006997          	auipc	s3,0x6
    80001af6:	74e98993          	addi	s3,s3,1870 # 80008240 <etext+0x240>
    printf("%d %s %s", p->pid, state, p->name);
    80001afa:	00006a97          	auipc	s5,0x6
    80001afe:	74ea8a93          	addi	s5,s5,1870 # 80008248 <etext+0x248>
    printf("\n");
    80001b02:	00006a17          	auipc	s4,0x6
    80001b06:	516a0a13          	addi	s4,s4,1302 # 80008018 <etext+0x18>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80001b0a:	00008b97          	auipc	s7,0x8
    80001b0e:	556b8b93          	addi	s7,s7,1366 # 8000a060 <states.0>
    80001b12:	a00d                	j	80001b34 <procdump+0x7a>
    printf("%d %s %s", p->pid, state, p->name);
    80001b14:	ed86a583          	lw	a1,-296(a3)
    80001b18:	8556                	mv	a0,s5
    80001b1a:	00004097          	auipc	ra,0x4
    80001b1e:	4c4080e7          	jalr	1220(ra) # 80005fde <printf>
    printf("\n");
    80001b22:	8552                	mv	a0,s4
    80001b24:	00004097          	auipc	ra,0x4
    80001b28:	4ba080e7          	jalr	1210(ra) # 80005fde <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80001b2c:	18848493          	addi	s1,s1,392
    80001b30:	03248263          	beq	s1,s2,80001b54 <procdump+0x9a>
    if(p->state == UNUSED)
    80001b34:	86a6                	mv	a3,s1
    80001b36:	ec04a783          	lw	a5,-320(s1)
    80001b3a:	dbed                	beqz	a5,80001b2c <procdump+0x72>
      state = "???";
    80001b3c:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80001b3e:	fcfb6be3          	bltu	s6,a5,80001b14 <procdump+0x5a>
    80001b42:	02079713          	slli	a4,a5,0x20
    80001b46:	01d75793          	srli	a5,a4,0x1d
    80001b4a:	97de                	add	a5,a5,s7
    80001b4c:	6390                	ld	a2,0(a5)
    80001b4e:	f279                	bnez	a2,80001b14 <procdump+0x5a>
      state = "???";
    80001b50:	864e                	mv	a2,s3
    80001b52:	b7c9                	j	80001b14 <procdump+0x5a>
  }
}
    80001b54:	60a6                	ld	ra,72(sp)
    80001b56:	6406                	ld	s0,64(sp)
    80001b58:	74e2                	ld	s1,56(sp)
    80001b5a:	7942                	ld	s2,48(sp)
    80001b5c:	79a2                	ld	s3,40(sp)
    80001b5e:	7a02                	ld	s4,32(sp)
    80001b60:	6ae2                	ld	s5,24(sp)
    80001b62:	6b42                	ld	s6,16(sp)
    80001b64:	6ba2                	ld	s7,8(sp)
    80001b66:	6161                	addi	sp,sp,80
    80001b68:	8082                	ret

0000000080001b6a <swtch>:
    80001b6a:	00153023          	sd	ra,0(a0)
    80001b6e:	00253423          	sd	sp,8(a0)
    80001b72:	e900                	sd	s0,16(a0)
    80001b74:	ed04                	sd	s1,24(a0)
    80001b76:	03253023          	sd	s2,32(a0)
    80001b7a:	03353423          	sd	s3,40(a0)
    80001b7e:	03453823          	sd	s4,48(a0)
    80001b82:	03553c23          	sd	s5,56(a0)
    80001b86:	05653023          	sd	s6,64(a0)
    80001b8a:	05753423          	sd	s7,72(a0)
    80001b8e:	05853823          	sd	s8,80(a0)
    80001b92:	05953c23          	sd	s9,88(a0)
    80001b96:	07a53023          	sd	s10,96(a0)
    80001b9a:	07b53423          	sd	s11,104(a0)
    80001b9e:	0005b083          	ld	ra,0(a1)
    80001ba2:	0085b103          	ld	sp,8(a1)
    80001ba6:	6980                	ld	s0,16(a1)
    80001ba8:	6d84                	ld	s1,24(a1)
    80001baa:	0205b903          	ld	s2,32(a1)
    80001bae:	0285b983          	ld	s3,40(a1)
    80001bb2:	0305ba03          	ld	s4,48(a1)
    80001bb6:	0385ba83          	ld	s5,56(a1)
    80001bba:	0405bb03          	ld	s6,64(a1)
    80001bbe:	0485bb83          	ld	s7,72(a1)
    80001bc2:	0505bc03          	ld	s8,80(a1)
    80001bc6:	0585bc83          	ld	s9,88(a1)
    80001bca:	0605bd03          	ld	s10,96(a1)
    80001bce:	0685bd83          	ld	s11,104(a1)
    80001bd2:	8082                	ret

0000000080001bd4 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80001bd4:	1141                	addi	sp,sp,-16
    80001bd6:	e406                	sd	ra,8(sp)
    80001bd8:	e022                	sd	s0,0(sp)
    80001bda:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80001bdc:	00006597          	auipc	a1,0x6
    80001be0:	6ac58593          	addi	a1,a1,1708 # 80008288 <etext+0x288>
    80001be4:	00013517          	auipc	a0,0x13
    80001be8:	8bc50513          	addi	a0,a0,-1860 # 800144a0 <tickslock>
    80001bec:	00005097          	auipc	ra,0x5
    80001bf0:	892080e7          	jalr	-1902(ra) # 8000647e <initlock>
}
    80001bf4:	60a2                	ld	ra,8(sp)
    80001bf6:	6402                	ld	s0,0(sp)
    80001bf8:	0141                	addi	sp,sp,16
    80001bfa:	8082                	ret

0000000080001bfc <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80001bfc:	1141                	addi	sp,sp,-16
    80001bfe:	e422                	sd	s0,8(sp)
    80001c00:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001c02:	00003797          	auipc	a5,0x3
    80001c06:	68e78793          	addi	a5,a5,1678 # 80005290 <kernelvec>
    80001c0a:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80001c0e:	6422                	ld	s0,8(sp)
    80001c10:	0141                	addi	sp,sp,16
    80001c12:	8082                	ret

0000000080001c14 <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    80001c14:	1141                	addi	sp,sp,-16
    80001c16:	e406                	sd	ra,8(sp)
    80001c18:	e022                	sd	s0,0(sp)
    80001c1a:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80001c1c:	fffff097          	auipc	ra,0xfffff
    80001c20:	2ea080e7          	jalr	746(ra) # 80000f06 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001c24:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001c28:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001c2a:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80001c2e:	00005697          	auipc	a3,0x5
    80001c32:	3d268693          	addi	a3,a3,978 # 80007000 <_trampoline>
    80001c36:	00005717          	auipc	a4,0x5
    80001c3a:	3ca70713          	addi	a4,a4,970 # 80007000 <_trampoline>
    80001c3e:	8f15                	sub	a4,a4,a3
    80001c40:	040007b7          	lui	a5,0x4000
    80001c44:	17fd                	addi	a5,a5,-1 # 3ffffff <_entry-0x7c000001>
    80001c46:	07b2                	slli	a5,a5,0xc
    80001c48:	973e                	add	a4,a4,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001c4a:	10571073          	csrw	stvec,a4
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80001c4e:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    80001c50:	18002673          	csrr	a2,satp
    80001c54:	e310                	sd	a2,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    80001c56:	6d30                	ld	a2,88(a0)
    80001c58:	6138                	ld	a4,64(a0)
    80001c5a:	6585                	lui	a1,0x1
    80001c5c:	972e                	add	a4,a4,a1
    80001c5e:	e618                	sd	a4,8(a2)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80001c60:	6d38                	ld	a4,88(a0)
    80001c62:	00000617          	auipc	a2,0x0
    80001c66:	13860613          	addi	a2,a2,312 # 80001d9a <usertrap>
    80001c6a:	eb10                	sd	a2,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    80001c6c:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    80001c6e:	8612                	mv	a2,tp
    80001c70:	f310                	sd	a2,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001c72:	10002773          	csrr	a4,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80001c76:	eff77713          	andi	a4,a4,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80001c7a:	02076713          	ori	a4,a4,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001c7e:	10071073          	csrw	sstatus,a4
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80001c82:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001c84:	6f18                	ld	a4,24(a4)
    80001c86:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    80001c8a:	6928                	ld	a0,80(a0)
    80001c8c:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001c8e:	00005717          	auipc	a4,0x5
    80001c92:	40e70713          	addi	a4,a4,1038 # 8000709c <userret>
    80001c96:	8f15                	sub	a4,a4,a3
    80001c98:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001c9a:	577d                	li	a4,-1
    80001c9c:	177e                	slli	a4,a4,0x3f
    80001c9e:	8d59                	or	a0,a0,a4
    80001ca0:	9782                	jalr	a5
}
    80001ca2:	60a2                	ld	ra,8(sp)
    80001ca4:	6402                	ld	s0,0(sp)
    80001ca6:	0141                	addi	sp,sp,16
    80001ca8:	8082                	ret

0000000080001caa <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80001caa:	1101                	addi	sp,sp,-32
    80001cac:	ec06                	sd	ra,24(sp)
    80001cae:	e822                	sd	s0,16(sp)
    80001cb0:	e426                	sd	s1,8(sp)
    80001cb2:	1000                	addi	s0,sp,32
  acquire(&tickslock);
    80001cb4:	00012497          	auipc	s1,0x12
    80001cb8:	7ec48493          	addi	s1,s1,2028 # 800144a0 <tickslock>
    80001cbc:	8526                	mv	a0,s1
    80001cbe:	00005097          	auipc	ra,0x5
    80001cc2:	850080e7          	jalr	-1968(ra) # 8000650e <acquire>
  ticks++;
    80001cc6:	0000c517          	auipc	a0,0xc
    80001cca:	17250513          	addi	a0,a0,370 # 8000de38 <ticks>
    80001cce:	411c                	lw	a5,0(a0)
    80001cd0:	2785                	addiw	a5,a5,1
    80001cd2:	c11c                	sw	a5,0(a0)
  wakeup(&ticks);
    80001cd4:	00000097          	auipc	ra,0x0
    80001cd8:	996080e7          	jalr	-1642(ra) # 8000166a <wakeup>
  release(&tickslock);
    80001cdc:	8526                	mv	a0,s1
    80001cde:	00005097          	auipc	ra,0x5
    80001ce2:	8e4080e7          	jalr	-1820(ra) # 800065c2 <release>
}
    80001ce6:	60e2                	ld	ra,24(sp)
    80001ce8:	6442                	ld	s0,16(sp)
    80001cea:	64a2                	ld	s1,8(sp)
    80001cec:	6105                	addi	sp,sp,32
    80001cee:	8082                	ret

0000000080001cf0 <devintr>:
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001cf0:	142027f3          	csrr	a5,scause
    // the SSIP bit in sip.
    w_sip(r_sip() & ~2);

    return 2;
  } else {
    return 0;
    80001cf4:	4501                	li	a0,0
  if((scause & 0x8000000000000000L) &&
    80001cf6:	0a07d163          	bgez	a5,80001d98 <devintr+0xa8>
{
    80001cfa:	1101                	addi	sp,sp,-32
    80001cfc:	ec06                	sd	ra,24(sp)
    80001cfe:	e822                	sd	s0,16(sp)
    80001d00:	1000                	addi	s0,sp,32
     (scause & 0xff) == 9){
    80001d02:	0ff7f713          	zext.b	a4,a5
  if((scause & 0x8000000000000000L) &&
    80001d06:	46a5                	li	a3,9
    80001d08:	00d70c63          	beq	a4,a3,80001d20 <devintr+0x30>
  } else if(scause == 0x8000000000000001L){
    80001d0c:	577d                	li	a4,-1
    80001d0e:	177e                	slli	a4,a4,0x3f
    80001d10:	0705                	addi	a4,a4,1
    return 0;
    80001d12:	4501                	li	a0,0
  } else if(scause == 0x8000000000000001L){
    80001d14:	06e78163          	beq	a5,a4,80001d76 <devintr+0x86>
  }
}
    80001d18:	60e2                	ld	ra,24(sp)
    80001d1a:	6442                	ld	s0,16(sp)
    80001d1c:	6105                	addi	sp,sp,32
    80001d1e:	8082                	ret
    80001d20:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    80001d22:	00003097          	auipc	ra,0x3
    80001d26:	67a080e7          	jalr	1658(ra) # 8000539c <plic_claim>
    80001d2a:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80001d2c:	47a9                	li	a5,10
    80001d2e:	00f50963          	beq	a0,a5,80001d40 <devintr+0x50>
    } else if(irq == VIRTIO0_IRQ){
    80001d32:	4785                	li	a5,1
    80001d34:	00f50b63          	beq	a0,a5,80001d4a <devintr+0x5a>
    return 1;
    80001d38:	4505                	li	a0,1
    } else if(irq){
    80001d3a:	ec89                	bnez	s1,80001d54 <devintr+0x64>
    80001d3c:	64a2                	ld	s1,8(sp)
    80001d3e:	bfe9                	j	80001d18 <devintr+0x28>
      uartintr();
    80001d40:	00004097          	auipc	ra,0x4
    80001d44:	6ee080e7          	jalr	1774(ra) # 8000642e <uartintr>
    if(irq)
    80001d48:	a839                	j	80001d66 <devintr+0x76>
      virtio_disk_intr();
    80001d4a:	00004097          	auipc	ra,0x4
    80001d4e:	b7c080e7          	jalr	-1156(ra) # 800058c6 <virtio_disk_intr>
    if(irq)
    80001d52:	a811                	j	80001d66 <devintr+0x76>
      printf("unexpected interrupt irq=%d\n", irq);
    80001d54:	85a6                	mv	a1,s1
    80001d56:	00006517          	auipc	a0,0x6
    80001d5a:	53a50513          	addi	a0,a0,1338 # 80008290 <etext+0x290>
    80001d5e:	00004097          	auipc	ra,0x4
    80001d62:	280080e7          	jalr	640(ra) # 80005fde <printf>
      plic_complete(irq);
    80001d66:	8526                	mv	a0,s1
    80001d68:	00003097          	auipc	ra,0x3
    80001d6c:	658080e7          	jalr	1624(ra) # 800053c0 <plic_complete>
    return 1;
    80001d70:	4505                	li	a0,1
    80001d72:	64a2                	ld	s1,8(sp)
    80001d74:	b755                	j	80001d18 <devintr+0x28>
    if(cpuid() == 0){
    80001d76:	fffff097          	auipc	ra,0xfffff
    80001d7a:	164080e7          	jalr	356(ra) # 80000eda <cpuid>
    80001d7e:	c901                	beqz	a0,80001d8e <devintr+0x9e>
  asm volatile("csrr %0, sip" : "=r" (x) );
    80001d80:	144027f3          	csrr	a5,sip
    w_sip(r_sip() & ~2);
    80001d84:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sip, %0" : : "r" (x));
    80001d86:	14479073          	csrw	sip,a5
    return 2;
    80001d8a:	4509                	li	a0,2
    80001d8c:	b771                	j	80001d18 <devintr+0x28>
      clockintr();
    80001d8e:	00000097          	auipc	ra,0x0
    80001d92:	f1c080e7          	jalr	-228(ra) # 80001caa <clockintr>
    80001d96:	b7ed                	j	80001d80 <devintr+0x90>
}
    80001d98:	8082                	ret

0000000080001d9a <usertrap>:
{
    80001d9a:	1101                	addi	sp,sp,-32
    80001d9c:	ec06                	sd	ra,24(sp)
    80001d9e:	e822                	sd	s0,16(sp)
    80001da0:	e426                	sd	s1,8(sp)
    80001da2:	e04a                	sd	s2,0(sp)
    80001da4:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001da6:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    80001daa:	1007f793          	andi	a5,a5,256
    80001dae:	e3b1                	bnez	a5,80001df2 <usertrap+0x58>
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001db0:	00003797          	auipc	a5,0x3
    80001db4:	4e078793          	addi	a5,a5,1248 # 80005290 <kernelvec>
    80001db8:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80001dbc:	fffff097          	auipc	ra,0xfffff
    80001dc0:	14a080e7          	jalr	330(ra) # 80000f06 <myproc>
    80001dc4:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80001dc6:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001dc8:	14102773          	csrr	a4,sepc
    80001dcc:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001dce:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    80001dd2:	47a1                	li	a5,8
    80001dd4:	02f70763          	beq	a4,a5,80001e02 <usertrap+0x68>
  } else if((which_dev = devintr()) != 0){
    80001dd8:	00000097          	auipc	ra,0x0
    80001ddc:	f18080e7          	jalr	-232(ra) # 80001cf0 <devintr>
    80001de0:	892a                	mv	s2,a0
    80001de2:	c92d                	beqz	a0,80001e54 <usertrap+0xba>
  if(killed(p))
    80001de4:	8526                	mv	a0,s1
    80001de6:	00000097          	auipc	ra,0x0
    80001dea:	ac8080e7          	jalr	-1336(ra) # 800018ae <killed>
    80001dee:	c555                	beqz	a0,80001e9a <usertrap+0x100>
    80001df0:	a045                	j	80001e90 <usertrap+0xf6>
    panic("usertrap: not from user mode");
    80001df2:	00006517          	auipc	a0,0x6
    80001df6:	4be50513          	addi	a0,a0,1214 # 800082b0 <etext+0x2b0>
    80001dfa:	00004097          	auipc	ra,0x4
    80001dfe:	192080e7          	jalr	402(ra) # 80005f8c <panic>
    if(killed(p))
    80001e02:	00000097          	auipc	ra,0x0
    80001e06:	aac080e7          	jalr	-1364(ra) # 800018ae <killed>
    80001e0a:	ed1d                	bnez	a0,80001e48 <usertrap+0xae>
    p->trapframe->epc += 4;
    80001e0c:	6cb8                	ld	a4,88(s1)
    80001e0e:	6f1c                	ld	a5,24(a4)
    80001e10:	0791                	addi	a5,a5,4
    80001e12:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e14:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001e18:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001e1c:	10079073          	csrw	sstatus,a5
    syscall();
    80001e20:	00000097          	auipc	ra,0x0
    80001e24:	31a080e7          	jalr	794(ra) # 8000213a <syscall>
  if(killed(p))
    80001e28:	8526                	mv	a0,s1
    80001e2a:	00000097          	auipc	ra,0x0
    80001e2e:	a84080e7          	jalr	-1404(ra) # 800018ae <killed>
    80001e32:	ed31                	bnez	a0,80001e8e <usertrap+0xf4>
  usertrapret();
    80001e34:	00000097          	auipc	ra,0x0
    80001e38:	de0080e7          	jalr	-544(ra) # 80001c14 <usertrapret>
}
    80001e3c:	60e2                	ld	ra,24(sp)
    80001e3e:	6442                	ld	s0,16(sp)
    80001e40:	64a2                	ld	s1,8(sp)
    80001e42:	6902                	ld	s2,0(sp)
    80001e44:	6105                	addi	sp,sp,32
    80001e46:	8082                	ret
      exit(-1);
    80001e48:	557d                	li	a0,-1
    80001e4a:	00000097          	auipc	ra,0x0
    80001e4e:	8f0080e7          	jalr	-1808(ra) # 8000173a <exit>
    80001e52:	bf6d                	j	80001e0c <usertrap+0x72>
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001e54:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause %p pid=%d\n", r_scause(), p->pid);
    80001e58:	5890                	lw	a2,48(s1)
    80001e5a:	00006517          	auipc	a0,0x6
    80001e5e:	47650513          	addi	a0,a0,1142 # 800082d0 <etext+0x2d0>
    80001e62:	00004097          	auipc	ra,0x4
    80001e66:	17c080e7          	jalr	380(ra) # 80005fde <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001e6a:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001e6e:	14302673          	csrr	a2,stval
    printf("            sepc=%p stval=%p\n", r_sepc(), r_stval());
    80001e72:	00006517          	auipc	a0,0x6
    80001e76:	48e50513          	addi	a0,a0,1166 # 80008300 <etext+0x300>
    80001e7a:	00004097          	auipc	ra,0x4
    80001e7e:	164080e7          	jalr	356(ra) # 80005fde <printf>
    setkilled(p);
    80001e82:	8526                	mv	a0,s1
    80001e84:	00000097          	auipc	ra,0x0
    80001e88:	9fe080e7          	jalr	-1538(ra) # 80001882 <setkilled>
    80001e8c:	bf71                	j	80001e28 <usertrap+0x8e>
  if(killed(p))
    80001e8e:	4901                	li	s2,0
    exit(-1);
    80001e90:	557d                	li	a0,-1
    80001e92:	00000097          	auipc	ra,0x0
    80001e96:	8a8080e7          	jalr	-1880(ra) # 8000173a <exit>
  if (which_dev == 2 &&
    80001e9a:	4789                	li	a5,2
    80001e9c:	f8f91ce3          	bne	s2,a5,80001e34 <usertrap+0x9a>
      p->alarm_inteval > 0 &&
    80001ea0:	1684a783          	lw	a5,360(s1)
  if (which_dev == 2 &&
    80001ea4:	00f05e63          	blez	a5,80001ec0 <usertrap+0x126>
      p->alarm_inteval > 0 &&
    80001ea8:	1704a703          	lw	a4,368(s1)
    80001eac:	eb11                	bnez	a4,80001ec0 <usertrap+0x126>
    p->alarm_ticks++;
    80001eae:	16c4a703          	lw	a4,364(s1)
    80001eb2:	2705                	addiw	a4,a4,1
    80001eb4:	0007069b          	sext.w	a3,a4
    80001eb8:	16e4a623          	sw	a4,364(s1)
    if (p->alarm_ticks >= p->alarm_inteval) {
    80001ebc:	00f6d763          	bge	a3,a5,80001eca <usertrap+0x130>
    yield();
    80001ec0:	fffff097          	auipc	ra,0xfffff
    80001ec4:	70a080e7          	jalr	1802(ra) # 800015ca <yield>
    80001ec8:	b7b5                	j	80001e34 <usertrap+0x9a>
      memmove(p->alarm_trapframe, p->trapframe, sizeof(struct trapframe));
    80001eca:	12000613          	li	a2,288
    80001ece:	6cac                	ld	a1,88(s1)
    80001ed0:	1804b503          	ld	a0,384(s1)
    80001ed4:	ffffe097          	auipc	ra,0xffffe
    80001ed8:	302080e7          	jalr	770(ra) # 800001d6 <memmove>
      p->trapframe->epc = (uint64)p->alarm_handler;
    80001edc:	6cbc                	ld	a5,88(s1)
    80001ede:	1784b703          	ld	a4,376(s1)
    80001ee2:	ef98                	sd	a4,24(a5)
      p->alarm_ticks = 0;
    80001ee4:	1604a623          	sw	zero,364(s1)
      p->alarm_armed = 1;
    80001ee8:	4785                	li	a5,1
    80001eea:	16f4a823          	sw	a5,368(s1)
    80001eee:	bfc9                	j	80001ec0 <usertrap+0x126>

0000000080001ef0 <kerneltrap>:
{
    80001ef0:	7179                	addi	sp,sp,-48
    80001ef2:	f406                	sd	ra,40(sp)
    80001ef4:	f022                	sd	s0,32(sp)
    80001ef6:	ec26                	sd	s1,24(sp)
    80001ef8:	e84a                	sd	s2,16(sp)
    80001efa:	e44e                	sd	s3,8(sp)
    80001efc:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001efe:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001f02:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001f06:	142029f3          	csrr	s3,scause
  if((sstatus & SSTATUS_SPP) == 0)
    80001f0a:	1004f793          	andi	a5,s1,256
    80001f0e:	cb85                	beqz	a5,80001f3e <kerneltrap+0x4e>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001f10:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001f14:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80001f16:	ef85                	bnez	a5,80001f4e <kerneltrap+0x5e>
  if((which_dev = devintr()) == 0){
    80001f18:	00000097          	auipc	ra,0x0
    80001f1c:	dd8080e7          	jalr	-552(ra) # 80001cf0 <devintr>
    80001f20:	cd1d                	beqz	a0,80001f5e <kerneltrap+0x6e>
  if(which_dev == 2 && myproc() != 0 && myproc()->state == RUNNING)
    80001f22:	4789                	li	a5,2
    80001f24:	06f50a63          	beq	a0,a5,80001f98 <kerneltrap+0xa8>
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001f28:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001f2c:	10049073          	csrw	sstatus,s1
}
    80001f30:	70a2                	ld	ra,40(sp)
    80001f32:	7402                	ld	s0,32(sp)
    80001f34:	64e2                	ld	s1,24(sp)
    80001f36:	6942                	ld	s2,16(sp)
    80001f38:	69a2                	ld	s3,8(sp)
    80001f3a:	6145                	addi	sp,sp,48
    80001f3c:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80001f3e:	00006517          	auipc	a0,0x6
    80001f42:	3e250513          	addi	a0,a0,994 # 80008320 <etext+0x320>
    80001f46:	00004097          	auipc	ra,0x4
    80001f4a:	046080e7          	jalr	70(ra) # 80005f8c <panic>
    panic("kerneltrap: interrupts enabled");
    80001f4e:	00006517          	auipc	a0,0x6
    80001f52:	3fa50513          	addi	a0,a0,1018 # 80008348 <etext+0x348>
    80001f56:	00004097          	auipc	ra,0x4
    80001f5a:	036080e7          	jalr	54(ra) # 80005f8c <panic>
    printf("scause %p\n", scause);
    80001f5e:	85ce                	mv	a1,s3
    80001f60:	00006517          	auipc	a0,0x6
    80001f64:	40850513          	addi	a0,a0,1032 # 80008368 <etext+0x368>
    80001f68:	00004097          	auipc	ra,0x4
    80001f6c:	076080e7          	jalr	118(ra) # 80005fde <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001f70:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001f74:	14302673          	csrr	a2,stval
    printf("sepc=%p stval=%p\n", r_sepc(), r_stval());
    80001f78:	00006517          	auipc	a0,0x6
    80001f7c:	40050513          	addi	a0,a0,1024 # 80008378 <etext+0x378>
    80001f80:	00004097          	auipc	ra,0x4
    80001f84:	05e080e7          	jalr	94(ra) # 80005fde <printf>
    panic("kerneltrap");
    80001f88:	00006517          	auipc	a0,0x6
    80001f8c:	40850513          	addi	a0,a0,1032 # 80008390 <etext+0x390>
    80001f90:	00004097          	auipc	ra,0x4
    80001f94:	ffc080e7          	jalr	-4(ra) # 80005f8c <panic>
  if(which_dev == 2 && myproc() != 0 && myproc()->state == RUNNING)
    80001f98:	fffff097          	auipc	ra,0xfffff
    80001f9c:	f6e080e7          	jalr	-146(ra) # 80000f06 <myproc>
    80001fa0:	d541                	beqz	a0,80001f28 <kerneltrap+0x38>
    80001fa2:	fffff097          	auipc	ra,0xfffff
    80001fa6:	f64080e7          	jalr	-156(ra) # 80000f06 <myproc>
    80001faa:	4d18                	lw	a4,24(a0)
    80001fac:	4791                	li	a5,4
    80001fae:	f6f71de3          	bne	a4,a5,80001f28 <kerneltrap+0x38>
    yield();
    80001fb2:	fffff097          	auipc	ra,0xfffff
    80001fb6:	618080e7          	jalr	1560(ra) # 800015ca <yield>
    80001fba:	b7bd                	j	80001f28 <kerneltrap+0x38>

0000000080001fbc <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80001fbc:	1101                	addi	sp,sp,-32
    80001fbe:	ec06                	sd	ra,24(sp)
    80001fc0:	e822                	sd	s0,16(sp)
    80001fc2:	e426                	sd	s1,8(sp)
    80001fc4:	1000                	addi	s0,sp,32
    80001fc6:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001fc8:	fffff097          	auipc	ra,0xfffff
    80001fcc:	f3e080e7          	jalr	-194(ra) # 80000f06 <myproc>
  switch (n) {
    80001fd0:	4795                	li	a5,5
    80001fd2:	0497e163          	bltu	a5,s1,80002014 <argraw+0x58>
    80001fd6:	048a                	slli	s1,s1,0x2
    80001fd8:	00008717          	auipc	a4,0x8
    80001fdc:	0b870713          	addi	a4,a4,184 # 8000a090 <states.0+0x30>
    80001fe0:	94ba                	add	s1,s1,a4
    80001fe2:	409c                	lw	a5,0(s1)
    80001fe4:	97ba                	add	a5,a5,a4
    80001fe6:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80001fe8:	6d3c                	ld	a5,88(a0)
    80001fea:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80001fec:	60e2                	ld	ra,24(sp)
    80001fee:	6442                	ld	s0,16(sp)
    80001ff0:	64a2                	ld	s1,8(sp)
    80001ff2:	6105                	addi	sp,sp,32
    80001ff4:	8082                	ret
    return p->trapframe->a1;
    80001ff6:	6d3c                	ld	a5,88(a0)
    80001ff8:	7fa8                	ld	a0,120(a5)
    80001ffa:	bfcd                	j	80001fec <argraw+0x30>
    return p->trapframe->a2;
    80001ffc:	6d3c                	ld	a5,88(a0)
    80001ffe:	63c8                	ld	a0,128(a5)
    80002000:	b7f5                	j	80001fec <argraw+0x30>
    return p->trapframe->a3;
    80002002:	6d3c                	ld	a5,88(a0)
    80002004:	67c8                	ld	a0,136(a5)
    80002006:	b7dd                	j	80001fec <argraw+0x30>
    return p->trapframe->a4;
    80002008:	6d3c                	ld	a5,88(a0)
    8000200a:	6bc8                	ld	a0,144(a5)
    8000200c:	b7c5                	j	80001fec <argraw+0x30>
    return p->trapframe->a5;
    8000200e:	6d3c                	ld	a5,88(a0)
    80002010:	6fc8                	ld	a0,152(a5)
    80002012:	bfe9                	j	80001fec <argraw+0x30>
  panic("argraw");
    80002014:	00006517          	auipc	a0,0x6
    80002018:	38c50513          	addi	a0,a0,908 # 800083a0 <etext+0x3a0>
    8000201c:	00004097          	auipc	ra,0x4
    80002020:	f70080e7          	jalr	-144(ra) # 80005f8c <panic>

0000000080002024 <fetchaddr>:
{
    80002024:	1101                	addi	sp,sp,-32
    80002026:	ec06                	sd	ra,24(sp)
    80002028:	e822                	sd	s0,16(sp)
    8000202a:	e426                	sd	s1,8(sp)
    8000202c:	e04a                	sd	s2,0(sp)
    8000202e:	1000                	addi	s0,sp,32
    80002030:	84aa                	mv	s1,a0
    80002032:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002034:	fffff097          	auipc	ra,0xfffff
    80002038:	ed2080e7          	jalr	-302(ra) # 80000f06 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    8000203c:	653c                	ld	a5,72(a0)
    8000203e:	02f4f863          	bgeu	s1,a5,8000206e <fetchaddr+0x4a>
    80002042:	00848713          	addi	a4,s1,8
    80002046:	02e7e663          	bltu	a5,a4,80002072 <fetchaddr+0x4e>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    8000204a:	46a1                	li	a3,8
    8000204c:	8626                	mv	a2,s1
    8000204e:	85ca                	mv	a1,s2
    80002050:	6928                	ld	a0,80(a0)
    80002052:	fffff097          	auipc	ra,0xfffff
    80002056:	bd8080e7          	jalr	-1064(ra) # 80000c2a <copyin>
    8000205a:	00a03533          	snez	a0,a0
    8000205e:	40a00533          	neg	a0,a0
}
    80002062:	60e2                	ld	ra,24(sp)
    80002064:	6442                	ld	s0,16(sp)
    80002066:	64a2                	ld	s1,8(sp)
    80002068:	6902                	ld	s2,0(sp)
    8000206a:	6105                	addi	sp,sp,32
    8000206c:	8082                	ret
    return -1;
    8000206e:	557d                	li	a0,-1
    80002070:	bfcd                	j	80002062 <fetchaddr+0x3e>
    80002072:	557d                	li	a0,-1
    80002074:	b7fd                	j	80002062 <fetchaddr+0x3e>

0000000080002076 <fetchstr>:
{
    80002076:	7179                	addi	sp,sp,-48
    80002078:	f406                	sd	ra,40(sp)
    8000207a:	f022                	sd	s0,32(sp)
    8000207c:	ec26                	sd	s1,24(sp)
    8000207e:	e84a                	sd	s2,16(sp)
    80002080:	e44e                	sd	s3,8(sp)
    80002082:	1800                	addi	s0,sp,48
    80002084:	892a                	mv	s2,a0
    80002086:	84ae                	mv	s1,a1
    80002088:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    8000208a:	fffff097          	auipc	ra,0xfffff
    8000208e:	e7c080e7          	jalr	-388(ra) # 80000f06 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80002092:	86ce                	mv	a3,s3
    80002094:	864a                	mv	a2,s2
    80002096:	85a6                	mv	a1,s1
    80002098:	6928                	ld	a0,80(a0)
    8000209a:	fffff097          	auipc	ra,0xfffff
    8000209e:	c1e080e7          	jalr	-994(ra) # 80000cb8 <copyinstr>
    800020a2:	00054e63          	bltz	a0,800020be <fetchstr+0x48>
  return strlen(buf);
    800020a6:	8526                	mv	a0,s1
    800020a8:	ffffe097          	auipc	ra,0xffffe
    800020ac:	246080e7          	jalr	582(ra) # 800002ee <strlen>
}
    800020b0:	70a2                	ld	ra,40(sp)
    800020b2:	7402                	ld	s0,32(sp)
    800020b4:	64e2                	ld	s1,24(sp)
    800020b6:	6942                	ld	s2,16(sp)
    800020b8:	69a2                	ld	s3,8(sp)
    800020ba:	6145                	addi	sp,sp,48
    800020bc:	8082                	ret
    return -1;
    800020be:	557d                	li	a0,-1
    800020c0:	bfc5                	j	800020b0 <fetchstr+0x3a>

00000000800020c2 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    800020c2:	1101                	addi	sp,sp,-32
    800020c4:	ec06                	sd	ra,24(sp)
    800020c6:	e822                	sd	s0,16(sp)
    800020c8:	e426                	sd	s1,8(sp)
    800020ca:	1000                	addi	s0,sp,32
    800020cc:	84ae                	mv	s1,a1
  *ip = argraw(n);
    800020ce:	00000097          	auipc	ra,0x0
    800020d2:	eee080e7          	jalr	-274(ra) # 80001fbc <argraw>
    800020d6:	c088                	sw	a0,0(s1)
}
    800020d8:	60e2                	ld	ra,24(sp)
    800020da:	6442                	ld	s0,16(sp)
    800020dc:	64a2                	ld	s1,8(sp)
    800020de:	6105                	addi	sp,sp,32
    800020e0:	8082                	ret

00000000800020e2 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    800020e2:	1101                	addi	sp,sp,-32
    800020e4:	ec06                	sd	ra,24(sp)
    800020e6:	e822                	sd	s0,16(sp)
    800020e8:	e426                	sd	s1,8(sp)
    800020ea:	1000                	addi	s0,sp,32
    800020ec:	84ae                	mv	s1,a1
  *ip = argraw(n);
    800020ee:	00000097          	auipc	ra,0x0
    800020f2:	ece080e7          	jalr	-306(ra) # 80001fbc <argraw>
    800020f6:	e088                	sd	a0,0(s1)
}
    800020f8:	60e2                	ld	ra,24(sp)
    800020fa:	6442                	ld	s0,16(sp)
    800020fc:	64a2                	ld	s1,8(sp)
    800020fe:	6105                	addi	sp,sp,32
    80002100:	8082                	ret

0000000080002102 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002102:	7179                	addi	sp,sp,-48
    80002104:	f406                	sd	ra,40(sp)
    80002106:	f022                	sd	s0,32(sp)
    80002108:	ec26                	sd	s1,24(sp)
    8000210a:	e84a                	sd	s2,16(sp)
    8000210c:	1800                	addi	s0,sp,48
    8000210e:	84ae                	mv	s1,a1
    80002110:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    80002112:	fd840593          	addi	a1,s0,-40
    80002116:	00000097          	auipc	ra,0x0
    8000211a:	fcc080e7          	jalr	-52(ra) # 800020e2 <argaddr>
  return fetchstr(addr, buf, max);
    8000211e:	864a                	mv	a2,s2
    80002120:	85a6                	mv	a1,s1
    80002122:	fd843503          	ld	a0,-40(s0)
    80002126:	00000097          	auipc	ra,0x0
    8000212a:	f50080e7          	jalr	-176(ra) # 80002076 <fetchstr>
}
    8000212e:	70a2                	ld	ra,40(sp)
    80002130:	7402                	ld	s0,32(sp)
    80002132:	64e2                	ld	s1,24(sp)
    80002134:	6942                	ld	s2,16(sp)
    80002136:	6145                	addi	sp,sp,48
    80002138:	8082                	ret

000000008000213a <syscall>:

};

void
syscall(void)
{
    8000213a:	1101                	addi	sp,sp,-32
    8000213c:	ec06                	sd	ra,24(sp)
    8000213e:	e822                	sd	s0,16(sp)
    80002140:	e426                	sd	s1,8(sp)
    80002142:	e04a                	sd	s2,0(sp)
    80002144:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002146:	fffff097          	auipc	ra,0xfffff
    8000214a:	dc0080e7          	jalr	-576(ra) # 80000f06 <myproc>
    8000214e:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002150:	05853903          	ld	s2,88(a0)
    80002154:	0a893783          	ld	a5,168(s2)
    80002158:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    8000215c:	37fd                	addiw	a5,a5,-1
    8000215e:	4759                	li	a4,22
    80002160:	00f76f63          	bltu	a4,a5,8000217e <syscall+0x44>
    80002164:	00369713          	slli	a4,a3,0x3
    80002168:	00008797          	auipc	a5,0x8
    8000216c:	f4078793          	addi	a5,a5,-192 # 8000a0a8 <syscalls>
    80002170:	97ba                	add	a5,a5,a4
    80002172:	639c                	ld	a5,0(a5)
    80002174:	c789                	beqz	a5,8000217e <syscall+0x44>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002176:	9782                	jalr	a5
    80002178:	06a93823          	sd	a0,112(s2)
    8000217c:	a839                	j	8000219a <syscall+0x60>
  } else {
    printf("%d %s: unknown sys call %d\n",
    8000217e:	15848613          	addi	a2,s1,344
    80002182:	588c                	lw	a1,48(s1)
    80002184:	00006517          	auipc	a0,0x6
    80002188:	22450513          	addi	a0,a0,548 # 800083a8 <etext+0x3a8>
    8000218c:	00004097          	auipc	ra,0x4
    80002190:	e52080e7          	jalr	-430(ra) # 80005fde <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80002194:	6cbc                	ld	a5,88(s1)
    80002196:	577d                	li	a4,-1
    80002198:	fbb8                	sd	a4,112(a5)
  }
}
    8000219a:	60e2                	ld	ra,24(sp)
    8000219c:	6442                	ld	s0,16(sp)
    8000219e:	64a2                	ld	s1,8(sp)
    800021a0:	6902                	ld	s2,0(sp)
    800021a2:	6105                	addi	sp,sp,32
    800021a4:	8082                	ret

00000000800021a6 <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    800021a6:	1101                	addi	sp,sp,-32
    800021a8:	ec06                	sd	ra,24(sp)
    800021aa:	e822                	sd	s0,16(sp)
    800021ac:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    800021ae:	fec40593          	addi	a1,s0,-20
    800021b2:	4501                	li	a0,0
    800021b4:	00000097          	auipc	ra,0x0
    800021b8:	f0e080e7          	jalr	-242(ra) # 800020c2 <argint>
  exit(n);
    800021bc:	fec42503          	lw	a0,-20(s0)
    800021c0:	fffff097          	auipc	ra,0xfffff
    800021c4:	57a080e7          	jalr	1402(ra) # 8000173a <exit>
  return 0;  // not reached
}
    800021c8:	4501                	li	a0,0
    800021ca:	60e2                	ld	ra,24(sp)
    800021cc:	6442                	ld	s0,16(sp)
    800021ce:	6105                	addi	sp,sp,32
    800021d0:	8082                	ret

00000000800021d2 <sys_getpid>:

uint64
sys_getpid(void)
{
    800021d2:	1141                	addi	sp,sp,-16
    800021d4:	e406                	sd	ra,8(sp)
    800021d6:	e022                	sd	s0,0(sp)
    800021d8:	0800                	addi	s0,sp,16
  return myproc()->pid;
    800021da:	fffff097          	auipc	ra,0xfffff
    800021de:	d2c080e7          	jalr	-724(ra) # 80000f06 <myproc>
}
    800021e2:	5908                	lw	a0,48(a0)
    800021e4:	60a2                	ld	ra,8(sp)
    800021e6:	6402                	ld	s0,0(sp)
    800021e8:	0141                	addi	sp,sp,16
    800021ea:	8082                	ret

00000000800021ec <sys_fork>:

uint64
sys_fork(void)
{
    800021ec:	1141                	addi	sp,sp,-16
    800021ee:	e406                	sd	ra,8(sp)
    800021f0:	e022                	sd	s0,0(sp)
    800021f2:	0800                	addi	s0,sp,16
  return fork();
    800021f4:	fffff097          	auipc	ra,0xfffff
    800021f8:	11e080e7          	jalr	286(ra) # 80001312 <fork>
}
    800021fc:	60a2                	ld	ra,8(sp)
    800021fe:	6402                	ld	s0,0(sp)
    80002200:	0141                	addi	sp,sp,16
    80002202:	8082                	ret

0000000080002204 <sys_wait>:

uint64
sys_wait(void)
{
    80002204:	1101                	addi	sp,sp,-32
    80002206:	ec06                	sd	ra,24(sp)
    80002208:	e822                	sd	s0,16(sp)
    8000220a:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    8000220c:	fe840593          	addi	a1,s0,-24
    80002210:	4501                	li	a0,0
    80002212:	00000097          	auipc	ra,0x0
    80002216:	ed0080e7          	jalr	-304(ra) # 800020e2 <argaddr>
  return wait(p);
    8000221a:	fe843503          	ld	a0,-24(s0)
    8000221e:	fffff097          	auipc	ra,0xfffff
    80002222:	6c2080e7          	jalr	1730(ra) # 800018e0 <wait>
}
    80002226:	60e2                	ld	ra,24(sp)
    80002228:	6442                	ld	s0,16(sp)
    8000222a:	6105                	addi	sp,sp,32
    8000222c:	8082                	ret

000000008000222e <sys_sbrk>:

uint64
sys_sbrk(void)
{
    8000222e:	7179                	addi	sp,sp,-48
    80002230:	f406                	sd	ra,40(sp)
    80002232:	f022                	sd	s0,32(sp)
    80002234:	ec26                	sd	s1,24(sp)
    80002236:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    80002238:	fdc40593          	addi	a1,s0,-36
    8000223c:	4501                	li	a0,0
    8000223e:	00000097          	auipc	ra,0x0
    80002242:	e84080e7          	jalr	-380(ra) # 800020c2 <argint>
  addr = myproc()->sz;
    80002246:	fffff097          	auipc	ra,0xfffff
    8000224a:	cc0080e7          	jalr	-832(ra) # 80000f06 <myproc>
    8000224e:	6524                	ld	s1,72(a0)
  if(growproc(n) < 0)
    80002250:	fdc42503          	lw	a0,-36(s0)
    80002254:	fffff097          	auipc	ra,0xfffff
    80002258:	062080e7          	jalr	98(ra) # 800012b6 <growproc>
    8000225c:	00054863          	bltz	a0,8000226c <sys_sbrk+0x3e>
    return -1;
  return addr;
}
    80002260:	8526                	mv	a0,s1
    80002262:	70a2                	ld	ra,40(sp)
    80002264:	7402                	ld	s0,32(sp)
    80002266:	64e2                	ld	s1,24(sp)
    80002268:	6145                	addi	sp,sp,48
    8000226a:	8082                	ret
    return -1;
    8000226c:	54fd                	li	s1,-1
    8000226e:	bfcd                	j	80002260 <sys_sbrk+0x32>

0000000080002270 <sys_sleep>:

uint64
sys_sleep(void)
{
    80002270:	7139                	addi	sp,sp,-64
    80002272:	fc06                	sd	ra,56(sp)
    80002274:	f822                	sd	s0,48(sp)
    80002276:	f04a                	sd	s2,32(sp)
    80002278:	0080                	addi	s0,sp,64
  backtrace();
    8000227a:	00004097          	auipc	ra,0x4
    8000227e:	c56080e7          	jalr	-938(ra) # 80005ed0 <backtrace>
  int n;
  uint ticks0;

  argint(0, &n);
    80002282:	fcc40593          	addi	a1,s0,-52
    80002286:	4501                	li	a0,0
    80002288:	00000097          	auipc	ra,0x0
    8000228c:	e3a080e7          	jalr	-454(ra) # 800020c2 <argint>
  if(n < 0)
    80002290:	fcc42783          	lw	a5,-52(s0)
    80002294:	0807c163          	bltz	a5,80002316 <sys_sleep+0xa6>
    n = 0;
  acquire(&tickslock);
    80002298:	00012517          	auipc	a0,0x12
    8000229c:	20850513          	addi	a0,a0,520 # 800144a0 <tickslock>
    800022a0:	00004097          	auipc	ra,0x4
    800022a4:	26e080e7          	jalr	622(ra) # 8000650e <acquire>
  ticks0 = ticks;
    800022a8:	0000c917          	auipc	s2,0xc
    800022ac:	b9092903          	lw	s2,-1136(s2) # 8000de38 <ticks>
  while(ticks - ticks0 < n){
    800022b0:	fcc42783          	lw	a5,-52(s0)
    800022b4:	c3b9                	beqz	a5,800022fa <sys_sleep+0x8a>
    800022b6:	f426                	sd	s1,40(sp)
    800022b8:	ec4e                	sd	s3,24(sp)
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    800022ba:	00012997          	auipc	s3,0x12
    800022be:	1e698993          	addi	s3,s3,486 # 800144a0 <tickslock>
    800022c2:	0000c497          	auipc	s1,0xc
    800022c6:	b7648493          	addi	s1,s1,-1162 # 8000de38 <ticks>
    if(killed(myproc())){
    800022ca:	fffff097          	auipc	ra,0xfffff
    800022ce:	c3c080e7          	jalr	-964(ra) # 80000f06 <myproc>
    800022d2:	fffff097          	auipc	ra,0xfffff
    800022d6:	5dc080e7          	jalr	1500(ra) # 800018ae <killed>
    800022da:	e129                	bnez	a0,8000231c <sys_sleep+0xac>
    sleep(&ticks, &tickslock);
    800022dc:	85ce                	mv	a1,s3
    800022de:	8526                	mv	a0,s1
    800022e0:	fffff097          	auipc	ra,0xfffff
    800022e4:	326080e7          	jalr	806(ra) # 80001606 <sleep>
  while(ticks - ticks0 < n){
    800022e8:	409c                	lw	a5,0(s1)
    800022ea:	412787bb          	subw	a5,a5,s2
    800022ee:	fcc42703          	lw	a4,-52(s0)
    800022f2:	fce7ece3          	bltu	a5,a4,800022ca <sys_sleep+0x5a>
    800022f6:	74a2                	ld	s1,40(sp)
    800022f8:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    800022fa:	00012517          	auipc	a0,0x12
    800022fe:	1a650513          	addi	a0,a0,422 # 800144a0 <tickslock>
    80002302:	00004097          	auipc	ra,0x4
    80002306:	2c0080e7          	jalr	704(ra) # 800065c2 <release>
  return 0;
    8000230a:	4501                	li	a0,0
}
    8000230c:	70e2                	ld	ra,56(sp)
    8000230e:	7442                	ld	s0,48(sp)
    80002310:	7902                	ld	s2,32(sp)
    80002312:	6121                	addi	sp,sp,64
    80002314:	8082                	ret
    n = 0;
    80002316:	fc042623          	sw	zero,-52(s0)
    8000231a:	bfbd                	j	80002298 <sys_sleep+0x28>
      release(&tickslock);
    8000231c:	00012517          	auipc	a0,0x12
    80002320:	18450513          	addi	a0,a0,388 # 800144a0 <tickslock>
    80002324:	00004097          	auipc	ra,0x4
    80002328:	29e080e7          	jalr	670(ra) # 800065c2 <release>
      return -1;
    8000232c:	557d                	li	a0,-1
    8000232e:	74a2                	ld	s1,40(sp)
    80002330:	69e2                	ld	s3,24(sp)
    80002332:	bfe9                	j	8000230c <sys_sleep+0x9c>

0000000080002334 <sys_kill>:

uint64
sys_kill(void)
{
    80002334:	1101                	addi	sp,sp,-32
    80002336:	ec06                	sd	ra,24(sp)
    80002338:	e822                	sd	s0,16(sp)
    8000233a:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    8000233c:	fec40593          	addi	a1,s0,-20
    80002340:	4501                	li	a0,0
    80002342:	00000097          	auipc	ra,0x0
    80002346:	d80080e7          	jalr	-640(ra) # 800020c2 <argint>
  return kill(pid);
    8000234a:	fec42503          	lw	a0,-20(s0)
    8000234e:	fffff097          	auipc	ra,0xfffff
    80002352:	4c2080e7          	jalr	1218(ra) # 80001810 <kill>
}
    80002356:	60e2                	ld	ra,24(sp)
    80002358:	6442                	ld	s0,16(sp)
    8000235a:	6105                	addi	sp,sp,32
    8000235c:	8082                	ret

000000008000235e <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    8000235e:	1101                	addi	sp,sp,-32
    80002360:	ec06                	sd	ra,24(sp)
    80002362:	e822                	sd	s0,16(sp)
    80002364:	e426                	sd	s1,8(sp)
    80002366:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002368:	00012517          	auipc	a0,0x12
    8000236c:	13850513          	addi	a0,a0,312 # 800144a0 <tickslock>
    80002370:	00004097          	auipc	ra,0x4
    80002374:	19e080e7          	jalr	414(ra) # 8000650e <acquire>
  xticks = ticks;
    80002378:	0000c497          	auipc	s1,0xc
    8000237c:	ac04a483          	lw	s1,-1344(s1) # 8000de38 <ticks>
  release(&tickslock);
    80002380:	00012517          	auipc	a0,0x12
    80002384:	12050513          	addi	a0,a0,288 # 800144a0 <tickslock>
    80002388:	00004097          	auipc	ra,0x4
    8000238c:	23a080e7          	jalr	570(ra) # 800065c2 <release>
  return xticks;
}
    80002390:	02049513          	slli	a0,s1,0x20
    80002394:	9101                	srli	a0,a0,0x20
    80002396:	60e2                	ld	ra,24(sp)
    80002398:	6442                	ld	s0,16(sp)
    8000239a:	64a2                	ld	s1,8(sp)
    8000239c:	6105                	addi	sp,sp,32
    8000239e:	8082                	ret

00000000800023a0 <sys_sigalarm>:
// 参数 inteval: 报警间隔（以时钟滴答为单位），0 表示取消报警。
// 参数 handler: 用户态报警处理函数的地址。
// 当进程消耗的 CPU 时间达到 inteval 个滴答时，内核将调用 handler。
uint64
sys_sigalarm(void)
{
    800023a0:	1101                	addi	sp,sp,-32
    800023a2:	ec06                	sd	ra,24(sp)
    800023a4:	e822                	sd	s0,16(sp)
    800023a6:	1000                	addi	s0,sp,32
  int inteval;
  uint64 handler;

  argint(0, &inteval);
    800023a8:	fec40593          	addi	a1,s0,-20
    800023ac:	4501                	li	a0,0
    800023ae:	00000097          	auipc	ra,0x0
    800023b2:	d14080e7          	jalr	-748(ra) # 800020c2 <argint>
  argaddr(1, &handler);
    800023b6:	fe040593          	addi	a1,s0,-32
    800023ba:	4505                	li	a0,1
    800023bc:	00000097          	auipc	ra,0x0
    800023c0:	d26080e7          	jalr	-730(ra) # 800020e2 <argaddr>

  struct proc *p = myproc();
    800023c4:	fffff097          	auipc	ra,0xfffff
    800023c8:	b42080e7          	jalr	-1214(ra) # 80000f06 <myproc>
  p->alarm_inteval = inteval;
    800023cc:	fec42783          	lw	a5,-20(s0)
    800023d0:	16f52423          	sw	a5,360(a0)
  p->alarm_handler = (void (*)(void))handler;
    800023d4:	fe043783          	ld	a5,-32(s0)
    800023d8:	16f53c23          	sd	a5,376(a0)
  p->alarm_ticks = 0;
    800023dc:	16052623          	sw	zero,364(a0)
  p->alarm_armed = 0;
    800023e0:	16052823          	sw	zero,368(a0)

  return 0;
}
    800023e4:	4501                	li	a0,0
    800023e6:	60e2                	ld	ra,24(sp)
    800023e8:	6442                	ld	s0,16(sp)
    800023ea:	6105                	addi	sp,sp,32
    800023ec:	8082                	ret

00000000800023ee <sys_sigreturn>:
// 恢复被中断的用户程序上下文（所有寄存器、PC），
// 并允许后续再次触发报警。
// 注意：必须返回保存的 a0 值，因为 syscall() 会将返回值
// 写入 p->trapframe->a0，覆盖刚才恢复的值。
uint64 sys_sigreturn(void)
{
    800023ee:	1101                	addi	sp,sp,-32
    800023f0:	ec06                	sd	ra,24(sp)
    800023f2:	e822                	sd	s0,16(sp)
    800023f4:	e426                	sd	s1,8(sp)
    800023f6:	e04a                	sd	s2,0(sp)
    800023f8:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    800023fa:	fffff097          	auipc	ra,0xfffff
    800023fe:	b0c080e7          	jalr	-1268(ra) # 80000f06 <myproc>
    80002402:	84aa                	mv	s1,a0
  // 先读取被中断时保存的 a0，memmove 会覆盖掉 trapframe
  uint64 saved_a0 = p->alarm_trapframe->a0;
    80002404:	18053583          	ld	a1,384(a0)
    80002408:	0705b903          	ld	s2,112(a1) # 1070 <_entry-0x7fffef90>
  // 恢复被中断时的完整寄存器现场
  memmove(p->trapframe, p->alarm_trapframe, sizeof(struct trapframe));
    8000240c:	12000613          	li	a2,288
    80002410:	6d28                	ld	a0,88(a0)
    80002412:	ffffe097          	auipc	ra,0xffffe
    80002416:	dc4080e7          	jalr	-572(ra) # 800001d6 <memmove>
  // 清除报警处理程序执行标志，允许再次触发
  p->alarm_armed = 0;
    8000241a:	1604a823          	sw	zero,368(s1)
  // 返回保存的 a0，使 syscall() 写入正确的 a0 值
  return saved_a0;
}
    8000241e:	854a                	mv	a0,s2
    80002420:	60e2                	ld	ra,24(sp)
    80002422:	6442                	ld	s0,16(sp)
    80002424:	64a2                	ld	s1,8(sp)
    80002426:	6902                	ld	s2,0(sp)
    80002428:	6105                	addi	sp,sp,32
    8000242a:	8082                	ret

000000008000242c <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    8000242c:	7179                	addi	sp,sp,-48
    8000242e:	f406                	sd	ra,40(sp)
    80002430:	f022                	sd	s0,32(sp)
    80002432:	ec26                	sd	s1,24(sp)
    80002434:	e84a                	sd	s2,16(sp)
    80002436:	e44e                	sd	s3,8(sp)
    80002438:	e052                	sd	s4,0(sp)
    8000243a:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    8000243c:	00006597          	auipc	a1,0x6
    80002440:	f8c58593          	addi	a1,a1,-116 # 800083c8 <etext+0x3c8>
    80002444:	00012517          	auipc	a0,0x12
    80002448:	07450513          	addi	a0,a0,116 # 800144b8 <bcache>
    8000244c:	00004097          	auipc	ra,0x4
    80002450:	032080e7          	jalr	50(ra) # 8000647e <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002454:	0001a797          	auipc	a5,0x1a
    80002458:	06478793          	addi	a5,a5,100 # 8001c4b8 <bcache+0x8000>
    8000245c:	0001a717          	auipc	a4,0x1a
    80002460:	2c470713          	addi	a4,a4,708 # 8001c720 <bcache+0x8268>
    80002464:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002468:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    8000246c:	00012497          	auipc	s1,0x12
    80002470:	06448493          	addi	s1,s1,100 # 800144d0 <bcache+0x18>
    b->next = bcache.head.next;
    80002474:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002476:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002478:	00006a17          	auipc	s4,0x6
    8000247c:	f58a0a13          	addi	s4,s4,-168 # 800083d0 <etext+0x3d0>
    b->next = bcache.head.next;
    80002480:	2b893783          	ld	a5,696(s2)
    80002484:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002486:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    8000248a:	85d2                	mv	a1,s4
    8000248c:	01048513          	addi	a0,s1,16
    80002490:	00001097          	auipc	ra,0x1
    80002494:	4e8080e7          	jalr	1256(ra) # 80003978 <initsleeplock>
    bcache.head.next->prev = b;
    80002498:	2b893783          	ld	a5,696(s2)
    8000249c:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    8000249e:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    800024a2:	45848493          	addi	s1,s1,1112
    800024a6:	fd349de3          	bne	s1,s3,80002480 <binit+0x54>
  }
}
    800024aa:	70a2                	ld	ra,40(sp)
    800024ac:	7402                	ld	s0,32(sp)
    800024ae:	64e2                	ld	s1,24(sp)
    800024b0:	6942                	ld	s2,16(sp)
    800024b2:	69a2                	ld	s3,8(sp)
    800024b4:	6a02                	ld	s4,0(sp)
    800024b6:	6145                	addi	sp,sp,48
    800024b8:	8082                	ret

00000000800024ba <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    800024ba:	7179                	addi	sp,sp,-48
    800024bc:	f406                	sd	ra,40(sp)
    800024be:	f022                	sd	s0,32(sp)
    800024c0:	ec26                	sd	s1,24(sp)
    800024c2:	e84a                	sd	s2,16(sp)
    800024c4:	e44e                	sd	s3,8(sp)
    800024c6:	1800                	addi	s0,sp,48
    800024c8:	892a                	mv	s2,a0
    800024ca:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    800024cc:	00012517          	auipc	a0,0x12
    800024d0:	fec50513          	addi	a0,a0,-20 # 800144b8 <bcache>
    800024d4:	00004097          	auipc	ra,0x4
    800024d8:	03a080e7          	jalr	58(ra) # 8000650e <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    800024dc:	0001a497          	auipc	s1,0x1a
    800024e0:	2944b483          	ld	s1,660(s1) # 8001c770 <bcache+0x82b8>
    800024e4:	0001a797          	auipc	a5,0x1a
    800024e8:	23c78793          	addi	a5,a5,572 # 8001c720 <bcache+0x8268>
    800024ec:	02f48f63          	beq	s1,a5,8000252a <bread+0x70>
    800024f0:	873e                	mv	a4,a5
    800024f2:	a021                	j	800024fa <bread+0x40>
    800024f4:	68a4                	ld	s1,80(s1)
    800024f6:	02e48a63          	beq	s1,a4,8000252a <bread+0x70>
    if(b->dev == dev && b->blockno == blockno){
    800024fa:	449c                	lw	a5,8(s1)
    800024fc:	ff279ce3          	bne	a5,s2,800024f4 <bread+0x3a>
    80002500:	44dc                	lw	a5,12(s1)
    80002502:	ff3799e3          	bne	a5,s3,800024f4 <bread+0x3a>
      b->refcnt++;
    80002506:	40bc                	lw	a5,64(s1)
    80002508:	2785                	addiw	a5,a5,1
    8000250a:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    8000250c:	00012517          	auipc	a0,0x12
    80002510:	fac50513          	addi	a0,a0,-84 # 800144b8 <bcache>
    80002514:	00004097          	auipc	ra,0x4
    80002518:	0ae080e7          	jalr	174(ra) # 800065c2 <release>
      acquiresleep(&b->lock);
    8000251c:	01048513          	addi	a0,s1,16
    80002520:	00001097          	auipc	ra,0x1
    80002524:	492080e7          	jalr	1170(ra) # 800039b2 <acquiresleep>
      return b;
    80002528:	a8b9                	j	80002586 <bread+0xcc>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    8000252a:	0001a497          	auipc	s1,0x1a
    8000252e:	23e4b483          	ld	s1,574(s1) # 8001c768 <bcache+0x82b0>
    80002532:	0001a797          	auipc	a5,0x1a
    80002536:	1ee78793          	addi	a5,a5,494 # 8001c720 <bcache+0x8268>
    8000253a:	00f48863          	beq	s1,a5,8000254a <bread+0x90>
    8000253e:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002540:	40bc                	lw	a5,64(s1)
    80002542:	cf81                	beqz	a5,8000255a <bread+0xa0>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002544:	64a4                	ld	s1,72(s1)
    80002546:	fee49de3          	bne	s1,a4,80002540 <bread+0x86>
  panic("bget: no buffers");
    8000254a:	00006517          	auipc	a0,0x6
    8000254e:	e8e50513          	addi	a0,a0,-370 # 800083d8 <etext+0x3d8>
    80002552:	00004097          	auipc	ra,0x4
    80002556:	a3a080e7          	jalr	-1478(ra) # 80005f8c <panic>
      b->dev = dev;
    8000255a:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    8000255e:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002562:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002566:	4785                	li	a5,1
    80002568:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    8000256a:	00012517          	auipc	a0,0x12
    8000256e:	f4e50513          	addi	a0,a0,-178 # 800144b8 <bcache>
    80002572:	00004097          	auipc	ra,0x4
    80002576:	050080e7          	jalr	80(ra) # 800065c2 <release>
      acquiresleep(&b->lock);
    8000257a:	01048513          	addi	a0,s1,16
    8000257e:	00001097          	auipc	ra,0x1
    80002582:	434080e7          	jalr	1076(ra) # 800039b2 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002586:	409c                	lw	a5,0(s1)
    80002588:	cb89                	beqz	a5,8000259a <bread+0xe0>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    8000258a:	8526                	mv	a0,s1
    8000258c:	70a2                	ld	ra,40(sp)
    8000258e:	7402                	ld	s0,32(sp)
    80002590:	64e2                	ld	s1,24(sp)
    80002592:	6942                	ld	s2,16(sp)
    80002594:	69a2                	ld	s3,8(sp)
    80002596:	6145                	addi	sp,sp,48
    80002598:	8082                	ret
    virtio_disk_rw(b, 0);
    8000259a:	4581                	li	a1,0
    8000259c:	8526                	mv	a0,s1
    8000259e:	00003097          	auipc	ra,0x3
    800025a2:	0fa080e7          	jalr	250(ra) # 80005698 <virtio_disk_rw>
    b->valid = 1;
    800025a6:	4785                	li	a5,1
    800025a8:	c09c                	sw	a5,0(s1)
  return b;
    800025aa:	b7c5                	j	8000258a <bread+0xd0>

00000000800025ac <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    800025ac:	1101                	addi	sp,sp,-32
    800025ae:	ec06                	sd	ra,24(sp)
    800025b0:	e822                	sd	s0,16(sp)
    800025b2:	e426                	sd	s1,8(sp)
    800025b4:	1000                	addi	s0,sp,32
    800025b6:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    800025b8:	0541                	addi	a0,a0,16
    800025ba:	00001097          	auipc	ra,0x1
    800025be:	492080e7          	jalr	1170(ra) # 80003a4c <holdingsleep>
    800025c2:	cd01                	beqz	a0,800025da <bwrite+0x2e>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    800025c4:	4585                	li	a1,1
    800025c6:	8526                	mv	a0,s1
    800025c8:	00003097          	auipc	ra,0x3
    800025cc:	0d0080e7          	jalr	208(ra) # 80005698 <virtio_disk_rw>
}
    800025d0:	60e2                	ld	ra,24(sp)
    800025d2:	6442                	ld	s0,16(sp)
    800025d4:	64a2                	ld	s1,8(sp)
    800025d6:	6105                	addi	sp,sp,32
    800025d8:	8082                	ret
    panic("bwrite");
    800025da:	00006517          	auipc	a0,0x6
    800025de:	e1650513          	addi	a0,a0,-490 # 800083f0 <etext+0x3f0>
    800025e2:	00004097          	auipc	ra,0x4
    800025e6:	9aa080e7          	jalr	-1622(ra) # 80005f8c <panic>

00000000800025ea <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    800025ea:	1101                	addi	sp,sp,-32
    800025ec:	ec06                	sd	ra,24(sp)
    800025ee:	e822                	sd	s0,16(sp)
    800025f0:	e426                	sd	s1,8(sp)
    800025f2:	e04a                	sd	s2,0(sp)
    800025f4:	1000                	addi	s0,sp,32
    800025f6:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    800025f8:	01050913          	addi	s2,a0,16
    800025fc:	854a                	mv	a0,s2
    800025fe:	00001097          	auipc	ra,0x1
    80002602:	44e080e7          	jalr	1102(ra) # 80003a4c <holdingsleep>
    80002606:	c925                	beqz	a0,80002676 <brelse+0x8c>
    panic("brelse");

  releasesleep(&b->lock);
    80002608:	854a                	mv	a0,s2
    8000260a:	00001097          	auipc	ra,0x1
    8000260e:	3fe080e7          	jalr	1022(ra) # 80003a08 <releasesleep>

  acquire(&bcache.lock);
    80002612:	00012517          	auipc	a0,0x12
    80002616:	ea650513          	addi	a0,a0,-346 # 800144b8 <bcache>
    8000261a:	00004097          	auipc	ra,0x4
    8000261e:	ef4080e7          	jalr	-268(ra) # 8000650e <acquire>
  b->refcnt--;
    80002622:	40bc                	lw	a5,64(s1)
    80002624:	37fd                	addiw	a5,a5,-1
    80002626:	0007871b          	sext.w	a4,a5
    8000262a:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    8000262c:	e71d                	bnez	a4,8000265a <brelse+0x70>
    // no one is waiting for it.
    b->next->prev = b->prev;
    8000262e:	68b8                	ld	a4,80(s1)
    80002630:	64bc                	ld	a5,72(s1)
    80002632:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002634:	68b8                	ld	a4,80(s1)
    80002636:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002638:	0001a797          	auipc	a5,0x1a
    8000263c:	e8078793          	addi	a5,a5,-384 # 8001c4b8 <bcache+0x8000>
    80002640:	2b87b703          	ld	a4,696(a5)
    80002644:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002646:	0001a717          	auipc	a4,0x1a
    8000264a:	0da70713          	addi	a4,a4,218 # 8001c720 <bcache+0x8268>
    8000264e:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002650:	2b87b703          	ld	a4,696(a5)
    80002654:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002656:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    8000265a:	00012517          	auipc	a0,0x12
    8000265e:	e5e50513          	addi	a0,a0,-418 # 800144b8 <bcache>
    80002662:	00004097          	auipc	ra,0x4
    80002666:	f60080e7          	jalr	-160(ra) # 800065c2 <release>
}
    8000266a:	60e2                	ld	ra,24(sp)
    8000266c:	6442                	ld	s0,16(sp)
    8000266e:	64a2                	ld	s1,8(sp)
    80002670:	6902                	ld	s2,0(sp)
    80002672:	6105                	addi	sp,sp,32
    80002674:	8082                	ret
    panic("brelse");
    80002676:	00006517          	auipc	a0,0x6
    8000267a:	d8250513          	addi	a0,a0,-638 # 800083f8 <etext+0x3f8>
    8000267e:	00004097          	auipc	ra,0x4
    80002682:	90e080e7          	jalr	-1778(ra) # 80005f8c <panic>

0000000080002686 <bpin>:

void
bpin(struct buf *b) {
    80002686:	1101                	addi	sp,sp,-32
    80002688:	ec06                	sd	ra,24(sp)
    8000268a:	e822                	sd	s0,16(sp)
    8000268c:	e426                	sd	s1,8(sp)
    8000268e:	1000                	addi	s0,sp,32
    80002690:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002692:	00012517          	auipc	a0,0x12
    80002696:	e2650513          	addi	a0,a0,-474 # 800144b8 <bcache>
    8000269a:	00004097          	auipc	ra,0x4
    8000269e:	e74080e7          	jalr	-396(ra) # 8000650e <acquire>
  b->refcnt++;
    800026a2:	40bc                	lw	a5,64(s1)
    800026a4:	2785                	addiw	a5,a5,1
    800026a6:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    800026a8:	00012517          	auipc	a0,0x12
    800026ac:	e1050513          	addi	a0,a0,-496 # 800144b8 <bcache>
    800026b0:	00004097          	auipc	ra,0x4
    800026b4:	f12080e7          	jalr	-238(ra) # 800065c2 <release>
}
    800026b8:	60e2                	ld	ra,24(sp)
    800026ba:	6442                	ld	s0,16(sp)
    800026bc:	64a2                	ld	s1,8(sp)
    800026be:	6105                	addi	sp,sp,32
    800026c0:	8082                	ret

00000000800026c2 <bunpin>:

void
bunpin(struct buf *b) {
    800026c2:	1101                	addi	sp,sp,-32
    800026c4:	ec06                	sd	ra,24(sp)
    800026c6:	e822                	sd	s0,16(sp)
    800026c8:	e426                	sd	s1,8(sp)
    800026ca:	1000                	addi	s0,sp,32
    800026cc:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    800026ce:	00012517          	auipc	a0,0x12
    800026d2:	dea50513          	addi	a0,a0,-534 # 800144b8 <bcache>
    800026d6:	00004097          	auipc	ra,0x4
    800026da:	e38080e7          	jalr	-456(ra) # 8000650e <acquire>
  b->refcnt--;
    800026de:	40bc                	lw	a5,64(s1)
    800026e0:	37fd                	addiw	a5,a5,-1
    800026e2:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    800026e4:	00012517          	auipc	a0,0x12
    800026e8:	dd450513          	addi	a0,a0,-556 # 800144b8 <bcache>
    800026ec:	00004097          	auipc	ra,0x4
    800026f0:	ed6080e7          	jalr	-298(ra) # 800065c2 <release>
}
    800026f4:	60e2                	ld	ra,24(sp)
    800026f6:	6442                	ld	s0,16(sp)
    800026f8:	64a2                	ld	s1,8(sp)
    800026fa:	6105                	addi	sp,sp,32
    800026fc:	8082                	ret

00000000800026fe <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    800026fe:	1101                	addi	sp,sp,-32
    80002700:	ec06                	sd	ra,24(sp)
    80002702:	e822                	sd	s0,16(sp)
    80002704:	e426                	sd	s1,8(sp)
    80002706:	e04a                	sd	s2,0(sp)
    80002708:	1000                	addi	s0,sp,32
    8000270a:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    8000270c:	00d5d59b          	srliw	a1,a1,0xd
    80002710:	0001a797          	auipc	a5,0x1a
    80002714:	4847a783          	lw	a5,1156(a5) # 8001cb94 <sb+0x1c>
    80002718:	9dbd                	addw	a1,a1,a5
    8000271a:	00000097          	auipc	ra,0x0
    8000271e:	da0080e7          	jalr	-608(ra) # 800024ba <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002722:	0074f713          	andi	a4,s1,7
    80002726:	4785                	li	a5,1
    80002728:	00e797bb          	sllw	a5,a5,a4
  if((bp->data[bi/8] & m) == 0)
    8000272c:	14ce                	slli	s1,s1,0x33
    8000272e:	90d9                	srli	s1,s1,0x36
    80002730:	00950733          	add	a4,a0,s1
    80002734:	05874703          	lbu	a4,88(a4)
    80002738:	00e7f6b3          	and	a3,a5,a4
    8000273c:	c69d                	beqz	a3,8000276a <bfree+0x6c>
    8000273e:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80002740:	94aa                	add	s1,s1,a0
    80002742:	fff7c793          	not	a5,a5
    80002746:	8f7d                	and	a4,a4,a5
    80002748:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    8000274c:	00001097          	auipc	ra,0x1
    80002750:	148080e7          	jalr	328(ra) # 80003894 <log_write>
  brelse(bp);
    80002754:	854a                	mv	a0,s2
    80002756:	00000097          	auipc	ra,0x0
    8000275a:	e94080e7          	jalr	-364(ra) # 800025ea <brelse>
}
    8000275e:	60e2                	ld	ra,24(sp)
    80002760:	6442                	ld	s0,16(sp)
    80002762:	64a2                	ld	s1,8(sp)
    80002764:	6902                	ld	s2,0(sp)
    80002766:	6105                	addi	sp,sp,32
    80002768:	8082                	ret
    panic("freeing free block");
    8000276a:	00006517          	auipc	a0,0x6
    8000276e:	c9650513          	addi	a0,a0,-874 # 80008400 <etext+0x400>
    80002772:	00004097          	auipc	ra,0x4
    80002776:	81a080e7          	jalr	-2022(ra) # 80005f8c <panic>

000000008000277a <balloc>:
{
    8000277a:	711d                	addi	sp,sp,-96
    8000277c:	ec86                	sd	ra,88(sp)
    8000277e:	e8a2                	sd	s0,80(sp)
    80002780:	e4a6                	sd	s1,72(sp)
    80002782:	1080                	addi	s0,sp,96
  for(b = 0; b < sb.size; b += BPB){
    80002784:	0001a797          	auipc	a5,0x1a
    80002788:	3f87a783          	lw	a5,1016(a5) # 8001cb7c <sb+0x4>
    8000278c:	10078f63          	beqz	a5,800028aa <balloc+0x130>
    80002790:	e0ca                	sd	s2,64(sp)
    80002792:	fc4e                	sd	s3,56(sp)
    80002794:	f852                	sd	s4,48(sp)
    80002796:	f456                	sd	s5,40(sp)
    80002798:	f05a                	sd	s6,32(sp)
    8000279a:	ec5e                	sd	s7,24(sp)
    8000279c:	e862                	sd	s8,16(sp)
    8000279e:	e466                	sd	s9,8(sp)
    800027a0:	8baa                	mv	s7,a0
    800027a2:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    800027a4:	0001ab17          	auipc	s6,0x1a
    800027a8:	3d4b0b13          	addi	s6,s6,980 # 8001cb78 <sb>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800027ac:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    800027ae:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800027b0:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    800027b2:	6c89                	lui	s9,0x2
    800027b4:	a061                	j	8000283c <balloc+0xc2>
        bp->data[bi/8] |= m;  // Mark block in use.
    800027b6:	97ca                	add	a5,a5,s2
    800027b8:	8e55                	or	a2,a2,a3
    800027ba:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    800027be:	854a                	mv	a0,s2
    800027c0:	00001097          	auipc	ra,0x1
    800027c4:	0d4080e7          	jalr	212(ra) # 80003894 <log_write>
        brelse(bp);
    800027c8:	854a                	mv	a0,s2
    800027ca:	00000097          	auipc	ra,0x0
    800027ce:	e20080e7          	jalr	-480(ra) # 800025ea <brelse>
  bp = bread(dev, bno);
    800027d2:	85a6                	mv	a1,s1
    800027d4:	855e                	mv	a0,s7
    800027d6:	00000097          	auipc	ra,0x0
    800027da:	ce4080e7          	jalr	-796(ra) # 800024ba <bread>
    800027de:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    800027e0:	40000613          	li	a2,1024
    800027e4:	4581                	li	a1,0
    800027e6:	05850513          	addi	a0,a0,88
    800027ea:	ffffe097          	auipc	ra,0xffffe
    800027ee:	990080e7          	jalr	-1648(ra) # 8000017a <memset>
  log_write(bp);
    800027f2:	854a                	mv	a0,s2
    800027f4:	00001097          	auipc	ra,0x1
    800027f8:	0a0080e7          	jalr	160(ra) # 80003894 <log_write>
  brelse(bp);
    800027fc:	854a                	mv	a0,s2
    800027fe:	00000097          	auipc	ra,0x0
    80002802:	dec080e7          	jalr	-532(ra) # 800025ea <brelse>
}
    80002806:	6906                	ld	s2,64(sp)
    80002808:	79e2                	ld	s3,56(sp)
    8000280a:	7a42                	ld	s4,48(sp)
    8000280c:	7aa2                	ld	s5,40(sp)
    8000280e:	7b02                	ld	s6,32(sp)
    80002810:	6be2                	ld	s7,24(sp)
    80002812:	6c42                	ld	s8,16(sp)
    80002814:	6ca2                	ld	s9,8(sp)
}
    80002816:	8526                	mv	a0,s1
    80002818:	60e6                	ld	ra,88(sp)
    8000281a:	6446                	ld	s0,80(sp)
    8000281c:	64a6                	ld	s1,72(sp)
    8000281e:	6125                	addi	sp,sp,96
    80002820:	8082                	ret
    brelse(bp);
    80002822:	854a                	mv	a0,s2
    80002824:	00000097          	auipc	ra,0x0
    80002828:	dc6080e7          	jalr	-570(ra) # 800025ea <brelse>
  for(b = 0; b < sb.size; b += BPB){
    8000282c:	015c87bb          	addw	a5,s9,s5
    80002830:	00078a9b          	sext.w	s5,a5
    80002834:	004b2703          	lw	a4,4(s6)
    80002838:	06eaf163          	bgeu	s5,a4,8000289a <balloc+0x120>
    bp = bread(dev, BBLOCK(b, sb));
    8000283c:	41fad79b          	sraiw	a5,s5,0x1f
    80002840:	0137d79b          	srliw	a5,a5,0x13
    80002844:	015787bb          	addw	a5,a5,s5
    80002848:	40d7d79b          	sraiw	a5,a5,0xd
    8000284c:	01cb2583          	lw	a1,28(s6)
    80002850:	9dbd                	addw	a1,a1,a5
    80002852:	855e                	mv	a0,s7
    80002854:	00000097          	auipc	ra,0x0
    80002858:	c66080e7          	jalr	-922(ra) # 800024ba <bread>
    8000285c:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    8000285e:	004b2503          	lw	a0,4(s6)
    80002862:	000a849b          	sext.w	s1,s5
    80002866:	8762                	mv	a4,s8
    80002868:	faa4fde3          	bgeu	s1,a0,80002822 <balloc+0xa8>
      m = 1 << (bi % 8);
    8000286c:	00777693          	andi	a3,a4,7
    80002870:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    80002874:	41f7579b          	sraiw	a5,a4,0x1f
    80002878:	01d7d79b          	srliw	a5,a5,0x1d
    8000287c:	9fb9                	addw	a5,a5,a4
    8000287e:	4037d79b          	sraiw	a5,a5,0x3
    80002882:	00f90633          	add	a2,s2,a5
    80002886:	05864603          	lbu	a2,88(a2)
    8000288a:	00c6f5b3          	and	a1,a3,a2
    8000288e:	d585                	beqz	a1,800027b6 <balloc+0x3c>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002890:	2705                	addiw	a4,a4,1
    80002892:	2485                	addiw	s1,s1,1
    80002894:	fd471ae3          	bne	a4,s4,80002868 <balloc+0xee>
    80002898:	b769                	j	80002822 <balloc+0xa8>
    8000289a:	6906                	ld	s2,64(sp)
    8000289c:	79e2                	ld	s3,56(sp)
    8000289e:	7a42                	ld	s4,48(sp)
    800028a0:	7aa2                	ld	s5,40(sp)
    800028a2:	7b02                	ld	s6,32(sp)
    800028a4:	6be2                	ld	s7,24(sp)
    800028a6:	6c42                	ld	s8,16(sp)
    800028a8:	6ca2                	ld	s9,8(sp)
  printf("balloc: out of blocks\n");
    800028aa:	00006517          	auipc	a0,0x6
    800028ae:	b6e50513          	addi	a0,a0,-1170 # 80008418 <etext+0x418>
    800028b2:	00003097          	auipc	ra,0x3
    800028b6:	72c080e7          	jalr	1836(ra) # 80005fde <printf>
  return 0;
    800028ba:	4481                	li	s1,0
    800028bc:	bfa9                	j	80002816 <balloc+0x9c>

00000000800028be <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    800028be:	7179                	addi	sp,sp,-48
    800028c0:	f406                	sd	ra,40(sp)
    800028c2:	f022                	sd	s0,32(sp)
    800028c4:	ec26                	sd	s1,24(sp)
    800028c6:	e84a                	sd	s2,16(sp)
    800028c8:	e44e                	sd	s3,8(sp)
    800028ca:	1800                	addi	s0,sp,48
    800028cc:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    800028ce:	47ad                	li	a5,11
    800028d0:	02b7e863          	bltu	a5,a1,80002900 <bmap+0x42>
    if((addr = ip->addrs[bn]) == 0){
    800028d4:	02059793          	slli	a5,a1,0x20
    800028d8:	01e7d593          	srli	a1,a5,0x1e
    800028dc:	00b504b3          	add	s1,a0,a1
    800028e0:	0504a903          	lw	s2,80(s1)
    800028e4:	08091263          	bnez	s2,80002968 <bmap+0xaa>
      addr = balloc(ip->dev);
    800028e8:	4108                	lw	a0,0(a0)
    800028ea:	00000097          	auipc	ra,0x0
    800028ee:	e90080e7          	jalr	-368(ra) # 8000277a <balloc>
    800028f2:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    800028f6:	06090963          	beqz	s2,80002968 <bmap+0xaa>
        return 0;
      ip->addrs[bn] = addr;
    800028fa:	0524a823          	sw	s2,80(s1)
    800028fe:	a0ad                	j	80002968 <bmap+0xaa>
    }
    return addr;
  }
  bn -= NDIRECT;
    80002900:	ff45849b          	addiw	s1,a1,-12
    80002904:	0004871b          	sext.w	a4,s1

  if(bn < NINDIRECT){
    80002908:	0ff00793          	li	a5,255
    8000290c:	08e7e863          	bltu	a5,a4,8000299c <bmap+0xde>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    80002910:	08052903          	lw	s2,128(a0)
    80002914:	00091f63          	bnez	s2,80002932 <bmap+0x74>
      addr = balloc(ip->dev);
    80002918:	4108                	lw	a0,0(a0)
    8000291a:	00000097          	auipc	ra,0x0
    8000291e:	e60080e7          	jalr	-416(ra) # 8000277a <balloc>
    80002922:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80002926:	04090163          	beqz	s2,80002968 <bmap+0xaa>
    8000292a:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    8000292c:	0929a023          	sw	s2,128(s3)
    80002930:	a011                	j	80002934 <bmap+0x76>
    80002932:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    80002934:	85ca                	mv	a1,s2
    80002936:	0009a503          	lw	a0,0(s3)
    8000293a:	00000097          	auipc	ra,0x0
    8000293e:	b80080e7          	jalr	-1152(ra) # 800024ba <bread>
    80002942:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80002944:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    80002948:	02049713          	slli	a4,s1,0x20
    8000294c:	01e75593          	srli	a1,a4,0x1e
    80002950:	00b784b3          	add	s1,a5,a1
    80002954:	0004a903          	lw	s2,0(s1)
    80002958:	02090063          	beqz	s2,80002978 <bmap+0xba>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    8000295c:	8552                	mv	a0,s4
    8000295e:	00000097          	auipc	ra,0x0
    80002962:	c8c080e7          	jalr	-884(ra) # 800025ea <brelse>
    return addr;
    80002966:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80002968:	854a                	mv	a0,s2
    8000296a:	70a2                	ld	ra,40(sp)
    8000296c:	7402                	ld	s0,32(sp)
    8000296e:	64e2                	ld	s1,24(sp)
    80002970:	6942                	ld	s2,16(sp)
    80002972:	69a2                	ld	s3,8(sp)
    80002974:	6145                	addi	sp,sp,48
    80002976:	8082                	ret
      addr = balloc(ip->dev);
    80002978:	0009a503          	lw	a0,0(s3)
    8000297c:	00000097          	auipc	ra,0x0
    80002980:	dfe080e7          	jalr	-514(ra) # 8000277a <balloc>
    80002984:	0005091b          	sext.w	s2,a0
      if(addr){
    80002988:	fc090ae3          	beqz	s2,8000295c <bmap+0x9e>
        a[bn] = addr;
    8000298c:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    80002990:	8552                	mv	a0,s4
    80002992:	00001097          	auipc	ra,0x1
    80002996:	f02080e7          	jalr	-254(ra) # 80003894 <log_write>
    8000299a:	b7c9                	j	8000295c <bmap+0x9e>
    8000299c:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    8000299e:	00006517          	auipc	a0,0x6
    800029a2:	a9250513          	addi	a0,a0,-1390 # 80008430 <etext+0x430>
    800029a6:	00003097          	auipc	ra,0x3
    800029aa:	5e6080e7          	jalr	1510(ra) # 80005f8c <panic>

00000000800029ae <iget>:
{
    800029ae:	7179                	addi	sp,sp,-48
    800029b0:	f406                	sd	ra,40(sp)
    800029b2:	f022                	sd	s0,32(sp)
    800029b4:	ec26                	sd	s1,24(sp)
    800029b6:	e84a                	sd	s2,16(sp)
    800029b8:	e44e                	sd	s3,8(sp)
    800029ba:	e052                	sd	s4,0(sp)
    800029bc:	1800                	addi	s0,sp,48
    800029be:	89aa                	mv	s3,a0
    800029c0:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    800029c2:	0001a517          	auipc	a0,0x1a
    800029c6:	1d650513          	addi	a0,a0,470 # 8001cb98 <itable>
    800029ca:	00004097          	auipc	ra,0x4
    800029ce:	b44080e7          	jalr	-1212(ra) # 8000650e <acquire>
  empty = 0;
    800029d2:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800029d4:	0001a497          	auipc	s1,0x1a
    800029d8:	1dc48493          	addi	s1,s1,476 # 8001cbb0 <itable+0x18>
    800029dc:	0001c697          	auipc	a3,0x1c
    800029e0:	c6468693          	addi	a3,a3,-924 # 8001e640 <log>
    800029e4:	a039                	j	800029f2 <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800029e6:	02090b63          	beqz	s2,80002a1c <iget+0x6e>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800029ea:	08848493          	addi	s1,s1,136
    800029ee:	02d48a63          	beq	s1,a3,80002a22 <iget+0x74>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    800029f2:	449c                	lw	a5,8(s1)
    800029f4:	fef059e3          	blez	a5,800029e6 <iget+0x38>
    800029f8:	4098                	lw	a4,0(s1)
    800029fa:	ff3716e3          	bne	a4,s3,800029e6 <iget+0x38>
    800029fe:	40d8                	lw	a4,4(s1)
    80002a00:	ff4713e3          	bne	a4,s4,800029e6 <iget+0x38>
      ip->ref++;
    80002a04:	2785                	addiw	a5,a5,1
    80002a06:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80002a08:	0001a517          	auipc	a0,0x1a
    80002a0c:	19050513          	addi	a0,a0,400 # 8001cb98 <itable>
    80002a10:	00004097          	auipc	ra,0x4
    80002a14:	bb2080e7          	jalr	-1102(ra) # 800065c2 <release>
      return ip;
    80002a18:	8926                	mv	s2,s1
    80002a1a:	a03d                	j	80002a48 <iget+0x9a>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80002a1c:	f7f9                	bnez	a5,800029ea <iget+0x3c>
      empty = ip;
    80002a1e:	8926                	mv	s2,s1
    80002a20:	b7e9                	j	800029ea <iget+0x3c>
  if(empty == 0)
    80002a22:	02090c63          	beqz	s2,80002a5a <iget+0xac>
  ip->dev = dev;
    80002a26:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    80002a2a:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    80002a2e:	4785                	li	a5,1
    80002a30:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    80002a34:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    80002a38:	0001a517          	auipc	a0,0x1a
    80002a3c:	16050513          	addi	a0,a0,352 # 8001cb98 <itable>
    80002a40:	00004097          	auipc	ra,0x4
    80002a44:	b82080e7          	jalr	-1150(ra) # 800065c2 <release>
}
    80002a48:	854a                	mv	a0,s2
    80002a4a:	70a2                	ld	ra,40(sp)
    80002a4c:	7402                	ld	s0,32(sp)
    80002a4e:	64e2                	ld	s1,24(sp)
    80002a50:	6942                	ld	s2,16(sp)
    80002a52:	69a2                	ld	s3,8(sp)
    80002a54:	6a02                	ld	s4,0(sp)
    80002a56:	6145                	addi	sp,sp,48
    80002a58:	8082                	ret
    panic("iget: no inodes");
    80002a5a:	00006517          	auipc	a0,0x6
    80002a5e:	9ee50513          	addi	a0,a0,-1554 # 80008448 <etext+0x448>
    80002a62:	00003097          	auipc	ra,0x3
    80002a66:	52a080e7          	jalr	1322(ra) # 80005f8c <panic>

0000000080002a6a <fsinit>:
fsinit(int dev) {
    80002a6a:	7179                	addi	sp,sp,-48
    80002a6c:	f406                	sd	ra,40(sp)
    80002a6e:	f022                	sd	s0,32(sp)
    80002a70:	ec26                	sd	s1,24(sp)
    80002a72:	e84a                	sd	s2,16(sp)
    80002a74:	e44e                	sd	s3,8(sp)
    80002a76:	1800                	addi	s0,sp,48
    80002a78:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80002a7a:	4585                	li	a1,1
    80002a7c:	00000097          	auipc	ra,0x0
    80002a80:	a3e080e7          	jalr	-1474(ra) # 800024ba <bread>
    80002a84:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80002a86:	0001a997          	auipc	s3,0x1a
    80002a8a:	0f298993          	addi	s3,s3,242 # 8001cb78 <sb>
    80002a8e:	02000613          	li	a2,32
    80002a92:	05850593          	addi	a1,a0,88
    80002a96:	854e                	mv	a0,s3
    80002a98:	ffffd097          	auipc	ra,0xffffd
    80002a9c:	73e080e7          	jalr	1854(ra) # 800001d6 <memmove>
  brelse(bp);
    80002aa0:	8526                	mv	a0,s1
    80002aa2:	00000097          	auipc	ra,0x0
    80002aa6:	b48080e7          	jalr	-1208(ra) # 800025ea <brelse>
  if(sb.magic != FSMAGIC)
    80002aaa:	0009a703          	lw	a4,0(s3)
    80002aae:	102037b7          	lui	a5,0x10203
    80002ab2:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80002ab6:	02f71263          	bne	a4,a5,80002ada <fsinit+0x70>
  initlog(dev, &sb);
    80002aba:	0001a597          	auipc	a1,0x1a
    80002abe:	0be58593          	addi	a1,a1,190 # 8001cb78 <sb>
    80002ac2:	854a                	mv	a0,s2
    80002ac4:	00001097          	auipc	ra,0x1
    80002ac8:	b60080e7          	jalr	-1184(ra) # 80003624 <initlog>
}
    80002acc:	70a2                	ld	ra,40(sp)
    80002ace:	7402                	ld	s0,32(sp)
    80002ad0:	64e2                	ld	s1,24(sp)
    80002ad2:	6942                	ld	s2,16(sp)
    80002ad4:	69a2                	ld	s3,8(sp)
    80002ad6:	6145                	addi	sp,sp,48
    80002ad8:	8082                	ret
    panic("invalid file system");
    80002ada:	00006517          	auipc	a0,0x6
    80002ade:	97e50513          	addi	a0,a0,-1666 # 80008458 <etext+0x458>
    80002ae2:	00003097          	auipc	ra,0x3
    80002ae6:	4aa080e7          	jalr	1194(ra) # 80005f8c <panic>

0000000080002aea <iinit>:
{
    80002aea:	7179                	addi	sp,sp,-48
    80002aec:	f406                	sd	ra,40(sp)
    80002aee:	f022                	sd	s0,32(sp)
    80002af0:	ec26                	sd	s1,24(sp)
    80002af2:	e84a                	sd	s2,16(sp)
    80002af4:	e44e                	sd	s3,8(sp)
    80002af6:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80002af8:	00006597          	auipc	a1,0x6
    80002afc:	97858593          	addi	a1,a1,-1672 # 80008470 <etext+0x470>
    80002b00:	0001a517          	auipc	a0,0x1a
    80002b04:	09850513          	addi	a0,a0,152 # 8001cb98 <itable>
    80002b08:	00004097          	auipc	ra,0x4
    80002b0c:	976080e7          	jalr	-1674(ra) # 8000647e <initlock>
  for(i = 0; i < NINODE; i++) {
    80002b10:	0001a497          	auipc	s1,0x1a
    80002b14:	0b048493          	addi	s1,s1,176 # 8001cbc0 <itable+0x28>
    80002b18:	0001c997          	auipc	s3,0x1c
    80002b1c:	b3898993          	addi	s3,s3,-1224 # 8001e650 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    80002b20:	00006917          	auipc	s2,0x6
    80002b24:	95890913          	addi	s2,s2,-1704 # 80008478 <etext+0x478>
    80002b28:	85ca                	mv	a1,s2
    80002b2a:	8526                	mv	a0,s1
    80002b2c:	00001097          	auipc	ra,0x1
    80002b30:	e4c080e7          	jalr	-436(ra) # 80003978 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    80002b34:	08848493          	addi	s1,s1,136
    80002b38:	ff3498e3          	bne	s1,s3,80002b28 <iinit+0x3e>
}
    80002b3c:	70a2                	ld	ra,40(sp)
    80002b3e:	7402                	ld	s0,32(sp)
    80002b40:	64e2                	ld	s1,24(sp)
    80002b42:	6942                	ld	s2,16(sp)
    80002b44:	69a2                	ld	s3,8(sp)
    80002b46:	6145                	addi	sp,sp,48
    80002b48:	8082                	ret

0000000080002b4a <ialloc>:
{
    80002b4a:	7139                	addi	sp,sp,-64
    80002b4c:	fc06                	sd	ra,56(sp)
    80002b4e:	f822                	sd	s0,48(sp)
    80002b50:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    80002b52:	0001a717          	auipc	a4,0x1a
    80002b56:	03272703          	lw	a4,50(a4) # 8001cb84 <sb+0xc>
    80002b5a:	4785                	li	a5,1
    80002b5c:	06e7f463          	bgeu	a5,a4,80002bc4 <ialloc+0x7a>
    80002b60:	f426                	sd	s1,40(sp)
    80002b62:	f04a                	sd	s2,32(sp)
    80002b64:	ec4e                	sd	s3,24(sp)
    80002b66:	e852                	sd	s4,16(sp)
    80002b68:	e456                	sd	s5,8(sp)
    80002b6a:	e05a                	sd	s6,0(sp)
    80002b6c:	8aaa                	mv	s5,a0
    80002b6e:	8b2e                	mv	s6,a1
    80002b70:	4905                	li	s2,1
    bp = bread(dev, IBLOCK(inum, sb));
    80002b72:	0001aa17          	auipc	s4,0x1a
    80002b76:	006a0a13          	addi	s4,s4,6 # 8001cb78 <sb>
    80002b7a:	00495593          	srli	a1,s2,0x4
    80002b7e:	018a2783          	lw	a5,24(s4)
    80002b82:	9dbd                	addw	a1,a1,a5
    80002b84:	8556                	mv	a0,s5
    80002b86:	00000097          	auipc	ra,0x0
    80002b8a:	934080e7          	jalr	-1740(ra) # 800024ba <bread>
    80002b8e:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    80002b90:	05850993          	addi	s3,a0,88
    80002b94:	00f97793          	andi	a5,s2,15
    80002b98:	079a                	slli	a5,a5,0x6
    80002b9a:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    80002b9c:	00099783          	lh	a5,0(s3)
    80002ba0:	cf9d                	beqz	a5,80002bde <ialloc+0x94>
    brelse(bp);
    80002ba2:	00000097          	auipc	ra,0x0
    80002ba6:	a48080e7          	jalr	-1464(ra) # 800025ea <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    80002baa:	0905                	addi	s2,s2,1
    80002bac:	00ca2703          	lw	a4,12(s4)
    80002bb0:	0009079b          	sext.w	a5,s2
    80002bb4:	fce7e3e3          	bltu	a5,a4,80002b7a <ialloc+0x30>
    80002bb8:	74a2                	ld	s1,40(sp)
    80002bba:	7902                	ld	s2,32(sp)
    80002bbc:	69e2                	ld	s3,24(sp)
    80002bbe:	6a42                	ld	s4,16(sp)
    80002bc0:	6aa2                	ld	s5,8(sp)
    80002bc2:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    80002bc4:	00006517          	auipc	a0,0x6
    80002bc8:	8bc50513          	addi	a0,a0,-1860 # 80008480 <etext+0x480>
    80002bcc:	00003097          	auipc	ra,0x3
    80002bd0:	412080e7          	jalr	1042(ra) # 80005fde <printf>
  return 0;
    80002bd4:	4501                	li	a0,0
}
    80002bd6:	70e2                	ld	ra,56(sp)
    80002bd8:	7442                	ld	s0,48(sp)
    80002bda:	6121                	addi	sp,sp,64
    80002bdc:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80002bde:	04000613          	li	a2,64
    80002be2:	4581                	li	a1,0
    80002be4:	854e                	mv	a0,s3
    80002be6:	ffffd097          	auipc	ra,0xffffd
    80002bea:	594080e7          	jalr	1428(ra) # 8000017a <memset>
      dip->type = type;
    80002bee:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    80002bf2:	8526                	mv	a0,s1
    80002bf4:	00001097          	auipc	ra,0x1
    80002bf8:	ca0080e7          	jalr	-864(ra) # 80003894 <log_write>
      brelse(bp);
    80002bfc:	8526                	mv	a0,s1
    80002bfe:	00000097          	auipc	ra,0x0
    80002c02:	9ec080e7          	jalr	-1556(ra) # 800025ea <brelse>
      return iget(dev, inum);
    80002c06:	0009059b          	sext.w	a1,s2
    80002c0a:	8556                	mv	a0,s5
    80002c0c:	00000097          	auipc	ra,0x0
    80002c10:	da2080e7          	jalr	-606(ra) # 800029ae <iget>
    80002c14:	74a2                	ld	s1,40(sp)
    80002c16:	7902                	ld	s2,32(sp)
    80002c18:	69e2                	ld	s3,24(sp)
    80002c1a:	6a42                	ld	s4,16(sp)
    80002c1c:	6aa2                	ld	s5,8(sp)
    80002c1e:	6b02                	ld	s6,0(sp)
    80002c20:	bf5d                	j	80002bd6 <ialloc+0x8c>

0000000080002c22 <iupdate>:
{
    80002c22:	1101                	addi	sp,sp,-32
    80002c24:	ec06                	sd	ra,24(sp)
    80002c26:	e822                	sd	s0,16(sp)
    80002c28:	e426                	sd	s1,8(sp)
    80002c2a:	e04a                	sd	s2,0(sp)
    80002c2c:	1000                	addi	s0,sp,32
    80002c2e:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80002c30:	415c                	lw	a5,4(a0)
    80002c32:	0047d79b          	srliw	a5,a5,0x4
    80002c36:	0001a597          	auipc	a1,0x1a
    80002c3a:	f5a5a583          	lw	a1,-166(a1) # 8001cb90 <sb+0x18>
    80002c3e:	9dbd                	addw	a1,a1,a5
    80002c40:	4108                	lw	a0,0(a0)
    80002c42:	00000097          	auipc	ra,0x0
    80002c46:	878080e7          	jalr	-1928(ra) # 800024ba <bread>
    80002c4a:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    80002c4c:	05850793          	addi	a5,a0,88
    80002c50:	40d8                	lw	a4,4(s1)
    80002c52:	8b3d                	andi	a4,a4,15
    80002c54:	071a                	slli	a4,a4,0x6
    80002c56:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    80002c58:	04449703          	lh	a4,68(s1)
    80002c5c:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    80002c60:	04649703          	lh	a4,70(s1)
    80002c64:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    80002c68:	04849703          	lh	a4,72(s1)
    80002c6c:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    80002c70:	04a49703          	lh	a4,74(s1)
    80002c74:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    80002c78:	44f8                	lw	a4,76(s1)
    80002c7a:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80002c7c:	03400613          	li	a2,52
    80002c80:	05048593          	addi	a1,s1,80
    80002c84:	00c78513          	addi	a0,a5,12
    80002c88:	ffffd097          	auipc	ra,0xffffd
    80002c8c:	54e080e7          	jalr	1358(ra) # 800001d6 <memmove>
  log_write(bp);
    80002c90:	854a                	mv	a0,s2
    80002c92:	00001097          	auipc	ra,0x1
    80002c96:	c02080e7          	jalr	-1022(ra) # 80003894 <log_write>
  brelse(bp);
    80002c9a:	854a                	mv	a0,s2
    80002c9c:	00000097          	auipc	ra,0x0
    80002ca0:	94e080e7          	jalr	-1714(ra) # 800025ea <brelse>
}
    80002ca4:	60e2                	ld	ra,24(sp)
    80002ca6:	6442                	ld	s0,16(sp)
    80002ca8:	64a2                	ld	s1,8(sp)
    80002caa:	6902                	ld	s2,0(sp)
    80002cac:	6105                	addi	sp,sp,32
    80002cae:	8082                	ret

0000000080002cb0 <idup>:
{
    80002cb0:	1101                	addi	sp,sp,-32
    80002cb2:	ec06                	sd	ra,24(sp)
    80002cb4:	e822                	sd	s0,16(sp)
    80002cb6:	e426                	sd	s1,8(sp)
    80002cb8:	1000                	addi	s0,sp,32
    80002cba:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80002cbc:	0001a517          	auipc	a0,0x1a
    80002cc0:	edc50513          	addi	a0,a0,-292 # 8001cb98 <itable>
    80002cc4:	00004097          	auipc	ra,0x4
    80002cc8:	84a080e7          	jalr	-1974(ra) # 8000650e <acquire>
  ip->ref++;
    80002ccc:	449c                	lw	a5,8(s1)
    80002cce:	2785                	addiw	a5,a5,1
    80002cd0:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80002cd2:	0001a517          	auipc	a0,0x1a
    80002cd6:	ec650513          	addi	a0,a0,-314 # 8001cb98 <itable>
    80002cda:	00004097          	auipc	ra,0x4
    80002cde:	8e8080e7          	jalr	-1816(ra) # 800065c2 <release>
}
    80002ce2:	8526                	mv	a0,s1
    80002ce4:	60e2                	ld	ra,24(sp)
    80002ce6:	6442                	ld	s0,16(sp)
    80002ce8:	64a2                	ld	s1,8(sp)
    80002cea:	6105                	addi	sp,sp,32
    80002cec:	8082                	ret

0000000080002cee <ilock>:
{
    80002cee:	1101                	addi	sp,sp,-32
    80002cf0:	ec06                	sd	ra,24(sp)
    80002cf2:	e822                	sd	s0,16(sp)
    80002cf4:	e426                	sd	s1,8(sp)
    80002cf6:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    80002cf8:	c10d                	beqz	a0,80002d1a <ilock+0x2c>
    80002cfa:	84aa                	mv	s1,a0
    80002cfc:	451c                	lw	a5,8(a0)
    80002cfe:	00f05e63          	blez	a5,80002d1a <ilock+0x2c>
  acquiresleep(&ip->lock);
    80002d02:	0541                	addi	a0,a0,16
    80002d04:	00001097          	auipc	ra,0x1
    80002d08:	cae080e7          	jalr	-850(ra) # 800039b2 <acquiresleep>
  if(ip->valid == 0){
    80002d0c:	40bc                	lw	a5,64(s1)
    80002d0e:	cf99                	beqz	a5,80002d2c <ilock+0x3e>
}
    80002d10:	60e2                	ld	ra,24(sp)
    80002d12:	6442                	ld	s0,16(sp)
    80002d14:	64a2                	ld	s1,8(sp)
    80002d16:	6105                	addi	sp,sp,32
    80002d18:	8082                	ret
    80002d1a:	e04a                	sd	s2,0(sp)
    panic("ilock");
    80002d1c:	00005517          	auipc	a0,0x5
    80002d20:	77c50513          	addi	a0,a0,1916 # 80008498 <etext+0x498>
    80002d24:	00003097          	auipc	ra,0x3
    80002d28:	268080e7          	jalr	616(ra) # 80005f8c <panic>
    80002d2c:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80002d2e:	40dc                	lw	a5,4(s1)
    80002d30:	0047d79b          	srliw	a5,a5,0x4
    80002d34:	0001a597          	auipc	a1,0x1a
    80002d38:	e5c5a583          	lw	a1,-420(a1) # 8001cb90 <sb+0x18>
    80002d3c:	9dbd                	addw	a1,a1,a5
    80002d3e:	4088                	lw	a0,0(s1)
    80002d40:	fffff097          	auipc	ra,0xfffff
    80002d44:	77a080e7          	jalr	1914(ra) # 800024ba <bread>
    80002d48:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    80002d4a:	05850593          	addi	a1,a0,88
    80002d4e:	40dc                	lw	a5,4(s1)
    80002d50:	8bbd                	andi	a5,a5,15
    80002d52:	079a                	slli	a5,a5,0x6
    80002d54:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80002d56:	00059783          	lh	a5,0(a1)
    80002d5a:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    80002d5e:	00259783          	lh	a5,2(a1)
    80002d62:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80002d66:	00459783          	lh	a5,4(a1)
    80002d6a:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    80002d6e:	00659783          	lh	a5,6(a1)
    80002d72:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80002d76:	459c                	lw	a5,8(a1)
    80002d78:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80002d7a:	03400613          	li	a2,52
    80002d7e:	05b1                	addi	a1,a1,12
    80002d80:	05048513          	addi	a0,s1,80
    80002d84:	ffffd097          	auipc	ra,0xffffd
    80002d88:	452080e7          	jalr	1106(ra) # 800001d6 <memmove>
    brelse(bp);
    80002d8c:	854a                	mv	a0,s2
    80002d8e:	00000097          	auipc	ra,0x0
    80002d92:	85c080e7          	jalr	-1956(ra) # 800025ea <brelse>
    ip->valid = 1;
    80002d96:	4785                	li	a5,1
    80002d98:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    80002d9a:	04449783          	lh	a5,68(s1)
    80002d9e:	c399                	beqz	a5,80002da4 <ilock+0xb6>
    80002da0:	6902                	ld	s2,0(sp)
    80002da2:	b7bd                	j	80002d10 <ilock+0x22>
      panic("ilock: no type");
    80002da4:	00005517          	auipc	a0,0x5
    80002da8:	6fc50513          	addi	a0,a0,1788 # 800084a0 <etext+0x4a0>
    80002dac:	00003097          	auipc	ra,0x3
    80002db0:	1e0080e7          	jalr	480(ra) # 80005f8c <panic>

0000000080002db4 <iunlock>:
{
    80002db4:	1101                	addi	sp,sp,-32
    80002db6:	ec06                	sd	ra,24(sp)
    80002db8:	e822                	sd	s0,16(sp)
    80002dba:	e426                	sd	s1,8(sp)
    80002dbc:	e04a                	sd	s2,0(sp)
    80002dbe:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80002dc0:	c905                	beqz	a0,80002df0 <iunlock+0x3c>
    80002dc2:	84aa                	mv	s1,a0
    80002dc4:	01050913          	addi	s2,a0,16
    80002dc8:	854a                	mv	a0,s2
    80002dca:	00001097          	auipc	ra,0x1
    80002dce:	c82080e7          	jalr	-894(ra) # 80003a4c <holdingsleep>
    80002dd2:	cd19                	beqz	a0,80002df0 <iunlock+0x3c>
    80002dd4:	449c                	lw	a5,8(s1)
    80002dd6:	00f05d63          	blez	a5,80002df0 <iunlock+0x3c>
  releasesleep(&ip->lock);
    80002dda:	854a                	mv	a0,s2
    80002ddc:	00001097          	auipc	ra,0x1
    80002de0:	c2c080e7          	jalr	-980(ra) # 80003a08 <releasesleep>
}
    80002de4:	60e2                	ld	ra,24(sp)
    80002de6:	6442                	ld	s0,16(sp)
    80002de8:	64a2                	ld	s1,8(sp)
    80002dea:	6902                	ld	s2,0(sp)
    80002dec:	6105                	addi	sp,sp,32
    80002dee:	8082                	ret
    panic("iunlock");
    80002df0:	00005517          	auipc	a0,0x5
    80002df4:	6c050513          	addi	a0,a0,1728 # 800084b0 <etext+0x4b0>
    80002df8:	00003097          	auipc	ra,0x3
    80002dfc:	194080e7          	jalr	404(ra) # 80005f8c <panic>

0000000080002e00 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80002e00:	7179                	addi	sp,sp,-48
    80002e02:	f406                	sd	ra,40(sp)
    80002e04:	f022                	sd	s0,32(sp)
    80002e06:	ec26                	sd	s1,24(sp)
    80002e08:	e84a                	sd	s2,16(sp)
    80002e0a:	e44e                	sd	s3,8(sp)
    80002e0c:	1800                	addi	s0,sp,48
    80002e0e:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    80002e10:	05050493          	addi	s1,a0,80
    80002e14:	08050913          	addi	s2,a0,128
    80002e18:	a021                	j	80002e20 <itrunc+0x20>
    80002e1a:	0491                	addi	s1,s1,4
    80002e1c:	01248d63          	beq	s1,s2,80002e36 <itrunc+0x36>
    if(ip->addrs[i]){
    80002e20:	408c                	lw	a1,0(s1)
    80002e22:	dde5                	beqz	a1,80002e1a <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    80002e24:	0009a503          	lw	a0,0(s3)
    80002e28:	00000097          	auipc	ra,0x0
    80002e2c:	8d6080e7          	jalr	-1834(ra) # 800026fe <bfree>
      ip->addrs[i] = 0;
    80002e30:	0004a023          	sw	zero,0(s1)
    80002e34:	b7dd                	j	80002e1a <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    80002e36:	0809a583          	lw	a1,128(s3)
    80002e3a:	ed99                	bnez	a1,80002e58 <itrunc+0x58>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    80002e3c:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80002e40:	854e                	mv	a0,s3
    80002e42:	00000097          	auipc	ra,0x0
    80002e46:	de0080e7          	jalr	-544(ra) # 80002c22 <iupdate>
}
    80002e4a:	70a2                	ld	ra,40(sp)
    80002e4c:	7402                	ld	s0,32(sp)
    80002e4e:	64e2                	ld	s1,24(sp)
    80002e50:	6942                	ld	s2,16(sp)
    80002e52:	69a2                	ld	s3,8(sp)
    80002e54:	6145                	addi	sp,sp,48
    80002e56:	8082                	ret
    80002e58:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    80002e5a:	0009a503          	lw	a0,0(s3)
    80002e5e:	fffff097          	auipc	ra,0xfffff
    80002e62:	65c080e7          	jalr	1628(ra) # 800024ba <bread>
    80002e66:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    80002e68:	05850493          	addi	s1,a0,88
    80002e6c:	45850913          	addi	s2,a0,1112
    80002e70:	a021                	j	80002e78 <itrunc+0x78>
    80002e72:	0491                	addi	s1,s1,4
    80002e74:	01248b63          	beq	s1,s2,80002e8a <itrunc+0x8a>
      if(a[j])
    80002e78:	408c                	lw	a1,0(s1)
    80002e7a:	dde5                	beqz	a1,80002e72 <itrunc+0x72>
        bfree(ip->dev, a[j]);
    80002e7c:	0009a503          	lw	a0,0(s3)
    80002e80:	00000097          	auipc	ra,0x0
    80002e84:	87e080e7          	jalr	-1922(ra) # 800026fe <bfree>
    80002e88:	b7ed                	j	80002e72 <itrunc+0x72>
    brelse(bp);
    80002e8a:	8552                	mv	a0,s4
    80002e8c:	fffff097          	auipc	ra,0xfffff
    80002e90:	75e080e7          	jalr	1886(ra) # 800025ea <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80002e94:	0809a583          	lw	a1,128(s3)
    80002e98:	0009a503          	lw	a0,0(s3)
    80002e9c:	00000097          	auipc	ra,0x0
    80002ea0:	862080e7          	jalr	-1950(ra) # 800026fe <bfree>
    ip->addrs[NDIRECT] = 0;
    80002ea4:	0809a023          	sw	zero,128(s3)
    80002ea8:	6a02                	ld	s4,0(sp)
    80002eaa:	bf49                	j	80002e3c <itrunc+0x3c>

0000000080002eac <iput>:
{
    80002eac:	1101                	addi	sp,sp,-32
    80002eae:	ec06                	sd	ra,24(sp)
    80002eb0:	e822                	sd	s0,16(sp)
    80002eb2:	e426                	sd	s1,8(sp)
    80002eb4:	1000                	addi	s0,sp,32
    80002eb6:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80002eb8:	0001a517          	auipc	a0,0x1a
    80002ebc:	ce050513          	addi	a0,a0,-800 # 8001cb98 <itable>
    80002ec0:	00003097          	auipc	ra,0x3
    80002ec4:	64e080e7          	jalr	1614(ra) # 8000650e <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80002ec8:	4498                	lw	a4,8(s1)
    80002eca:	4785                	li	a5,1
    80002ecc:	02f70263          	beq	a4,a5,80002ef0 <iput+0x44>
  ip->ref--;
    80002ed0:	449c                	lw	a5,8(s1)
    80002ed2:	37fd                	addiw	a5,a5,-1
    80002ed4:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80002ed6:	0001a517          	auipc	a0,0x1a
    80002eda:	cc250513          	addi	a0,a0,-830 # 8001cb98 <itable>
    80002ede:	00003097          	auipc	ra,0x3
    80002ee2:	6e4080e7          	jalr	1764(ra) # 800065c2 <release>
}
    80002ee6:	60e2                	ld	ra,24(sp)
    80002ee8:	6442                	ld	s0,16(sp)
    80002eea:	64a2                	ld	s1,8(sp)
    80002eec:	6105                	addi	sp,sp,32
    80002eee:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80002ef0:	40bc                	lw	a5,64(s1)
    80002ef2:	dff9                	beqz	a5,80002ed0 <iput+0x24>
    80002ef4:	04a49783          	lh	a5,74(s1)
    80002ef8:	ffe1                	bnez	a5,80002ed0 <iput+0x24>
    80002efa:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    80002efc:	01048913          	addi	s2,s1,16
    80002f00:	854a                	mv	a0,s2
    80002f02:	00001097          	auipc	ra,0x1
    80002f06:	ab0080e7          	jalr	-1360(ra) # 800039b2 <acquiresleep>
    release(&itable.lock);
    80002f0a:	0001a517          	auipc	a0,0x1a
    80002f0e:	c8e50513          	addi	a0,a0,-882 # 8001cb98 <itable>
    80002f12:	00003097          	auipc	ra,0x3
    80002f16:	6b0080e7          	jalr	1712(ra) # 800065c2 <release>
    itrunc(ip);
    80002f1a:	8526                	mv	a0,s1
    80002f1c:	00000097          	auipc	ra,0x0
    80002f20:	ee4080e7          	jalr	-284(ra) # 80002e00 <itrunc>
    ip->type = 0;
    80002f24:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80002f28:	8526                	mv	a0,s1
    80002f2a:	00000097          	auipc	ra,0x0
    80002f2e:	cf8080e7          	jalr	-776(ra) # 80002c22 <iupdate>
    ip->valid = 0;
    80002f32:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80002f36:	854a                	mv	a0,s2
    80002f38:	00001097          	auipc	ra,0x1
    80002f3c:	ad0080e7          	jalr	-1328(ra) # 80003a08 <releasesleep>
    acquire(&itable.lock);
    80002f40:	0001a517          	auipc	a0,0x1a
    80002f44:	c5850513          	addi	a0,a0,-936 # 8001cb98 <itable>
    80002f48:	00003097          	auipc	ra,0x3
    80002f4c:	5c6080e7          	jalr	1478(ra) # 8000650e <acquire>
    80002f50:	6902                	ld	s2,0(sp)
    80002f52:	bfbd                	j	80002ed0 <iput+0x24>

0000000080002f54 <iunlockput>:
{
    80002f54:	1101                	addi	sp,sp,-32
    80002f56:	ec06                	sd	ra,24(sp)
    80002f58:	e822                	sd	s0,16(sp)
    80002f5a:	e426                	sd	s1,8(sp)
    80002f5c:	1000                	addi	s0,sp,32
    80002f5e:	84aa                	mv	s1,a0
  iunlock(ip);
    80002f60:	00000097          	auipc	ra,0x0
    80002f64:	e54080e7          	jalr	-428(ra) # 80002db4 <iunlock>
  iput(ip);
    80002f68:	8526                	mv	a0,s1
    80002f6a:	00000097          	auipc	ra,0x0
    80002f6e:	f42080e7          	jalr	-190(ra) # 80002eac <iput>
}
    80002f72:	60e2                	ld	ra,24(sp)
    80002f74:	6442                	ld	s0,16(sp)
    80002f76:	64a2                	ld	s1,8(sp)
    80002f78:	6105                	addi	sp,sp,32
    80002f7a:	8082                	ret

0000000080002f7c <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80002f7c:	1141                	addi	sp,sp,-16
    80002f7e:	e422                	sd	s0,8(sp)
    80002f80:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80002f82:	411c                	lw	a5,0(a0)
    80002f84:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80002f86:	415c                	lw	a5,4(a0)
    80002f88:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80002f8a:	04451783          	lh	a5,68(a0)
    80002f8e:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80002f92:	04a51783          	lh	a5,74(a0)
    80002f96:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80002f9a:	04c56783          	lwu	a5,76(a0)
    80002f9e:	e99c                	sd	a5,16(a1)
}
    80002fa0:	6422                	ld	s0,8(sp)
    80002fa2:	0141                	addi	sp,sp,16
    80002fa4:	8082                	ret

0000000080002fa6 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80002fa6:	457c                	lw	a5,76(a0)
    80002fa8:	10d7e563          	bltu	a5,a3,800030b2 <readi+0x10c>
{
    80002fac:	7159                	addi	sp,sp,-112
    80002fae:	f486                	sd	ra,104(sp)
    80002fb0:	f0a2                	sd	s0,96(sp)
    80002fb2:	eca6                	sd	s1,88(sp)
    80002fb4:	e0d2                	sd	s4,64(sp)
    80002fb6:	fc56                	sd	s5,56(sp)
    80002fb8:	f85a                	sd	s6,48(sp)
    80002fba:	f45e                	sd	s7,40(sp)
    80002fbc:	1880                	addi	s0,sp,112
    80002fbe:	8b2a                	mv	s6,a0
    80002fc0:	8bae                	mv	s7,a1
    80002fc2:	8a32                	mv	s4,a2
    80002fc4:	84b6                	mv	s1,a3
    80002fc6:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80002fc8:	9f35                	addw	a4,a4,a3
    return 0;
    80002fca:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80002fcc:	0cd76a63          	bltu	a4,a3,800030a0 <readi+0xfa>
    80002fd0:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    80002fd2:	00e7f463          	bgeu	a5,a4,80002fda <readi+0x34>
    n = ip->size - off;
    80002fd6:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002fda:	0a0a8963          	beqz	s5,8000308c <readi+0xe6>
    80002fde:	e8ca                	sd	s2,80(sp)
    80002fe0:	f062                	sd	s8,32(sp)
    80002fe2:	ec66                	sd	s9,24(sp)
    80002fe4:	e86a                	sd	s10,16(sp)
    80002fe6:	e46e                	sd	s11,8(sp)
    80002fe8:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80002fea:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80002fee:	5c7d                	li	s8,-1
    80002ff0:	a82d                	j	8000302a <readi+0x84>
    80002ff2:	020d1d93          	slli	s11,s10,0x20
    80002ff6:	020ddd93          	srli	s11,s11,0x20
    80002ffa:	05890613          	addi	a2,s2,88
    80002ffe:	86ee                	mv	a3,s11
    80003000:	963a                	add	a2,a2,a4
    80003002:	85d2                	mv	a1,s4
    80003004:	855e                	mv	a0,s7
    80003006:	fffff097          	auipc	ra,0xfffff
    8000300a:	a08080e7          	jalr	-1528(ra) # 80001a0e <either_copyout>
    8000300e:	05850d63          	beq	a0,s8,80003068 <readi+0xc2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80003012:	854a                	mv	a0,s2
    80003014:	fffff097          	auipc	ra,0xfffff
    80003018:	5d6080e7          	jalr	1494(ra) # 800025ea <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    8000301c:	013d09bb          	addw	s3,s10,s3
    80003020:	009d04bb          	addw	s1,s10,s1
    80003024:	9a6e                	add	s4,s4,s11
    80003026:	0559fd63          	bgeu	s3,s5,80003080 <readi+0xda>
    uint addr = bmap(ip, off/BSIZE);
    8000302a:	00a4d59b          	srliw	a1,s1,0xa
    8000302e:	855a                	mv	a0,s6
    80003030:	00000097          	auipc	ra,0x0
    80003034:	88e080e7          	jalr	-1906(ra) # 800028be <bmap>
    80003038:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    8000303c:	c9b1                	beqz	a1,80003090 <readi+0xea>
    bp = bread(ip->dev, addr);
    8000303e:	000b2503          	lw	a0,0(s6)
    80003042:	fffff097          	auipc	ra,0xfffff
    80003046:	478080e7          	jalr	1144(ra) # 800024ba <bread>
    8000304a:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    8000304c:	3ff4f713          	andi	a4,s1,1023
    80003050:	40ec87bb          	subw	a5,s9,a4
    80003054:	413a86bb          	subw	a3,s5,s3
    80003058:	8d3e                	mv	s10,a5
    8000305a:	2781                	sext.w	a5,a5
    8000305c:	0006861b          	sext.w	a2,a3
    80003060:	f8f679e3          	bgeu	a2,a5,80002ff2 <readi+0x4c>
    80003064:	8d36                	mv	s10,a3
    80003066:	b771                	j	80002ff2 <readi+0x4c>
      brelse(bp);
    80003068:	854a                	mv	a0,s2
    8000306a:	fffff097          	auipc	ra,0xfffff
    8000306e:	580080e7          	jalr	1408(ra) # 800025ea <brelse>
      tot = -1;
    80003072:	59fd                	li	s3,-1
      break;
    80003074:	6946                	ld	s2,80(sp)
    80003076:	7c02                	ld	s8,32(sp)
    80003078:	6ce2                	ld	s9,24(sp)
    8000307a:	6d42                	ld	s10,16(sp)
    8000307c:	6da2                	ld	s11,8(sp)
    8000307e:	a831                	j	8000309a <readi+0xf4>
    80003080:	6946                	ld	s2,80(sp)
    80003082:	7c02                	ld	s8,32(sp)
    80003084:	6ce2                	ld	s9,24(sp)
    80003086:	6d42                	ld	s10,16(sp)
    80003088:	6da2                	ld	s11,8(sp)
    8000308a:	a801                	j	8000309a <readi+0xf4>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    8000308c:	89d6                	mv	s3,s5
    8000308e:	a031                	j	8000309a <readi+0xf4>
    80003090:	6946                	ld	s2,80(sp)
    80003092:	7c02                	ld	s8,32(sp)
    80003094:	6ce2                	ld	s9,24(sp)
    80003096:	6d42                	ld	s10,16(sp)
    80003098:	6da2                	ld	s11,8(sp)
  }
  return tot;
    8000309a:	0009851b          	sext.w	a0,s3
    8000309e:	69a6                	ld	s3,72(sp)
}
    800030a0:	70a6                	ld	ra,104(sp)
    800030a2:	7406                	ld	s0,96(sp)
    800030a4:	64e6                	ld	s1,88(sp)
    800030a6:	6a06                	ld	s4,64(sp)
    800030a8:	7ae2                	ld	s5,56(sp)
    800030aa:	7b42                	ld	s6,48(sp)
    800030ac:	7ba2                	ld	s7,40(sp)
    800030ae:	6165                	addi	sp,sp,112
    800030b0:	8082                	ret
    return 0;
    800030b2:	4501                	li	a0,0
}
    800030b4:	8082                	ret

00000000800030b6 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    800030b6:	457c                	lw	a5,76(a0)
    800030b8:	10d7ee63          	bltu	a5,a3,800031d4 <writei+0x11e>
{
    800030bc:	7159                	addi	sp,sp,-112
    800030be:	f486                	sd	ra,104(sp)
    800030c0:	f0a2                	sd	s0,96(sp)
    800030c2:	e8ca                	sd	s2,80(sp)
    800030c4:	e0d2                	sd	s4,64(sp)
    800030c6:	fc56                	sd	s5,56(sp)
    800030c8:	f85a                	sd	s6,48(sp)
    800030ca:	f45e                	sd	s7,40(sp)
    800030cc:	1880                	addi	s0,sp,112
    800030ce:	8aaa                	mv	s5,a0
    800030d0:	8bae                	mv	s7,a1
    800030d2:	8a32                	mv	s4,a2
    800030d4:	8936                	mv	s2,a3
    800030d6:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    800030d8:	00e687bb          	addw	a5,a3,a4
    800030dc:	0ed7ee63          	bltu	a5,a3,800031d8 <writei+0x122>
    return -1;
  if(off + n > MAXFILE*BSIZE)
    800030e0:	00043737          	lui	a4,0x43
    800030e4:	0ef76c63          	bltu	a4,a5,800031dc <writei+0x126>
    800030e8:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800030ea:	0c0b0d63          	beqz	s6,800031c4 <writei+0x10e>
    800030ee:	eca6                	sd	s1,88(sp)
    800030f0:	f062                	sd	s8,32(sp)
    800030f2:	ec66                	sd	s9,24(sp)
    800030f4:	e86a                	sd	s10,16(sp)
    800030f6:	e46e                	sd	s11,8(sp)
    800030f8:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    800030fa:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    800030fe:	5c7d                	li	s8,-1
    80003100:	a091                	j	80003144 <writei+0x8e>
    80003102:	020d1d93          	slli	s11,s10,0x20
    80003106:	020ddd93          	srli	s11,s11,0x20
    8000310a:	05848513          	addi	a0,s1,88
    8000310e:	86ee                	mv	a3,s11
    80003110:	8652                	mv	a2,s4
    80003112:	85de                	mv	a1,s7
    80003114:	953a                	add	a0,a0,a4
    80003116:	fffff097          	auipc	ra,0xfffff
    8000311a:	94e080e7          	jalr	-1714(ra) # 80001a64 <either_copyin>
    8000311e:	07850263          	beq	a0,s8,80003182 <writei+0xcc>
      brelse(bp);
      break;
    }
    log_write(bp);
    80003122:	8526                	mv	a0,s1
    80003124:	00000097          	auipc	ra,0x0
    80003128:	770080e7          	jalr	1904(ra) # 80003894 <log_write>
    brelse(bp);
    8000312c:	8526                	mv	a0,s1
    8000312e:	fffff097          	auipc	ra,0xfffff
    80003132:	4bc080e7          	jalr	1212(ra) # 800025ea <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003136:	013d09bb          	addw	s3,s10,s3
    8000313a:	012d093b          	addw	s2,s10,s2
    8000313e:	9a6e                	add	s4,s4,s11
    80003140:	0569f663          	bgeu	s3,s6,8000318c <writei+0xd6>
    uint addr = bmap(ip, off/BSIZE);
    80003144:	00a9559b          	srliw	a1,s2,0xa
    80003148:	8556                	mv	a0,s5
    8000314a:	fffff097          	auipc	ra,0xfffff
    8000314e:	774080e7          	jalr	1908(ra) # 800028be <bmap>
    80003152:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003156:	c99d                	beqz	a1,8000318c <writei+0xd6>
    bp = bread(ip->dev, addr);
    80003158:	000aa503          	lw	a0,0(s5)
    8000315c:	fffff097          	auipc	ra,0xfffff
    80003160:	35e080e7          	jalr	862(ra) # 800024ba <bread>
    80003164:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003166:	3ff97713          	andi	a4,s2,1023
    8000316a:	40ec87bb          	subw	a5,s9,a4
    8000316e:	413b06bb          	subw	a3,s6,s3
    80003172:	8d3e                	mv	s10,a5
    80003174:	2781                	sext.w	a5,a5
    80003176:	0006861b          	sext.w	a2,a3
    8000317a:	f8f674e3          	bgeu	a2,a5,80003102 <writei+0x4c>
    8000317e:	8d36                	mv	s10,a3
    80003180:	b749                	j	80003102 <writei+0x4c>
      brelse(bp);
    80003182:	8526                	mv	a0,s1
    80003184:	fffff097          	auipc	ra,0xfffff
    80003188:	466080e7          	jalr	1126(ra) # 800025ea <brelse>
  }

  if(off > ip->size)
    8000318c:	04caa783          	lw	a5,76(s5)
    80003190:	0327fc63          	bgeu	a5,s2,800031c8 <writei+0x112>
    ip->size = off;
    80003194:	052aa623          	sw	s2,76(s5)
    80003198:	64e6                	ld	s1,88(sp)
    8000319a:	7c02                	ld	s8,32(sp)
    8000319c:	6ce2                	ld	s9,24(sp)
    8000319e:	6d42                	ld	s10,16(sp)
    800031a0:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    800031a2:	8556                	mv	a0,s5
    800031a4:	00000097          	auipc	ra,0x0
    800031a8:	a7e080e7          	jalr	-1410(ra) # 80002c22 <iupdate>

  return tot;
    800031ac:	0009851b          	sext.w	a0,s3
    800031b0:	69a6                	ld	s3,72(sp)
}
    800031b2:	70a6                	ld	ra,104(sp)
    800031b4:	7406                	ld	s0,96(sp)
    800031b6:	6946                	ld	s2,80(sp)
    800031b8:	6a06                	ld	s4,64(sp)
    800031ba:	7ae2                	ld	s5,56(sp)
    800031bc:	7b42                	ld	s6,48(sp)
    800031be:	7ba2                	ld	s7,40(sp)
    800031c0:	6165                	addi	sp,sp,112
    800031c2:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800031c4:	89da                	mv	s3,s6
    800031c6:	bff1                	j	800031a2 <writei+0xec>
    800031c8:	64e6                	ld	s1,88(sp)
    800031ca:	7c02                	ld	s8,32(sp)
    800031cc:	6ce2                	ld	s9,24(sp)
    800031ce:	6d42                	ld	s10,16(sp)
    800031d0:	6da2                	ld	s11,8(sp)
    800031d2:	bfc1                	j	800031a2 <writei+0xec>
    return -1;
    800031d4:	557d                	li	a0,-1
}
    800031d6:	8082                	ret
    return -1;
    800031d8:	557d                	li	a0,-1
    800031da:	bfe1                	j	800031b2 <writei+0xfc>
    return -1;
    800031dc:	557d                	li	a0,-1
    800031de:	bfd1                	j	800031b2 <writei+0xfc>

00000000800031e0 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    800031e0:	1141                	addi	sp,sp,-16
    800031e2:	e406                	sd	ra,8(sp)
    800031e4:	e022                	sd	s0,0(sp)
    800031e6:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    800031e8:	4639                	li	a2,14
    800031ea:	ffffd097          	auipc	ra,0xffffd
    800031ee:	060080e7          	jalr	96(ra) # 8000024a <strncmp>
}
    800031f2:	60a2                	ld	ra,8(sp)
    800031f4:	6402                	ld	s0,0(sp)
    800031f6:	0141                	addi	sp,sp,16
    800031f8:	8082                	ret

00000000800031fa <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    800031fa:	7139                	addi	sp,sp,-64
    800031fc:	fc06                	sd	ra,56(sp)
    800031fe:	f822                	sd	s0,48(sp)
    80003200:	f426                	sd	s1,40(sp)
    80003202:	f04a                	sd	s2,32(sp)
    80003204:	ec4e                	sd	s3,24(sp)
    80003206:	e852                	sd	s4,16(sp)
    80003208:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    8000320a:	04451703          	lh	a4,68(a0)
    8000320e:	4785                	li	a5,1
    80003210:	00f71a63          	bne	a4,a5,80003224 <dirlookup+0x2a>
    80003214:	892a                	mv	s2,a0
    80003216:	89ae                	mv	s3,a1
    80003218:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    8000321a:	457c                	lw	a5,76(a0)
    8000321c:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    8000321e:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003220:	e79d                	bnez	a5,8000324e <dirlookup+0x54>
    80003222:	a8a5                	j	8000329a <dirlookup+0xa0>
    panic("dirlookup not DIR");
    80003224:	00005517          	auipc	a0,0x5
    80003228:	29450513          	addi	a0,a0,660 # 800084b8 <etext+0x4b8>
    8000322c:	00003097          	auipc	ra,0x3
    80003230:	d60080e7          	jalr	-672(ra) # 80005f8c <panic>
      panic("dirlookup read");
    80003234:	00005517          	auipc	a0,0x5
    80003238:	29c50513          	addi	a0,a0,668 # 800084d0 <etext+0x4d0>
    8000323c:	00003097          	auipc	ra,0x3
    80003240:	d50080e7          	jalr	-688(ra) # 80005f8c <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003244:	24c1                	addiw	s1,s1,16
    80003246:	04c92783          	lw	a5,76(s2)
    8000324a:	04f4f763          	bgeu	s1,a5,80003298 <dirlookup+0x9e>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000324e:	4741                	li	a4,16
    80003250:	86a6                	mv	a3,s1
    80003252:	fc040613          	addi	a2,s0,-64
    80003256:	4581                	li	a1,0
    80003258:	854a                	mv	a0,s2
    8000325a:	00000097          	auipc	ra,0x0
    8000325e:	d4c080e7          	jalr	-692(ra) # 80002fa6 <readi>
    80003262:	47c1                	li	a5,16
    80003264:	fcf518e3          	bne	a0,a5,80003234 <dirlookup+0x3a>
    if(de.inum == 0)
    80003268:	fc045783          	lhu	a5,-64(s0)
    8000326c:	dfe1                	beqz	a5,80003244 <dirlookup+0x4a>
    if(namecmp(name, de.name) == 0){
    8000326e:	fc240593          	addi	a1,s0,-62
    80003272:	854e                	mv	a0,s3
    80003274:	00000097          	auipc	ra,0x0
    80003278:	f6c080e7          	jalr	-148(ra) # 800031e0 <namecmp>
    8000327c:	f561                	bnez	a0,80003244 <dirlookup+0x4a>
      if(poff)
    8000327e:	000a0463          	beqz	s4,80003286 <dirlookup+0x8c>
        *poff = off;
    80003282:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    80003286:	fc045583          	lhu	a1,-64(s0)
    8000328a:	00092503          	lw	a0,0(s2)
    8000328e:	fffff097          	auipc	ra,0xfffff
    80003292:	720080e7          	jalr	1824(ra) # 800029ae <iget>
    80003296:	a011                	j	8000329a <dirlookup+0xa0>
  return 0;
    80003298:	4501                	li	a0,0
}
    8000329a:	70e2                	ld	ra,56(sp)
    8000329c:	7442                	ld	s0,48(sp)
    8000329e:	74a2                	ld	s1,40(sp)
    800032a0:	7902                	ld	s2,32(sp)
    800032a2:	69e2                	ld	s3,24(sp)
    800032a4:	6a42                	ld	s4,16(sp)
    800032a6:	6121                	addi	sp,sp,64
    800032a8:	8082                	ret

00000000800032aa <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    800032aa:	711d                	addi	sp,sp,-96
    800032ac:	ec86                	sd	ra,88(sp)
    800032ae:	e8a2                	sd	s0,80(sp)
    800032b0:	e4a6                	sd	s1,72(sp)
    800032b2:	e0ca                	sd	s2,64(sp)
    800032b4:	fc4e                	sd	s3,56(sp)
    800032b6:	f852                	sd	s4,48(sp)
    800032b8:	f456                	sd	s5,40(sp)
    800032ba:	f05a                	sd	s6,32(sp)
    800032bc:	ec5e                	sd	s7,24(sp)
    800032be:	e862                	sd	s8,16(sp)
    800032c0:	e466                	sd	s9,8(sp)
    800032c2:	1080                	addi	s0,sp,96
    800032c4:	84aa                	mv	s1,a0
    800032c6:	8b2e                	mv	s6,a1
    800032c8:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    800032ca:	00054703          	lbu	a4,0(a0)
    800032ce:	02f00793          	li	a5,47
    800032d2:	02f70263          	beq	a4,a5,800032f6 <namex+0x4c>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    800032d6:	ffffe097          	auipc	ra,0xffffe
    800032da:	c30080e7          	jalr	-976(ra) # 80000f06 <myproc>
    800032de:	15053503          	ld	a0,336(a0)
    800032e2:	00000097          	auipc	ra,0x0
    800032e6:	9ce080e7          	jalr	-1586(ra) # 80002cb0 <idup>
    800032ea:	8a2a                	mv	s4,a0
  while(*path == '/')
    800032ec:	02f00913          	li	s2,47
  if(len >= DIRSIZ)
    800032f0:	4c35                	li	s8,13

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    800032f2:	4b85                	li	s7,1
    800032f4:	a875                	j	800033b0 <namex+0x106>
    ip = iget(ROOTDEV, ROOTINO);
    800032f6:	4585                	li	a1,1
    800032f8:	4505                	li	a0,1
    800032fa:	fffff097          	auipc	ra,0xfffff
    800032fe:	6b4080e7          	jalr	1716(ra) # 800029ae <iget>
    80003302:	8a2a                	mv	s4,a0
    80003304:	b7e5                	j	800032ec <namex+0x42>
      iunlockput(ip);
    80003306:	8552                	mv	a0,s4
    80003308:	00000097          	auipc	ra,0x0
    8000330c:	c4c080e7          	jalr	-948(ra) # 80002f54 <iunlockput>
      return 0;
    80003310:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003312:	8552                	mv	a0,s4
    80003314:	60e6                	ld	ra,88(sp)
    80003316:	6446                	ld	s0,80(sp)
    80003318:	64a6                	ld	s1,72(sp)
    8000331a:	6906                	ld	s2,64(sp)
    8000331c:	79e2                	ld	s3,56(sp)
    8000331e:	7a42                	ld	s4,48(sp)
    80003320:	7aa2                	ld	s5,40(sp)
    80003322:	7b02                	ld	s6,32(sp)
    80003324:	6be2                	ld	s7,24(sp)
    80003326:	6c42                	ld	s8,16(sp)
    80003328:	6ca2                	ld	s9,8(sp)
    8000332a:	6125                	addi	sp,sp,96
    8000332c:	8082                	ret
      iunlock(ip);
    8000332e:	8552                	mv	a0,s4
    80003330:	00000097          	auipc	ra,0x0
    80003334:	a84080e7          	jalr	-1404(ra) # 80002db4 <iunlock>
      return ip;
    80003338:	bfe9                	j	80003312 <namex+0x68>
      iunlockput(ip);
    8000333a:	8552                	mv	a0,s4
    8000333c:	00000097          	auipc	ra,0x0
    80003340:	c18080e7          	jalr	-1000(ra) # 80002f54 <iunlockput>
      return 0;
    80003344:	8a4e                	mv	s4,s3
    80003346:	b7f1                	j	80003312 <namex+0x68>
  len = path - s;
    80003348:	40998633          	sub	a2,s3,s1
    8000334c:	00060c9b          	sext.w	s9,a2
  if(len >= DIRSIZ)
    80003350:	099c5863          	bge	s8,s9,800033e0 <namex+0x136>
    memmove(name, s, DIRSIZ);
    80003354:	4639                	li	a2,14
    80003356:	85a6                	mv	a1,s1
    80003358:	8556                	mv	a0,s5
    8000335a:	ffffd097          	auipc	ra,0xffffd
    8000335e:	e7c080e7          	jalr	-388(ra) # 800001d6 <memmove>
    80003362:	84ce                	mv	s1,s3
  while(*path == '/')
    80003364:	0004c783          	lbu	a5,0(s1)
    80003368:	01279763          	bne	a5,s2,80003376 <namex+0xcc>
    path++;
    8000336c:	0485                	addi	s1,s1,1
  while(*path == '/')
    8000336e:	0004c783          	lbu	a5,0(s1)
    80003372:	ff278de3          	beq	a5,s2,8000336c <namex+0xc2>
    ilock(ip);
    80003376:	8552                	mv	a0,s4
    80003378:	00000097          	auipc	ra,0x0
    8000337c:	976080e7          	jalr	-1674(ra) # 80002cee <ilock>
    if(ip->type != T_DIR){
    80003380:	044a1783          	lh	a5,68(s4)
    80003384:	f97791e3          	bne	a5,s7,80003306 <namex+0x5c>
    if(nameiparent && *path == '\0'){
    80003388:	000b0563          	beqz	s6,80003392 <namex+0xe8>
    8000338c:	0004c783          	lbu	a5,0(s1)
    80003390:	dfd9                	beqz	a5,8000332e <namex+0x84>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003392:	4601                	li	a2,0
    80003394:	85d6                	mv	a1,s5
    80003396:	8552                	mv	a0,s4
    80003398:	00000097          	auipc	ra,0x0
    8000339c:	e62080e7          	jalr	-414(ra) # 800031fa <dirlookup>
    800033a0:	89aa                	mv	s3,a0
    800033a2:	dd41                	beqz	a0,8000333a <namex+0x90>
    iunlockput(ip);
    800033a4:	8552                	mv	a0,s4
    800033a6:	00000097          	auipc	ra,0x0
    800033aa:	bae080e7          	jalr	-1106(ra) # 80002f54 <iunlockput>
    ip = next;
    800033ae:	8a4e                	mv	s4,s3
  while(*path == '/')
    800033b0:	0004c783          	lbu	a5,0(s1)
    800033b4:	01279763          	bne	a5,s2,800033c2 <namex+0x118>
    path++;
    800033b8:	0485                	addi	s1,s1,1
  while(*path == '/')
    800033ba:	0004c783          	lbu	a5,0(s1)
    800033be:	ff278de3          	beq	a5,s2,800033b8 <namex+0x10e>
  if(*path == 0)
    800033c2:	cb9d                	beqz	a5,800033f8 <namex+0x14e>
  while(*path != '/' && *path != 0)
    800033c4:	0004c783          	lbu	a5,0(s1)
    800033c8:	89a6                	mv	s3,s1
  len = path - s;
    800033ca:	4c81                	li	s9,0
    800033cc:	4601                	li	a2,0
  while(*path != '/' && *path != 0)
    800033ce:	01278963          	beq	a5,s2,800033e0 <namex+0x136>
    800033d2:	dbbd                	beqz	a5,80003348 <namex+0x9e>
    path++;
    800033d4:	0985                	addi	s3,s3,1
  while(*path != '/' && *path != 0)
    800033d6:	0009c783          	lbu	a5,0(s3)
    800033da:	ff279ce3          	bne	a5,s2,800033d2 <namex+0x128>
    800033de:	b7ad                	j	80003348 <namex+0x9e>
    memmove(name, s, len);
    800033e0:	2601                	sext.w	a2,a2
    800033e2:	85a6                	mv	a1,s1
    800033e4:	8556                	mv	a0,s5
    800033e6:	ffffd097          	auipc	ra,0xffffd
    800033ea:	df0080e7          	jalr	-528(ra) # 800001d6 <memmove>
    name[len] = 0;
    800033ee:	9cd6                	add	s9,s9,s5
    800033f0:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x7fffe000>
    800033f4:	84ce                	mv	s1,s3
    800033f6:	b7bd                	j	80003364 <namex+0xba>
  if(nameiparent){
    800033f8:	f00b0de3          	beqz	s6,80003312 <namex+0x68>
    iput(ip);
    800033fc:	8552                	mv	a0,s4
    800033fe:	00000097          	auipc	ra,0x0
    80003402:	aae080e7          	jalr	-1362(ra) # 80002eac <iput>
    return 0;
    80003406:	4a01                	li	s4,0
    80003408:	b729                	j	80003312 <namex+0x68>

000000008000340a <dirlink>:
{
    8000340a:	7139                	addi	sp,sp,-64
    8000340c:	fc06                	sd	ra,56(sp)
    8000340e:	f822                	sd	s0,48(sp)
    80003410:	f04a                	sd	s2,32(sp)
    80003412:	ec4e                	sd	s3,24(sp)
    80003414:	e852                	sd	s4,16(sp)
    80003416:	0080                	addi	s0,sp,64
    80003418:	892a                	mv	s2,a0
    8000341a:	8a2e                	mv	s4,a1
    8000341c:	89b2                	mv	s3,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    8000341e:	4601                	li	a2,0
    80003420:	00000097          	auipc	ra,0x0
    80003424:	dda080e7          	jalr	-550(ra) # 800031fa <dirlookup>
    80003428:	ed25                	bnez	a0,800034a0 <dirlink+0x96>
    8000342a:	f426                	sd	s1,40(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    8000342c:	04c92483          	lw	s1,76(s2)
    80003430:	c49d                	beqz	s1,8000345e <dirlink+0x54>
    80003432:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003434:	4741                	li	a4,16
    80003436:	86a6                	mv	a3,s1
    80003438:	fc040613          	addi	a2,s0,-64
    8000343c:	4581                	li	a1,0
    8000343e:	854a                	mv	a0,s2
    80003440:	00000097          	auipc	ra,0x0
    80003444:	b66080e7          	jalr	-1178(ra) # 80002fa6 <readi>
    80003448:	47c1                	li	a5,16
    8000344a:	06f51163          	bne	a0,a5,800034ac <dirlink+0xa2>
    if(de.inum == 0)
    8000344e:	fc045783          	lhu	a5,-64(s0)
    80003452:	c791                	beqz	a5,8000345e <dirlink+0x54>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003454:	24c1                	addiw	s1,s1,16
    80003456:	04c92783          	lw	a5,76(s2)
    8000345a:	fcf4ede3          	bltu	s1,a5,80003434 <dirlink+0x2a>
  strncpy(de.name, name, DIRSIZ);
    8000345e:	4639                	li	a2,14
    80003460:	85d2                	mv	a1,s4
    80003462:	fc240513          	addi	a0,s0,-62
    80003466:	ffffd097          	auipc	ra,0xffffd
    8000346a:	e1a080e7          	jalr	-486(ra) # 80000280 <strncpy>
  de.inum = inum;
    8000346e:	fd341023          	sh	s3,-64(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003472:	4741                	li	a4,16
    80003474:	86a6                	mv	a3,s1
    80003476:	fc040613          	addi	a2,s0,-64
    8000347a:	4581                	li	a1,0
    8000347c:	854a                	mv	a0,s2
    8000347e:	00000097          	auipc	ra,0x0
    80003482:	c38080e7          	jalr	-968(ra) # 800030b6 <writei>
    80003486:	1541                	addi	a0,a0,-16
    80003488:	00a03533          	snez	a0,a0
    8000348c:	40a00533          	neg	a0,a0
    80003490:	74a2                	ld	s1,40(sp)
}
    80003492:	70e2                	ld	ra,56(sp)
    80003494:	7442                	ld	s0,48(sp)
    80003496:	7902                	ld	s2,32(sp)
    80003498:	69e2                	ld	s3,24(sp)
    8000349a:	6a42                	ld	s4,16(sp)
    8000349c:	6121                	addi	sp,sp,64
    8000349e:	8082                	ret
    iput(ip);
    800034a0:	00000097          	auipc	ra,0x0
    800034a4:	a0c080e7          	jalr	-1524(ra) # 80002eac <iput>
    return -1;
    800034a8:	557d                	li	a0,-1
    800034aa:	b7e5                	j	80003492 <dirlink+0x88>
      panic("dirlink read");
    800034ac:	00005517          	auipc	a0,0x5
    800034b0:	03450513          	addi	a0,a0,52 # 800084e0 <etext+0x4e0>
    800034b4:	00003097          	auipc	ra,0x3
    800034b8:	ad8080e7          	jalr	-1320(ra) # 80005f8c <panic>

00000000800034bc <namei>:

struct inode*
namei(char *path)
{
    800034bc:	1101                	addi	sp,sp,-32
    800034be:	ec06                	sd	ra,24(sp)
    800034c0:	e822                	sd	s0,16(sp)
    800034c2:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    800034c4:	fe040613          	addi	a2,s0,-32
    800034c8:	4581                	li	a1,0
    800034ca:	00000097          	auipc	ra,0x0
    800034ce:	de0080e7          	jalr	-544(ra) # 800032aa <namex>
}
    800034d2:	60e2                	ld	ra,24(sp)
    800034d4:	6442                	ld	s0,16(sp)
    800034d6:	6105                	addi	sp,sp,32
    800034d8:	8082                	ret

00000000800034da <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    800034da:	1141                	addi	sp,sp,-16
    800034dc:	e406                	sd	ra,8(sp)
    800034de:	e022                	sd	s0,0(sp)
    800034e0:	0800                	addi	s0,sp,16
    800034e2:	862e                	mv	a2,a1
  return namex(path, 1, name);
    800034e4:	4585                	li	a1,1
    800034e6:	00000097          	auipc	ra,0x0
    800034ea:	dc4080e7          	jalr	-572(ra) # 800032aa <namex>
}
    800034ee:	60a2                	ld	ra,8(sp)
    800034f0:	6402                	ld	s0,0(sp)
    800034f2:	0141                	addi	sp,sp,16
    800034f4:	8082                	ret

00000000800034f6 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    800034f6:	1101                	addi	sp,sp,-32
    800034f8:	ec06                	sd	ra,24(sp)
    800034fa:	e822                	sd	s0,16(sp)
    800034fc:	e426                	sd	s1,8(sp)
    800034fe:	e04a                	sd	s2,0(sp)
    80003500:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003502:	0001b917          	auipc	s2,0x1b
    80003506:	13e90913          	addi	s2,s2,318 # 8001e640 <log>
    8000350a:	01892583          	lw	a1,24(s2)
    8000350e:	02892503          	lw	a0,40(s2)
    80003512:	fffff097          	auipc	ra,0xfffff
    80003516:	fa8080e7          	jalr	-88(ra) # 800024ba <bread>
    8000351a:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    8000351c:	02c92603          	lw	a2,44(s2)
    80003520:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003522:	00c05f63          	blez	a2,80003540 <write_head+0x4a>
    80003526:	0001b717          	auipc	a4,0x1b
    8000352a:	14a70713          	addi	a4,a4,330 # 8001e670 <log+0x30>
    8000352e:	87aa                	mv	a5,a0
    80003530:	060a                	slli	a2,a2,0x2
    80003532:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003534:	4314                	lw	a3,0(a4)
    80003536:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003538:	0711                	addi	a4,a4,4
    8000353a:	0791                	addi	a5,a5,4
    8000353c:	fec79ce3          	bne	a5,a2,80003534 <write_head+0x3e>
  }
  bwrite(buf);
    80003540:	8526                	mv	a0,s1
    80003542:	fffff097          	auipc	ra,0xfffff
    80003546:	06a080e7          	jalr	106(ra) # 800025ac <bwrite>
  brelse(buf);
    8000354a:	8526                	mv	a0,s1
    8000354c:	fffff097          	auipc	ra,0xfffff
    80003550:	09e080e7          	jalr	158(ra) # 800025ea <brelse>
}
    80003554:	60e2                	ld	ra,24(sp)
    80003556:	6442                	ld	s0,16(sp)
    80003558:	64a2                	ld	s1,8(sp)
    8000355a:	6902                	ld	s2,0(sp)
    8000355c:	6105                	addi	sp,sp,32
    8000355e:	8082                	ret

0000000080003560 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003560:	0001b797          	auipc	a5,0x1b
    80003564:	10c7a783          	lw	a5,268(a5) # 8001e66c <log+0x2c>
    80003568:	0af05d63          	blez	a5,80003622 <install_trans+0xc2>
{
    8000356c:	7139                	addi	sp,sp,-64
    8000356e:	fc06                	sd	ra,56(sp)
    80003570:	f822                	sd	s0,48(sp)
    80003572:	f426                	sd	s1,40(sp)
    80003574:	f04a                	sd	s2,32(sp)
    80003576:	ec4e                	sd	s3,24(sp)
    80003578:	e852                	sd	s4,16(sp)
    8000357a:	e456                	sd	s5,8(sp)
    8000357c:	e05a                	sd	s6,0(sp)
    8000357e:	0080                	addi	s0,sp,64
    80003580:	8b2a                	mv	s6,a0
    80003582:	0001ba97          	auipc	s5,0x1b
    80003586:	0eea8a93          	addi	s5,s5,238 # 8001e670 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    8000358a:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    8000358c:	0001b997          	auipc	s3,0x1b
    80003590:	0b498993          	addi	s3,s3,180 # 8001e640 <log>
    80003594:	a00d                	j	800035b6 <install_trans+0x56>
    brelse(lbuf);
    80003596:	854a                	mv	a0,s2
    80003598:	fffff097          	auipc	ra,0xfffff
    8000359c:	052080e7          	jalr	82(ra) # 800025ea <brelse>
    brelse(dbuf);
    800035a0:	8526                	mv	a0,s1
    800035a2:	fffff097          	auipc	ra,0xfffff
    800035a6:	048080e7          	jalr	72(ra) # 800025ea <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    800035aa:	2a05                	addiw	s4,s4,1
    800035ac:	0a91                	addi	s5,s5,4
    800035ae:	02c9a783          	lw	a5,44(s3)
    800035b2:	04fa5e63          	bge	s4,a5,8000360e <install_trans+0xae>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    800035b6:	0189a583          	lw	a1,24(s3)
    800035ba:	014585bb          	addw	a1,a1,s4
    800035be:	2585                	addiw	a1,a1,1
    800035c0:	0289a503          	lw	a0,40(s3)
    800035c4:	fffff097          	auipc	ra,0xfffff
    800035c8:	ef6080e7          	jalr	-266(ra) # 800024ba <bread>
    800035cc:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    800035ce:	000aa583          	lw	a1,0(s5)
    800035d2:	0289a503          	lw	a0,40(s3)
    800035d6:	fffff097          	auipc	ra,0xfffff
    800035da:	ee4080e7          	jalr	-284(ra) # 800024ba <bread>
    800035de:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    800035e0:	40000613          	li	a2,1024
    800035e4:	05890593          	addi	a1,s2,88
    800035e8:	05850513          	addi	a0,a0,88
    800035ec:	ffffd097          	auipc	ra,0xffffd
    800035f0:	bea080e7          	jalr	-1046(ra) # 800001d6 <memmove>
    bwrite(dbuf);  // write dst to disk
    800035f4:	8526                	mv	a0,s1
    800035f6:	fffff097          	auipc	ra,0xfffff
    800035fa:	fb6080e7          	jalr	-74(ra) # 800025ac <bwrite>
    if(recovering == 0)
    800035fe:	f80b1ce3          	bnez	s6,80003596 <install_trans+0x36>
      bunpin(dbuf);
    80003602:	8526                	mv	a0,s1
    80003604:	fffff097          	auipc	ra,0xfffff
    80003608:	0be080e7          	jalr	190(ra) # 800026c2 <bunpin>
    8000360c:	b769                	j	80003596 <install_trans+0x36>
}
    8000360e:	70e2                	ld	ra,56(sp)
    80003610:	7442                	ld	s0,48(sp)
    80003612:	74a2                	ld	s1,40(sp)
    80003614:	7902                	ld	s2,32(sp)
    80003616:	69e2                	ld	s3,24(sp)
    80003618:	6a42                	ld	s4,16(sp)
    8000361a:	6aa2                	ld	s5,8(sp)
    8000361c:	6b02                	ld	s6,0(sp)
    8000361e:	6121                	addi	sp,sp,64
    80003620:	8082                	ret
    80003622:	8082                	ret

0000000080003624 <initlog>:
{
    80003624:	7179                	addi	sp,sp,-48
    80003626:	f406                	sd	ra,40(sp)
    80003628:	f022                	sd	s0,32(sp)
    8000362a:	ec26                	sd	s1,24(sp)
    8000362c:	e84a                	sd	s2,16(sp)
    8000362e:	e44e                	sd	s3,8(sp)
    80003630:	1800                	addi	s0,sp,48
    80003632:	892a                	mv	s2,a0
    80003634:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003636:	0001b497          	auipc	s1,0x1b
    8000363a:	00a48493          	addi	s1,s1,10 # 8001e640 <log>
    8000363e:	00005597          	auipc	a1,0x5
    80003642:	eb258593          	addi	a1,a1,-334 # 800084f0 <etext+0x4f0>
    80003646:	8526                	mv	a0,s1
    80003648:	00003097          	auipc	ra,0x3
    8000364c:	e36080e7          	jalr	-458(ra) # 8000647e <initlock>
  log.start = sb->logstart;
    80003650:	0149a583          	lw	a1,20(s3)
    80003654:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    80003656:	0109a783          	lw	a5,16(s3)
    8000365a:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    8000365c:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    80003660:	854a                	mv	a0,s2
    80003662:	fffff097          	auipc	ra,0xfffff
    80003666:	e58080e7          	jalr	-424(ra) # 800024ba <bread>
  log.lh.n = lh->n;
    8000366a:	4d30                	lw	a2,88(a0)
    8000366c:	d4d0                	sw	a2,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    8000366e:	00c05f63          	blez	a2,8000368c <initlog+0x68>
    80003672:	87aa                	mv	a5,a0
    80003674:	0001b717          	auipc	a4,0x1b
    80003678:	ffc70713          	addi	a4,a4,-4 # 8001e670 <log+0x30>
    8000367c:	060a                	slli	a2,a2,0x2
    8000367e:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003680:	4ff4                	lw	a3,92(a5)
    80003682:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003684:	0791                	addi	a5,a5,4
    80003686:	0711                	addi	a4,a4,4
    80003688:	fec79ce3          	bne	a5,a2,80003680 <initlog+0x5c>
  brelse(buf);
    8000368c:	fffff097          	auipc	ra,0xfffff
    80003690:	f5e080e7          	jalr	-162(ra) # 800025ea <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003694:	4505                	li	a0,1
    80003696:	00000097          	auipc	ra,0x0
    8000369a:	eca080e7          	jalr	-310(ra) # 80003560 <install_trans>
  log.lh.n = 0;
    8000369e:	0001b797          	auipc	a5,0x1b
    800036a2:	fc07a723          	sw	zero,-50(a5) # 8001e66c <log+0x2c>
  write_head(); // clear the log
    800036a6:	00000097          	auipc	ra,0x0
    800036aa:	e50080e7          	jalr	-432(ra) # 800034f6 <write_head>
}
    800036ae:	70a2                	ld	ra,40(sp)
    800036b0:	7402                	ld	s0,32(sp)
    800036b2:	64e2                	ld	s1,24(sp)
    800036b4:	6942                	ld	s2,16(sp)
    800036b6:	69a2                	ld	s3,8(sp)
    800036b8:	6145                	addi	sp,sp,48
    800036ba:	8082                	ret

00000000800036bc <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    800036bc:	1101                	addi	sp,sp,-32
    800036be:	ec06                	sd	ra,24(sp)
    800036c0:	e822                	sd	s0,16(sp)
    800036c2:	e426                	sd	s1,8(sp)
    800036c4:	e04a                	sd	s2,0(sp)
    800036c6:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    800036c8:	0001b517          	auipc	a0,0x1b
    800036cc:	f7850513          	addi	a0,a0,-136 # 8001e640 <log>
    800036d0:	00003097          	auipc	ra,0x3
    800036d4:	e3e080e7          	jalr	-450(ra) # 8000650e <acquire>
  while(1){
    if(log.committing){
    800036d8:	0001b497          	auipc	s1,0x1b
    800036dc:	f6848493          	addi	s1,s1,-152 # 8001e640 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    800036e0:	4979                	li	s2,30
    800036e2:	a039                	j	800036f0 <begin_op+0x34>
      sleep(&log, &log.lock);
    800036e4:	85a6                	mv	a1,s1
    800036e6:	8526                	mv	a0,s1
    800036e8:	ffffe097          	auipc	ra,0xffffe
    800036ec:	f1e080e7          	jalr	-226(ra) # 80001606 <sleep>
    if(log.committing){
    800036f0:	50dc                	lw	a5,36(s1)
    800036f2:	fbed                	bnez	a5,800036e4 <begin_op+0x28>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    800036f4:	5098                	lw	a4,32(s1)
    800036f6:	2705                	addiw	a4,a4,1
    800036f8:	0027179b          	slliw	a5,a4,0x2
    800036fc:	9fb9                	addw	a5,a5,a4
    800036fe:	0017979b          	slliw	a5,a5,0x1
    80003702:	54d4                	lw	a3,44(s1)
    80003704:	9fb5                	addw	a5,a5,a3
    80003706:	00f95963          	bge	s2,a5,80003718 <begin_op+0x5c>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    8000370a:	85a6                	mv	a1,s1
    8000370c:	8526                	mv	a0,s1
    8000370e:	ffffe097          	auipc	ra,0xffffe
    80003712:	ef8080e7          	jalr	-264(ra) # 80001606 <sleep>
    80003716:	bfe9                	j	800036f0 <begin_op+0x34>
    } else {
      log.outstanding += 1;
    80003718:	0001b517          	auipc	a0,0x1b
    8000371c:	f2850513          	addi	a0,a0,-216 # 8001e640 <log>
    80003720:	d118                	sw	a4,32(a0)
      release(&log.lock);
    80003722:	00003097          	auipc	ra,0x3
    80003726:	ea0080e7          	jalr	-352(ra) # 800065c2 <release>
      break;
    }
  }
}
    8000372a:	60e2                	ld	ra,24(sp)
    8000372c:	6442                	ld	s0,16(sp)
    8000372e:	64a2                	ld	s1,8(sp)
    80003730:	6902                	ld	s2,0(sp)
    80003732:	6105                	addi	sp,sp,32
    80003734:	8082                	ret

0000000080003736 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003736:	7139                	addi	sp,sp,-64
    80003738:	fc06                	sd	ra,56(sp)
    8000373a:	f822                	sd	s0,48(sp)
    8000373c:	f426                	sd	s1,40(sp)
    8000373e:	f04a                	sd	s2,32(sp)
    80003740:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003742:	0001b497          	auipc	s1,0x1b
    80003746:	efe48493          	addi	s1,s1,-258 # 8001e640 <log>
    8000374a:	8526                	mv	a0,s1
    8000374c:	00003097          	auipc	ra,0x3
    80003750:	dc2080e7          	jalr	-574(ra) # 8000650e <acquire>
  log.outstanding -= 1;
    80003754:	509c                	lw	a5,32(s1)
    80003756:	37fd                	addiw	a5,a5,-1
    80003758:	0007891b          	sext.w	s2,a5
    8000375c:	d09c                	sw	a5,32(s1)
  if(log.committing)
    8000375e:	50dc                	lw	a5,36(s1)
    80003760:	e7b9                	bnez	a5,800037ae <end_op+0x78>
    panic("log.committing");
  if(log.outstanding == 0){
    80003762:	06091163          	bnez	s2,800037c4 <end_op+0x8e>
    do_commit = 1;
    log.committing = 1;
    80003766:	0001b497          	auipc	s1,0x1b
    8000376a:	eda48493          	addi	s1,s1,-294 # 8001e640 <log>
    8000376e:	4785                	li	a5,1
    80003770:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003772:	8526                	mv	a0,s1
    80003774:	00003097          	auipc	ra,0x3
    80003778:	e4e080e7          	jalr	-434(ra) # 800065c2 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    8000377c:	54dc                	lw	a5,44(s1)
    8000377e:	06f04763          	bgtz	a5,800037ec <end_op+0xb6>
    acquire(&log.lock);
    80003782:	0001b497          	auipc	s1,0x1b
    80003786:	ebe48493          	addi	s1,s1,-322 # 8001e640 <log>
    8000378a:	8526                	mv	a0,s1
    8000378c:	00003097          	auipc	ra,0x3
    80003790:	d82080e7          	jalr	-638(ra) # 8000650e <acquire>
    log.committing = 0;
    80003794:	0204a223          	sw	zero,36(s1)
    wakeup(&log);
    80003798:	8526                	mv	a0,s1
    8000379a:	ffffe097          	auipc	ra,0xffffe
    8000379e:	ed0080e7          	jalr	-304(ra) # 8000166a <wakeup>
    release(&log.lock);
    800037a2:	8526                	mv	a0,s1
    800037a4:	00003097          	auipc	ra,0x3
    800037a8:	e1e080e7          	jalr	-482(ra) # 800065c2 <release>
}
    800037ac:	a815                	j	800037e0 <end_op+0xaa>
    800037ae:	ec4e                	sd	s3,24(sp)
    800037b0:	e852                	sd	s4,16(sp)
    800037b2:	e456                	sd	s5,8(sp)
    panic("log.committing");
    800037b4:	00005517          	auipc	a0,0x5
    800037b8:	d4450513          	addi	a0,a0,-700 # 800084f8 <etext+0x4f8>
    800037bc:	00002097          	auipc	ra,0x2
    800037c0:	7d0080e7          	jalr	2000(ra) # 80005f8c <panic>
    wakeup(&log);
    800037c4:	0001b497          	auipc	s1,0x1b
    800037c8:	e7c48493          	addi	s1,s1,-388 # 8001e640 <log>
    800037cc:	8526                	mv	a0,s1
    800037ce:	ffffe097          	auipc	ra,0xffffe
    800037d2:	e9c080e7          	jalr	-356(ra) # 8000166a <wakeup>
  release(&log.lock);
    800037d6:	8526                	mv	a0,s1
    800037d8:	00003097          	auipc	ra,0x3
    800037dc:	dea080e7          	jalr	-534(ra) # 800065c2 <release>
}
    800037e0:	70e2                	ld	ra,56(sp)
    800037e2:	7442                	ld	s0,48(sp)
    800037e4:	74a2                	ld	s1,40(sp)
    800037e6:	7902                	ld	s2,32(sp)
    800037e8:	6121                	addi	sp,sp,64
    800037ea:	8082                	ret
    800037ec:	ec4e                	sd	s3,24(sp)
    800037ee:	e852                	sd	s4,16(sp)
    800037f0:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    800037f2:	0001ba97          	auipc	s5,0x1b
    800037f6:	e7ea8a93          	addi	s5,s5,-386 # 8001e670 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    800037fa:	0001ba17          	auipc	s4,0x1b
    800037fe:	e46a0a13          	addi	s4,s4,-442 # 8001e640 <log>
    80003802:	018a2583          	lw	a1,24(s4)
    80003806:	012585bb          	addw	a1,a1,s2
    8000380a:	2585                	addiw	a1,a1,1
    8000380c:	028a2503          	lw	a0,40(s4)
    80003810:	fffff097          	auipc	ra,0xfffff
    80003814:	caa080e7          	jalr	-854(ra) # 800024ba <bread>
    80003818:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    8000381a:	000aa583          	lw	a1,0(s5)
    8000381e:	028a2503          	lw	a0,40(s4)
    80003822:	fffff097          	auipc	ra,0xfffff
    80003826:	c98080e7          	jalr	-872(ra) # 800024ba <bread>
    8000382a:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    8000382c:	40000613          	li	a2,1024
    80003830:	05850593          	addi	a1,a0,88
    80003834:	05848513          	addi	a0,s1,88
    80003838:	ffffd097          	auipc	ra,0xffffd
    8000383c:	99e080e7          	jalr	-1634(ra) # 800001d6 <memmove>
    bwrite(to);  // write the log
    80003840:	8526                	mv	a0,s1
    80003842:	fffff097          	auipc	ra,0xfffff
    80003846:	d6a080e7          	jalr	-662(ra) # 800025ac <bwrite>
    brelse(from);
    8000384a:	854e                	mv	a0,s3
    8000384c:	fffff097          	auipc	ra,0xfffff
    80003850:	d9e080e7          	jalr	-610(ra) # 800025ea <brelse>
    brelse(to);
    80003854:	8526                	mv	a0,s1
    80003856:	fffff097          	auipc	ra,0xfffff
    8000385a:	d94080e7          	jalr	-620(ra) # 800025ea <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    8000385e:	2905                	addiw	s2,s2,1
    80003860:	0a91                	addi	s5,s5,4
    80003862:	02ca2783          	lw	a5,44(s4)
    80003866:	f8f94ee3          	blt	s2,a5,80003802 <end_op+0xcc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    8000386a:	00000097          	auipc	ra,0x0
    8000386e:	c8c080e7          	jalr	-884(ra) # 800034f6 <write_head>
    install_trans(0); // Now install writes to home locations
    80003872:	4501                	li	a0,0
    80003874:	00000097          	auipc	ra,0x0
    80003878:	cec080e7          	jalr	-788(ra) # 80003560 <install_trans>
    log.lh.n = 0;
    8000387c:	0001b797          	auipc	a5,0x1b
    80003880:	de07a823          	sw	zero,-528(a5) # 8001e66c <log+0x2c>
    write_head();    // Erase the transaction from the log
    80003884:	00000097          	auipc	ra,0x0
    80003888:	c72080e7          	jalr	-910(ra) # 800034f6 <write_head>
    8000388c:	69e2                	ld	s3,24(sp)
    8000388e:	6a42                	ld	s4,16(sp)
    80003890:	6aa2                	ld	s5,8(sp)
    80003892:	bdc5                	j	80003782 <end_op+0x4c>

0000000080003894 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003894:	1101                	addi	sp,sp,-32
    80003896:	ec06                	sd	ra,24(sp)
    80003898:	e822                	sd	s0,16(sp)
    8000389a:	e426                	sd	s1,8(sp)
    8000389c:	e04a                	sd	s2,0(sp)
    8000389e:	1000                	addi	s0,sp,32
    800038a0:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    800038a2:	0001b917          	auipc	s2,0x1b
    800038a6:	d9e90913          	addi	s2,s2,-610 # 8001e640 <log>
    800038aa:	854a                	mv	a0,s2
    800038ac:	00003097          	auipc	ra,0x3
    800038b0:	c62080e7          	jalr	-926(ra) # 8000650e <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    800038b4:	02c92603          	lw	a2,44(s2)
    800038b8:	47f5                	li	a5,29
    800038ba:	06c7c563          	blt	a5,a2,80003924 <log_write+0x90>
    800038be:	0001b797          	auipc	a5,0x1b
    800038c2:	d9e7a783          	lw	a5,-610(a5) # 8001e65c <log+0x1c>
    800038c6:	37fd                	addiw	a5,a5,-1
    800038c8:	04f65e63          	bge	a2,a5,80003924 <log_write+0x90>
    panic("too big a transaction");
  if (log.outstanding < 1)
    800038cc:	0001b797          	auipc	a5,0x1b
    800038d0:	d947a783          	lw	a5,-620(a5) # 8001e660 <log+0x20>
    800038d4:	06f05063          	blez	a5,80003934 <log_write+0xa0>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    800038d8:	4781                	li	a5,0
    800038da:	06c05563          	blez	a2,80003944 <log_write+0xb0>
    if (log.lh.block[i] == b->blockno)   // log absorption
    800038de:	44cc                	lw	a1,12(s1)
    800038e0:	0001b717          	auipc	a4,0x1b
    800038e4:	d9070713          	addi	a4,a4,-624 # 8001e670 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    800038e8:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    800038ea:	4314                	lw	a3,0(a4)
    800038ec:	04b68c63          	beq	a3,a1,80003944 <log_write+0xb0>
  for (i = 0; i < log.lh.n; i++) {
    800038f0:	2785                	addiw	a5,a5,1
    800038f2:	0711                	addi	a4,a4,4
    800038f4:	fef61be3          	bne	a2,a5,800038ea <log_write+0x56>
      break;
  }
  log.lh.block[i] = b->blockno;
    800038f8:	0621                	addi	a2,a2,8
    800038fa:	060a                	slli	a2,a2,0x2
    800038fc:	0001b797          	auipc	a5,0x1b
    80003900:	d4478793          	addi	a5,a5,-700 # 8001e640 <log>
    80003904:	97b2                	add	a5,a5,a2
    80003906:	44d8                	lw	a4,12(s1)
    80003908:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    8000390a:	8526                	mv	a0,s1
    8000390c:	fffff097          	auipc	ra,0xfffff
    80003910:	d7a080e7          	jalr	-646(ra) # 80002686 <bpin>
    log.lh.n++;
    80003914:	0001b717          	auipc	a4,0x1b
    80003918:	d2c70713          	addi	a4,a4,-724 # 8001e640 <log>
    8000391c:	575c                	lw	a5,44(a4)
    8000391e:	2785                	addiw	a5,a5,1
    80003920:	d75c                	sw	a5,44(a4)
    80003922:	a82d                	j	8000395c <log_write+0xc8>
    panic("too big a transaction");
    80003924:	00005517          	auipc	a0,0x5
    80003928:	be450513          	addi	a0,a0,-1052 # 80008508 <etext+0x508>
    8000392c:	00002097          	auipc	ra,0x2
    80003930:	660080e7          	jalr	1632(ra) # 80005f8c <panic>
    panic("log_write outside of trans");
    80003934:	00005517          	auipc	a0,0x5
    80003938:	bec50513          	addi	a0,a0,-1044 # 80008520 <etext+0x520>
    8000393c:	00002097          	auipc	ra,0x2
    80003940:	650080e7          	jalr	1616(ra) # 80005f8c <panic>
  log.lh.block[i] = b->blockno;
    80003944:	00878693          	addi	a3,a5,8
    80003948:	068a                	slli	a3,a3,0x2
    8000394a:	0001b717          	auipc	a4,0x1b
    8000394e:	cf670713          	addi	a4,a4,-778 # 8001e640 <log>
    80003952:	9736                	add	a4,a4,a3
    80003954:	44d4                	lw	a3,12(s1)
    80003956:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    80003958:	faf609e3          	beq	a2,a5,8000390a <log_write+0x76>
  }
  release(&log.lock);
    8000395c:	0001b517          	auipc	a0,0x1b
    80003960:	ce450513          	addi	a0,a0,-796 # 8001e640 <log>
    80003964:	00003097          	auipc	ra,0x3
    80003968:	c5e080e7          	jalr	-930(ra) # 800065c2 <release>
}
    8000396c:	60e2                	ld	ra,24(sp)
    8000396e:	6442                	ld	s0,16(sp)
    80003970:	64a2                	ld	s1,8(sp)
    80003972:	6902                	ld	s2,0(sp)
    80003974:	6105                	addi	sp,sp,32
    80003976:	8082                	ret

0000000080003978 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80003978:	1101                	addi	sp,sp,-32
    8000397a:	ec06                	sd	ra,24(sp)
    8000397c:	e822                	sd	s0,16(sp)
    8000397e:	e426                	sd	s1,8(sp)
    80003980:	e04a                	sd	s2,0(sp)
    80003982:	1000                	addi	s0,sp,32
    80003984:	84aa                	mv	s1,a0
    80003986:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80003988:	00005597          	auipc	a1,0x5
    8000398c:	bb858593          	addi	a1,a1,-1096 # 80008540 <etext+0x540>
    80003990:	0521                	addi	a0,a0,8
    80003992:	00003097          	auipc	ra,0x3
    80003996:	aec080e7          	jalr	-1300(ra) # 8000647e <initlock>
  lk->name = name;
    8000399a:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    8000399e:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800039a2:	0204a423          	sw	zero,40(s1)
}
    800039a6:	60e2                	ld	ra,24(sp)
    800039a8:	6442                	ld	s0,16(sp)
    800039aa:	64a2                	ld	s1,8(sp)
    800039ac:	6902                	ld	s2,0(sp)
    800039ae:	6105                	addi	sp,sp,32
    800039b0:	8082                	ret

00000000800039b2 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    800039b2:	1101                	addi	sp,sp,-32
    800039b4:	ec06                	sd	ra,24(sp)
    800039b6:	e822                	sd	s0,16(sp)
    800039b8:	e426                	sd	s1,8(sp)
    800039ba:	e04a                	sd	s2,0(sp)
    800039bc:	1000                	addi	s0,sp,32
    800039be:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800039c0:	00850913          	addi	s2,a0,8
    800039c4:	854a                	mv	a0,s2
    800039c6:	00003097          	auipc	ra,0x3
    800039ca:	b48080e7          	jalr	-1208(ra) # 8000650e <acquire>
  while (lk->locked) {
    800039ce:	409c                	lw	a5,0(s1)
    800039d0:	cb89                	beqz	a5,800039e2 <acquiresleep+0x30>
    sleep(lk, &lk->lk);
    800039d2:	85ca                	mv	a1,s2
    800039d4:	8526                	mv	a0,s1
    800039d6:	ffffe097          	auipc	ra,0xffffe
    800039da:	c30080e7          	jalr	-976(ra) # 80001606 <sleep>
  while (lk->locked) {
    800039de:	409c                	lw	a5,0(s1)
    800039e0:	fbed                	bnez	a5,800039d2 <acquiresleep+0x20>
  }
  lk->locked = 1;
    800039e2:	4785                	li	a5,1
    800039e4:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    800039e6:	ffffd097          	auipc	ra,0xffffd
    800039ea:	520080e7          	jalr	1312(ra) # 80000f06 <myproc>
    800039ee:	591c                	lw	a5,48(a0)
    800039f0:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    800039f2:	854a                	mv	a0,s2
    800039f4:	00003097          	auipc	ra,0x3
    800039f8:	bce080e7          	jalr	-1074(ra) # 800065c2 <release>
}
    800039fc:	60e2                	ld	ra,24(sp)
    800039fe:	6442                	ld	s0,16(sp)
    80003a00:	64a2                	ld	s1,8(sp)
    80003a02:	6902                	ld	s2,0(sp)
    80003a04:	6105                	addi	sp,sp,32
    80003a06:	8082                	ret

0000000080003a08 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80003a08:	1101                	addi	sp,sp,-32
    80003a0a:	ec06                	sd	ra,24(sp)
    80003a0c:	e822                	sd	s0,16(sp)
    80003a0e:	e426                	sd	s1,8(sp)
    80003a10:	e04a                	sd	s2,0(sp)
    80003a12:	1000                	addi	s0,sp,32
    80003a14:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003a16:	00850913          	addi	s2,a0,8
    80003a1a:	854a                	mv	a0,s2
    80003a1c:	00003097          	auipc	ra,0x3
    80003a20:	af2080e7          	jalr	-1294(ra) # 8000650e <acquire>
  lk->locked = 0;
    80003a24:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003a28:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80003a2c:	8526                	mv	a0,s1
    80003a2e:	ffffe097          	auipc	ra,0xffffe
    80003a32:	c3c080e7          	jalr	-964(ra) # 8000166a <wakeup>
  release(&lk->lk);
    80003a36:	854a                	mv	a0,s2
    80003a38:	00003097          	auipc	ra,0x3
    80003a3c:	b8a080e7          	jalr	-1142(ra) # 800065c2 <release>
}
    80003a40:	60e2                	ld	ra,24(sp)
    80003a42:	6442                	ld	s0,16(sp)
    80003a44:	64a2                	ld	s1,8(sp)
    80003a46:	6902                	ld	s2,0(sp)
    80003a48:	6105                	addi	sp,sp,32
    80003a4a:	8082                	ret

0000000080003a4c <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    80003a4c:	7179                	addi	sp,sp,-48
    80003a4e:	f406                	sd	ra,40(sp)
    80003a50:	f022                	sd	s0,32(sp)
    80003a52:	ec26                	sd	s1,24(sp)
    80003a54:	e84a                	sd	s2,16(sp)
    80003a56:	1800                	addi	s0,sp,48
    80003a58:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    80003a5a:	00850913          	addi	s2,a0,8
    80003a5e:	854a                	mv	a0,s2
    80003a60:	00003097          	auipc	ra,0x3
    80003a64:	aae080e7          	jalr	-1362(ra) # 8000650e <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80003a68:	409c                	lw	a5,0(s1)
    80003a6a:	ef91                	bnez	a5,80003a86 <holdingsleep+0x3a>
    80003a6c:	4481                	li	s1,0
  release(&lk->lk);
    80003a6e:	854a                	mv	a0,s2
    80003a70:	00003097          	auipc	ra,0x3
    80003a74:	b52080e7          	jalr	-1198(ra) # 800065c2 <release>
  return r;
}
    80003a78:	8526                	mv	a0,s1
    80003a7a:	70a2                	ld	ra,40(sp)
    80003a7c:	7402                	ld	s0,32(sp)
    80003a7e:	64e2                	ld	s1,24(sp)
    80003a80:	6942                	ld	s2,16(sp)
    80003a82:	6145                	addi	sp,sp,48
    80003a84:	8082                	ret
    80003a86:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    80003a88:	0284a983          	lw	s3,40(s1)
    80003a8c:	ffffd097          	auipc	ra,0xffffd
    80003a90:	47a080e7          	jalr	1146(ra) # 80000f06 <myproc>
    80003a94:	5904                	lw	s1,48(a0)
    80003a96:	413484b3          	sub	s1,s1,s3
    80003a9a:	0014b493          	seqz	s1,s1
    80003a9e:	69a2                	ld	s3,8(sp)
    80003aa0:	b7f9                	j	80003a6e <holdingsleep+0x22>

0000000080003aa2 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80003aa2:	1141                	addi	sp,sp,-16
    80003aa4:	e406                	sd	ra,8(sp)
    80003aa6:	e022                	sd	s0,0(sp)
    80003aa8:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    80003aaa:	00005597          	auipc	a1,0x5
    80003aae:	aa658593          	addi	a1,a1,-1370 # 80008550 <etext+0x550>
    80003ab2:	0001b517          	auipc	a0,0x1b
    80003ab6:	cd650513          	addi	a0,a0,-810 # 8001e788 <ftable>
    80003aba:	00003097          	auipc	ra,0x3
    80003abe:	9c4080e7          	jalr	-1596(ra) # 8000647e <initlock>
}
    80003ac2:	60a2                	ld	ra,8(sp)
    80003ac4:	6402                	ld	s0,0(sp)
    80003ac6:	0141                	addi	sp,sp,16
    80003ac8:	8082                	ret

0000000080003aca <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    80003aca:	1101                	addi	sp,sp,-32
    80003acc:	ec06                	sd	ra,24(sp)
    80003ace:	e822                	sd	s0,16(sp)
    80003ad0:	e426                	sd	s1,8(sp)
    80003ad2:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80003ad4:	0001b517          	auipc	a0,0x1b
    80003ad8:	cb450513          	addi	a0,a0,-844 # 8001e788 <ftable>
    80003adc:	00003097          	auipc	ra,0x3
    80003ae0:	a32080e7          	jalr	-1486(ra) # 8000650e <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003ae4:	0001b497          	auipc	s1,0x1b
    80003ae8:	cbc48493          	addi	s1,s1,-836 # 8001e7a0 <ftable+0x18>
    80003aec:	0001c717          	auipc	a4,0x1c
    80003af0:	c5470713          	addi	a4,a4,-940 # 8001f740 <disk>
    if(f->ref == 0){
    80003af4:	40dc                	lw	a5,4(s1)
    80003af6:	cf99                	beqz	a5,80003b14 <filealloc+0x4a>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003af8:	02848493          	addi	s1,s1,40
    80003afc:	fee49ce3          	bne	s1,a4,80003af4 <filealloc+0x2a>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80003b00:	0001b517          	auipc	a0,0x1b
    80003b04:	c8850513          	addi	a0,a0,-888 # 8001e788 <ftable>
    80003b08:	00003097          	auipc	ra,0x3
    80003b0c:	aba080e7          	jalr	-1350(ra) # 800065c2 <release>
  return 0;
    80003b10:	4481                	li	s1,0
    80003b12:	a819                	j	80003b28 <filealloc+0x5e>
      f->ref = 1;
    80003b14:	4785                	li	a5,1
    80003b16:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80003b18:	0001b517          	auipc	a0,0x1b
    80003b1c:	c7050513          	addi	a0,a0,-912 # 8001e788 <ftable>
    80003b20:	00003097          	auipc	ra,0x3
    80003b24:	aa2080e7          	jalr	-1374(ra) # 800065c2 <release>
}
    80003b28:	8526                	mv	a0,s1
    80003b2a:	60e2                	ld	ra,24(sp)
    80003b2c:	6442                	ld	s0,16(sp)
    80003b2e:	64a2                	ld	s1,8(sp)
    80003b30:	6105                	addi	sp,sp,32
    80003b32:	8082                	ret

0000000080003b34 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    80003b34:	1101                	addi	sp,sp,-32
    80003b36:	ec06                	sd	ra,24(sp)
    80003b38:	e822                	sd	s0,16(sp)
    80003b3a:	e426                	sd	s1,8(sp)
    80003b3c:	1000                	addi	s0,sp,32
    80003b3e:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80003b40:	0001b517          	auipc	a0,0x1b
    80003b44:	c4850513          	addi	a0,a0,-952 # 8001e788 <ftable>
    80003b48:	00003097          	auipc	ra,0x3
    80003b4c:	9c6080e7          	jalr	-1594(ra) # 8000650e <acquire>
  if(f->ref < 1)
    80003b50:	40dc                	lw	a5,4(s1)
    80003b52:	02f05263          	blez	a5,80003b76 <filedup+0x42>
    panic("filedup");
  f->ref++;
    80003b56:	2785                	addiw	a5,a5,1
    80003b58:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80003b5a:	0001b517          	auipc	a0,0x1b
    80003b5e:	c2e50513          	addi	a0,a0,-978 # 8001e788 <ftable>
    80003b62:	00003097          	auipc	ra,0x3
    80003b66:	a60080e7          	jalr	-1440(ra) # 800065c2 <release>
  return f;
}
    80003b6a:	8526                	mv	a0,s1
    80003b6c:	60e2                	ld	ra,24(sp)
    80003b6e:	6442                	ld	s0,16(sp)
    80003b70:	64a2                	ld	s1,8(sp)
    80003b72:	6105                	addi	sp,sp,32
    80003b74:	8082                	ret
    panic("filedup");
    80003b76:	00005517          	auipc	a0,0x5
    80003b7a:	9e250513          	addi	a0,a0,-1566 # 80008558 <etext+0x558>
    80003b7e:	00002097          	auipc	ra,0x2
    80003b82:	40e080e7          	jalr	1038(ra) # 80005f8c <panic>

0000000080003b86 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80003b86:	7139                	addi	sp,sp,-64
    80003b88:	fc06                	sd	ra,56(sp)
    80003b8a:	f822                	sd	s0,48(sp)
    80003b8c:	f426                	sd	s1,40(sp)
    80003b8e:	0080                	addi	s0,sp,64
    80003b90:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80003b92:	0001b517          	auipc	a0,0x1b
    80003b96:	bf650513          	addi	a0,a0,-1034 # 8001e788 <ftable>
    80003b9a:	00003097          	auipc	ra,0x3
    80003b9e:	974080e7          	jalr	-1676(ra) # 8000650e <acquire>
  if(f->ref < 1)
    80003ba2:	40dc                	lw	a5,4(s1)
    80003ba4:	04f05c63          	blez	a5,80003bfc <fileclose+0x76>
    panic("fileclose");
  if(--f->ref > 0){
    80003ba8:	37fd                	addiw	a5,a5,-1
    80003baa:	0007871b          	sext.w	a4,a5
    80003bae:	c0dc                	sw	a5,4(s1)
    80003bb0:	06e04263          	bgtz	a4,80003c14 <fileclose+0x8e>
    80003bb4:	f04a                	sd	s2,32(sp)
    80003bb6:	ec4e                	sd	s3,24(sp)
    80003bb8:	e852                	sd	s4,16(sp)
    80003bba:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80003bbc:	0004a903          	lw	s2,0(s1)
    80003bc0:	0094ca83          	lbu	s5,9(s1)
    80003bc4:	0104ba03          	ld	s4,16(s1)
    80003bc8:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    80003bcc:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80003bd0:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80003bd4:	0001b517          	auipc	a0,0x1b
    80003bd8:	bb450513          	addi	a0,a0,-1100 # 8001e788 <ftable>
    80003bdc:	00003097          	auipc	ra,0x3
    80003be0:	9e6080e7          	jalr	-1562(ra) # 800065c2 <release>

  if(ff.type == FD_PIPE){
    80003be4:	4785                	li	a5,1
    80003be6:	04f90463          	beq	s2,a5,80003c2e <fileclose+0xa8>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    80003bea:	3979                	addiw	s2,s2,-2
    80003bec:	4785                	li	a5,1
    80003bee:	0527fb63          	bgeu	a5,s2,80003c44 <fileclose+0xbe>
    80003bf2:	7902                	ld	s2,32(sp)
    80003bf4:	69e2                	ld	s3,24(sp)
    80003bf6:	6a42                	ld	s4,16(sp)
    80003bf8:	6aa2                	ld	s5,8(sp)
    80003bfa:	a02d                	j	80003c24 <fileclose+0x9e>
    80003bfc:	f04a                	sd	s2,32(sp)
    80003bfe:	ec4e                	sd	s3,24(sp)
    80003c00:	e852                	sd	s4,16(sp)
    80003c02:	e456                	sd	s5,8(sp)
    panic("fileclose");
    80003c04:	00005517          	auipc	a0,0x5
    80003c08:	95c50513          	addi	a0,a0,-1700 # 80008560 <etext+0x560>
    80003c0c:	00002097          	auipc	ra,0x2
    80003c10:	380080e7          	jalr	896(ra) # 80005f8c <panic>
    release(&ftable.lock);
    80003c14:	0001b517          	auipc	a0,0x1b
    80003c18:	b7450513          	addi	a0,a0,-1164 # 8001e788 <ftable>
    80003c1c:	00003097          	auipc	ra,0x3
    80003c20:	9a6080e7          	jalr	-1626(ra) # 800065c2 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    80003c24:	70e2                	ld	ra,56(sp)
    80003c26:	7442                	ld	s0,48(sp)
    80003c28:	74a2                	ld	s1,40(sp)
    80003c2a:	6121                	addi	sp,sp,64
    80003c2c:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80003c2e:	85d6                	mv	a1,s5
    80003c30:	8552                	mv	a0,s4
    80003c32:	00000097          	auipc	ra,0x0
    80003c36:	3a2080e7          	jalr	930(ra) # 80003fd4 <pipeclose>
    80003c3a:	7902                	ld	s2,32(sp)
    80003c3c:	69e2                	ld	s3,24(sp)
    80003c3e:	6a42                	ld	s4,16(sp)
    80003c40:	6aa2                	ld	s5,8(sp)
    80003c42:	b7cd                	j	80003c24 <fileclose+0x9e>
    begin_op();
    80003c44:	00000097          	auipc	ra,0x0
    80003c48:	a78080e7          	jalr	-1416(ra) # 800036bc <begin_op>
    iput(ff.ip);
    80003c4c:	854e                	mv	a0,s3
    80003c4e:	fffff097          	auipc	ra,0xfffff
    80003c52:	25e080e7          	jalr	606(ra) # 80002eac <iput>
    end_op();
    80003c56:	00000097          	auipc	ra,0x0
    80003c5a:	ae0080e7          	jalr	-1312(ra) # 80003736 <end_op>
    80003c5e:	7902                	ld	s2,32(sp)
    80003c60:	69e2                	ld	s3,24(sp)
    80003c62:	6a42                	ld	s4,16(sp)
    80003c64:	6aa2                	ld	s5,8(sp)
    80003c66:	bf7d                	j	80003c24 <fileclose+0x9e>

0000000080003c68 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    80003c68:	715d                	addi	sp,sp,-80
    80003c6a:	e486                	sd	ra,72(sp)
    80003c6c:	e0a2                	sd	s0,64(sp)
    80003c6e:	fc26                	sd	s1,56(sp)
    80003c70:	f44e                	sd	s3,40(sp)
    80003c72:	0880                	addi	s0,sp,80
    80003c74:	84aa                	mv	s1,a0
    80003c76:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    80003c78:	ffffd097          	auipc	ra,0xffffd
    80003c7c:	28e080e7          	jalr	654(ra) # 80000f06 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    80003c80:	409c                	lw	a5,0(s1)
    80003c82:	37f9                	addiw	a5,a5,-2
    80003c84:	4705                	li	a4,1
    80003c86:	04f76863          	bltu	a4,a5,80003cd6 <filestat+0x6e>
    80003c8a:	f84a                	sd	s2,48(sp)
    80003c8c:	892a                	mv	s2,a0
    ilock(f->ip);
    80003c8e:	6c88                	ld	a0,24(s1)
    80003c90:	fffff097          	auipc	ra,0xfffff
    80003c94:	05e080e7          	jalr	94(ra) # 80002cee <ilock>
    stati(f->ip, &st);
    80003c98:	fb840593          	addi	a1,s0,-72
    80003c9c:	6c88                	ld	a0,24(s1)
    80003c9e:	fffff097          	auipc	ra,0xfffff
    80003ca2:	2de080e7          	jalr	734(ra) # 80002f7c <stati>
    iunlock(f->ip);
    80003ca6:	6c88                	ld	a0,24(s1)
    80003ca8:	fffff097          	auipc	ra,0xfffff
    80003cac:	10c080e7          	jalr	268(ra) # 80002db4 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    80003cb0:	46e1                	li	a3,24
    80003cb2:	fb840613          	addi	a2,s0,-72
    80003cb6:	85ce                	mv	a1,s3
    80003cb8:	05093503          	ld	a0,80(s2)
    80003cbc:	ffffd097          	auipc	ra,0xffffd
    80003cc0:	e90080e7          	jalr	-368(ra) # 80000b4c <copyout>
    80003cc4:	41f5551b          	sraiw	a0,a0,0x1f
    80003cc8:	7942                	ld	s2,48(sp)
      return -1;
    return 0;
  }
  return -1;
}
    80003cca:	60a6                	ld	ra,72(sp)
    80003ccc:	6406                	ld	s0,64(sp)
    80003cce:	74e2                	ld	s1,56(sp)
    80003cd0:	79a2                	ld	s3,40(sp)
    80003cd2:	6161                	addi	sp,sp,80
    80003cd4:	8082                	ret
  return -1;
    80003cd6:	557d                	li	a0,-1
    80003cd8:	bfcd                	j	80003cca <filestat+0x62>

0000000080003cda <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80003cda:	7179                	addi	sp,sp,-48
    80003cdc:	f406                	sd	ra,40(sp)
    80003cde:	f022                	sd	s0,32(sp)
    80003ce0:	e84a                	sd	s2,16(sp)
    80003ce2:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    80003ce4:	00854783          	lbu	a5,8(a0)
    80003ce8:	cbc5                	beqz	a5,80003d98 <fileread+0xbe>
    80003cea:	ec26                	sd	s1,24(sp)
    80003cec:	e44e                	sd	s3,8(sp)
    80003cee:	84aa                	mv	s1,a0
    80003cf0:	89ae                	mv	s3,a1
    80003cf2:	8932                	mv	s2,a2
    return -1;

  if(f->type == FD_PIPE){
    80003cf4:	411c                	lw	a5,0(a0)
    80003cf6:	4705                	li	a4,1
    80003cf8:	04e78963          	beq	a5,a4,80003d4a <fileread+0x70>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80003cfc:	470d                	li	a4,3
    80003cfe:	04e78f63          	beq	a5,a4,80003d5c <fileread+0x82>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    80003d02:	4709                	li	a4,2
    80003d04:	08e79263          	bne	a5,a4,80003d88 <fileread+0xae>
    ilock(f->ip);
    80003d08:	6d08                	ld	a0,24(a0)
    80003d0a:	fffff097          	auipc	ra,0xfffff
    80003d0e:	fe4080e7          	jalr	-28(ra) # 80002cee <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80003d12:	874a                	mv	a4,s2
    80003d14:	5094                	lw	a3,32(s1)
    80003d16:	864e                	mv	a2,s3
    80003d18:	4585                	li	a1,1
    80003d1a:	6c88                	ld	a0,24(s1)
    80003d1c:	fffff097          	auipc	ra,0xfffff
    80003d20:	28a080e7          	jalr	650(ra) # 80002fa6 <readi>
    80003d24:	892a                	mv	s2,a0
    80003d26:	00a05563          	blez	a0,80003d30 <fileread+0x56>
      f->off += r;
    80003d2a:	509c                	lw	a5,32(s1)
    80003d2c:	9fa9                	addw	a5,a5,a0
    80003d2e:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80003d30:	6c88                	ld	a0,24(s1)
    80003d32:	fffff097          	auipc	ra,0xfffff
    80003d36:	082080e7          	jalr	130(ra) # 80002db4 <iunlock>
    80003d3a:	64e2                	ld	s1,24(sp)
    80003d3c:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    80003d3e:	854a                	mv	a0,s2
    80003d40:	70a2                	ld	ra,40(sp)
    80003d42:	7402                	ld	s0,32(sp)
    80003d44:	6942                	ld	s2,16(sp)
    80003d46:	6145                	addi	sp,sp,48
    80003d48:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80003d4a:	6908                	ld	a0,16(a0)
    80003d4c:	00000097          	auipc	ra,0x0
    80003d50:	400080e7          	jalr	1024(ra) # 8000414c <piperead>
    80003d54:	892a                	mv	s2,a0
    80003d56:	64e2                	ld	s1,24(sp)
    80003d58:	69a2                	ld	s3,8(sp)
    80003d5a:	b7d5                	j	80003d3e <fileread+0x64>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80003d5c:	02451783          	lh	a5,36(a0)
    80003d60:	03079693          	slli	a3,a5,0x30
    80003d64:	92c1                	srli	a3,a3,0x30
    80003d66:	4725                	li	a4,9
    80003d68:	02d76a63          	bltu	a4,a3,80003d9c <fileread+0xc2>
    80003d6c:	0792                	slli	a5,a5,0x4
    80003d6e:	0001b717          	auipc	a4,0x1b
    80003d72:	97a70713          	addi	a4,a4,-1670 # 8001e6e8 <devsw>
    80003d76:	97ba                	add	a5,a5,a4
    80003d78:	639c                	ld	a5,0(a5)
    80003d7a:	c78d                	beqz	a5,80003da4 <fileread+0xca>
    r = devsw[f->major].read(1, addr, n);
    80003d7c:	4505                	li	a0,1
    80003d7e:	9782                	jalr	a5
    80003d80:	892a                	mv	s2,a0
    80003d82:	64e2                	ld	s1,24(sp)
    80003d84:	69a2                	ld	s3,8(sp)
    80003d86:	bf65                	j	80003d3e <fileread+0x64>
    panic("fileread");
    80003d88:	00004517          	auipc	a0,0x4
    80003d8c:	7e850513          	addi	a0,a0,2024 # 80008570 <etext+0x570>
    80003d90:	00002097          	auipc	ra,0x2
    80003d94:	1fc080e7          	jalr	508(ra) # 80005f8c <panic>
    return -1;
    80003d98:	597d                	li	s2,-1
    80003d9a:	b755                	j	80003d3e <fileread+0x64>
      return -1;
    80003d9c:	597d                	li	s2,-1
    80003d9e:	64e2                	ld	s1,24(sp)
    80003da0:	69a2                	ld	s3,8(sp)
    80003da2:	bf71                	j	80003d3e <fileread+0x64>
    80003da4:	597d                	li	s2,-1
    80003da6:	64e2                	ld	s1,24(sp)
    80003da8:	69a2                	ld	s3,8(sp)
    80003daa:	bf51                	j	80003d3e <fileread+0x64>

0000000080003dac <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    80003dac:	00954783          	lbu	a5,9(a0)
    80003db0:	12078963          	beqz	a5,80003ee2 <filewrite+0x136>
{
    80003db4:	715d                	addi	sp,sp,-80
    80003db6:	e486                	sd	ra,72(sp)
    80003db8:	e0a2                	sd	s0,64(sp)
    80003dba:	f84a                	sd	s2,48(sp)
    80003dbc:	f052                	sd	s4,32(sp)
    80003dbe:	e85a                	sd	s6,16(sp)
    80003dc0:	0880                	addi	s0,sp,80
    80003dc2:	892a                	mv	s2,a0
    80003dc4:	8b2e                	mv	s6,a1
    80003dc6:	8a32                	mv	s4,a2
    return -1;

  if(f->type == FD_PIPE){
    80003dc8:	411c                	lw	a5,0(a0)
    80003dca:	4705                	li	a4,1
    80003dcc:	02e78763          	beq	a5,a4,80003dfa <filewrite+0x4e>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80003dd0:	470d                	li	a4,3
    80003dd2:	02e78a63          	beq	a5,a4,80003e06 <filewrite+0x5a>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    80003dd6:	4709                	li	a4,2
    80003dd8:	0ee79863          	bne	a5,a4,80003ec8 <filewrite+0x11c>
    80003ddc:	f44e                	sd	s3,40(sp)
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    80003dde:	0cc05463          	blez	a2,80003ea6 <filewrite+0xfa>
    80003de2:	fc26                	sd	s1,56(sp)
    80003de4:	ec56                	sd	s5,24(sp)
    80003de6:	e45e                	sd	s7,8(sp)
    80003de8:	e062                	sd	s8,0(sp)
    int i = 0;
    80003dea:	4981                	li	s3,0
      int n1 = n - i;
      if(n1 > max)
    80003dec:	6b85                	lui	s7,0x1
    80003dee:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    80003df2:	6c05                	lui	s8,0x1
    80003df4:	c00c0c1b          	addiw	s8,s8,-1024 # c00 <_entry-0x7ffff400>
    80003df8:	a851                	j	80003e8c <filewrite+0xe0>
    ret = pipewrite(f->pipe, addr, n);
    80003dfa:	6908                	ld	a0,16(a0)
    80003dfc:	00000097          	auipc	ra,0x0
    80003e00:	248080e7          	jalr	584(ra) # 80004044 <pipewrite>
    80003e04:	a85d                	j	80003eba <filewrite+0x10e>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80003e06:	02451783          	lh	a5,36(a0)
    80003e0a:	03079693          	slli	a3,a5,0x30
    80003e0e:	92c1                	srli	a3,a3,0x30
    80003e10:	4725                	li	a4,9
    80003e12:	0cd76a63          	bltu	a4,a3,80003ee6 <filewrite+0x13a>
    80003e16:	0792                	slli	a5,a5,0x4
    80003e18:	0001b717          	auipc	a4,0x1b
    80003e1c:	8d070713          	addi	a4,a4,-1840 # 8001e6e8 <devsw>
    80003e20:	97ba                	add	a5,a5,a4
    80003e22:	679c                	ld	a5,8(a5)
    80003e24:	c3f9                	beqz	a5,80003eea <filewrite+0x13e>
    ret = devsw[f->major].write(1, addr, n);
    80003e26:	4505                	li	a0,1
    80003e28:	9782                	jalr	a5
    80003e2a:	a841                	j	80003eba <filewrite+0x10e>
      if(n1 > max)
    80003e2c:	00048a9b          	sext.w	s5,s1
        n1 = max;

      begin_op();
    80003e30:	00000097          	auipc	ra,0x0
    80003e34:	88c080e7          	jalr	-1908(ra) # 800036bc <begin_op>
      ilock(f->ip);
    80003e38:	01893503          	ld	a0,24(s2)
    80003e3c:	fffff097          	auipc	ra,0xfffff
    80003e40:	eb2080e7          	jalr	-334(ra) # 80002cee <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80003e44:	8756                	mv	a4,s5
    80003e46:	02092683          	lw	a3,32(s2)
    80003e4a:	01698633          	add	a2,s3,s6
    80003e4e:	4585                	li	a1,1
    80003e50:	01893503          	ld	a0,24(s2)
    80003e54:	fffff097          	auipc	ra,0xfffff
    80003e58:	262080e7          	jalr	610(ra) # 800030b6 <writei>
    80003e5c:	84aa                	mv	s1,a0
    80003e5e:	00a05763          	blez	a0,80003e6c <filewrite+0xc0>
        f->off += r;
    80003e62:	02092783          	lw	a5,32(s2)
    80003e66:	9fa9                	addw	a5,a5,a0
    80003e68:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    80003e6c:	01893503          	ld	a0,24(s2)
    80003e70:	fffff097          	auipc	ra,0xfffff
    80003e74:	f44080e7          	jalr	-188(ra) # 80002db4 <iunlock>
      end_op();
    80003e78:	00000097          	auipc	ra,0x0
    80003e7c:	8be080e7          	jalr	-1858(ra) # 80003736 <end_op>

      if(r != n1){
    80003e80:	029a9563          	bne	s5,s1,80003eaa <filewrite+0xfe>
        // error from writei
        break;
      }
      i += r;
    80003e84:	013489bb          	addw	s3,s1,s3
    while(i < n){
    80003e88:	0149da63          	bge	s3,s4,80003e9c <filewrite+0xf0>
      int n1 = n - i;
    80003e8c:	413a04bb          	subw	s1,s4,s3
      if(n1 > max)
    80003e90:	0004879b          	sext.w	a5,s1
    80003e94:	f8fbdce3          	bge	s7,a5,80003e2c <filewrite+0x80>
    80003e98:	84e2                	mv	s1,s8
    80003e9a:	bf49                	j	80003e2c <filewrite+0x80>
    80003e9c:	74e2                	ld	s1,56(sp)
    80003e9e:	6ae2                	ld	s5,24(sp)
    80003ea0:	6ba2                	ld	s7,8(sp)
    80003ea2:	6c02                	ld	s8,0(sp)
    80003ea4:	a039                	j	80003eb2 <filewrite+0x106>
    int i = 0;
    80003ea6:	4981                	li	s3,0
    80003ea8:	a029                	j	80003eb2 <filewrite+0x106>
    80003eaa:	74e2                	ld	s1,56(sp)
    80003eac:	6ae2                	ld	s5,24(sp)
    80003eae:	6ba2                	ld	s7,8(sp)
    80003eb0:	6c02                	ld	s8,0(sp)
    }
    ret = (i == n ? n : -1);
    80003eb2:	033a1e63          	bne	s4,s3,80003eee <filewrite+0x142>
    80003eb6:	8552                	mv	a0,s4
    80003eb8:	79a2                	ld	s3,40(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80003eba:	60a6                	ld	ra,72(sp)
    80003ebc:	6406                	ld	s0,64(sp)
    80003ebe:	7942                	ld	s2,48(sp)
    80003ec0:	7a02                	ld	s4,32(sp)
    80003ec2:	6b42                	ld	s6,16(sp)
    80003ec4:	6161                	addi	sp,sp,80
    80003ec6:	8082                	ret
    80003ec8:	fc26                	sd	s1,56(sp)
    80003eca:	f44e                	sd	s3,40(sp)
    80003ecc:	ec56                	sd	s5,24(sp)
    80003ece:	e45e                	sd	s7,8(sp)
    80003ed0:	e062                	sd	s8,0(sp)
    panic("filewrite");
    80003ed2:	00004517          	auipc	a0,0x4
    80003ed6:	6ae50513          	addi	a0,a0,1710 # 80008580 <etext+0x580>
    80003eda:	00002097          	auipc	ra,0x2
    80003ede:	0b2080e7          	jalr	178(ra) # 80005f8c <panic>
    return -1;
    80003ee2:	557d                	li	a0,-1
}
    80003ee4:	8082                	ret
      return -1;
    80003ee6:	557d                	li	a0,-1
    80003ee8:	bfc9                	j	80003eba <filewrite+0x10e>
    80003eea:	557d                	li	a0,-1
    80003eec:	b7f9                	j	80003eba <filewrite+0x10e>
    ret = (i == n ? n : -1);
    80003eee:	557d                	li	a0,-1
    80003ef0:	79a2                	ld	s3,40(sp)
    80003ef2:	b7e1                	j	80003eba <filewrite+0x10e>

0000000080003ef4 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80003ef4:	7179                	addi	sp,sp,-48
    80003ef6:	f406                	sd	ra,40(sp)
    80003ef8:	f022                	sd	s0,32(sp)
    80003efa:	ec26                	sd	s1,24(sp)
    80003efc:	e052                	sd	s4,0(sp)
    80003efe:	1800                	addi	s0,sp,48
    80003f00:	84aa                	mv	s1,a0
    80003f02:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    80003f04:	0005b023          	sd	zero,0(a1)
    80003f08:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    80003f0c:	00000097          	auipc	ra,0x0
    80003f10:	bbe080e7          	jalr	-1090(ra) # 80003aca <filealloc>
    80003f14:	e088                	sd	a0,0(s1)
    80003f16:	cd49                	beqz	a0,80003fb0 <pipealloc+0xbc>
    80003f18:	00000097          	auipc	ra,0x0
    80003f1c:	bb2080e7          	jalr	-1102(ra) # 80003aca <filealloc>
    80003f20:	00aa3023          	sd	a0,0(s4)
    80003f24:	c141                	beqz	a0,80003fa4 <pipealloc+0xb0>
    80003f26:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    80003f28:	ffffc097          	auipc	ra,0xffffc
    80003f2c:	1f2080e7          	jalr	498(ra) # 8000011a <kalloc>
    80003f30:	892a                	mv	s2,a0
    80003f32:	c13d                	beqz	a0,80003f98 <pipealloc+0xa4>
    80003f34:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    80003f36:	4985                	li	s3,1
    80003f38:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    80003f3c:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80003f40:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80003f44:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80003f48:	00004597          	auipc	a1,0x4
    80003f4c:	64858593          	addi	a1,a1,1608 # 80008590 <etext+0x590>
    80003f50:	00002097          	auipc	ra,0x2
    80003f54:	52e080e7          	jalr	1326(ra) # 8000647e <initlock>
  (*f0)->type = FD_PIPE;
    80003f58:	609c                	ld	a5,0(s1)
    80003f5a:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80003f5e:	609c                	ld	a5,0(s1)
    80003f60:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80003f64:	609c                	ld	a5,0(s1)
    80003f66:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80003f6a:	609c                	ld	a5,0(s1)
    80003f6c:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80003f70:	000a3783          	ld	a5,0(s4)
    80003f74:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80003f78:	000a3783          	ld	a5,0(s4)
    80003f7c:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80003f80:	000a3783          	ld	a5,0(s4)
    80003f84:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80003f88:	000a3783          	ld	a5,0(s4)
    80003f8c:	0127b823          	sd	s2,16(a5)
  return 0;
    80003f90:	4501                	li	a0,0
    80003f92:	6942                	ld	s2,16(sp)
    80003f94:	69a2                	ld	s3,8(sp)
    80003f96:	a03d                	j	80003fc4 <pipealloc+0xd0>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    80003f98:	6088                	ld	a0,0(s1)
    80003f9a:	c119                	beqz	a0,80003fa0 <pipealloc+0xac>
    80003f9c:	6942                	ld	s2,16(sp)
    80003f9e:	a029                	j	80003fa8 <pipealloc+0xb4>
    80003fa0:	6942                	ld	s2,16(sp)
    80003fa2:	a039                	j	80003fb0 <pipealloc+0xbc>
    80003fa4:	6088                	ld	a0,0(s1)
    80003fa6:	c50d                	beqz	a0,80003fd0 <pipealloc+0xdc>
    fileclose(*f0);
    80003fa8:	00000097          	auipc	ra,0x0
    80003fac:	bde080e7          	jalr	-1058(ra) # 80003b86 <fileclose>
  if(*f1)
    80003fb0:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80003fb4:	557d                	li	a0,-1
  if(*f1)
    80003fb6:	c799                	beqz	a5,80003fc4 <pipealloc+0xd0>
    fileclose(*f1);
    80003fb8:	853e                	mv	a0,a5
    80003fba:	00000097          	auipc	ra,0x0
    80003fbe:	bcc080e7          	jalr	-1076(ra) # 80003b86 <fileclose>
  return -1;
    80003fc2:	557d                	li	a0,-1
}
    80003fc4:	70a2                	ld	ra,40(sp)
    80003fc6:	7402                	ld	s0,32(sp)
    80003fc8:	64e2                	ld	s1,24(sp)
    80003fca:	6a02                	ld	s4,0(sp)
    80003fcc:	6145                	addi	sp,sp,48
    80003fce:	8082                	ret
  return -1;
    80003fd0:	557d                	li	a0,-1
    80003fd2:	bfcd                	j	80003fc4 <pipealloc+0xd0>

0000000080003fd4 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80003fd4:	1101                	addi	sp,sp,-32
    80003fd6:	ec06                	sd	ra,24(sp)
    80003fd8:	e822                	sd	s0,16(sp)
    80003fda:	e426                	sd	s1,8(sp)
    80003fdc:	e04a                	sd	s2,0(sp)
    80003fde:	1000                	addi	s0,sp,32
    80003fe0:	84aa                	mv	s1,a0
    80003fe2:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80003fe4:	00002097          	auipc	ra,0x2
    80003fe8:	52a080e7          	jalr	1322(ra) # 8000650e <acquire>
  if(writable){
    80003fec:	02090d63          	beqz	s2,80004026 <pipeclose+0x52>
    pi->writeopen = 0;
    80003ff0:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80003ff4:	21848513          	addi	a0,s1,536
    80003ff8:	ffffd097          	auipc	ra,0xffffd
    80003ffc:	672080e7          	jalr	1650(ra) # 8000166a <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    80004000:	2204b783          	ld	a5,544(s1)
    80004004:	eb95                	bnez	a5,80004038 <pipeclose+0x64>
    release(&pi->lock);
    80004006:	8526                	mv	a0,s1
    80004008:	00002097          	auipc	ra,0x2
    8000400c:	5ba080e7          	jalr	1466(ra) # 800065c2 <release>
    kfree((char*)pi);
    80004010:	8526                	mv	a0,s1
    80004012:	ffffc097          	auipc	ra,0xffffc
    80004016:	00a080e7          	jalr	10(ra) # 8000001c <kfree>
  } else
    release(&pi->lock);
}
    8000401a:	60e2                	ld	ra,24(sp)
    8000401c:	6442                	ld	s0,16(sp)
    8000401e:	64a2                	ld	s1,8(sp)
    80004020:	6902                	ld	s2,0(sp)
    80004022:	6105                	addi	sp,sp,32
    80004024:	8082                	ret
    pi->readopen = 0;
    80004026:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    8000402a:	21c48513          	addi	a0,s1,540
    8000402e:	ffffd097          	auipc	ra,0xffffd
    80004032:	63c080e7          	jalr	1596(ra) # 8000166a <wakeup>
    80004036:	b7e9                	j	80004000 <pipeclose+0x2c>
    release(&pi->lock);
    80004038:	8526                	mv	a0,s1
    8000403a:	00002097          	auipc	ra,0x2
    8000403e:	588080e7          	jalr	1416(ra) # 800065c2 <release>
}
    80004042:	bfe1                	j	8000401a <pipeclose+0x46>

0000000080004044 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80004044:	711d                	addi	sp,sp,-96
    80004046:	ec86                	sd	ra,88(sp)
    80004048:	e8a2                	sd	s0,80(sp)
    8000404a:	e4a6                	sd	s1,72(sp)
    8000404c:	e0ca                	sd	s2,64(sp)
    8000404e:	fc4e                	sd	s3,56(sp)
    80004050:	f852                	sd	s4,48(sp)
    80004052:	f456                	sd	s5,40(sp)
    80004054:	1080                	addi	s0,sp,96
    80004056:	84aa                	mv	s1,a0
    80004058:	8aae                	mv	s5,a1
    8000405a:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    8000405c:	ffffd097          	auipc	ra,0xffffd
    80004060:	eaa080e7          	jalr	-342(ra) # 80000f06 <myproc>
    80004064:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004066:	8526                	mv	a0,s1
    80004068:	00002097          	auipc	ra,0x2
    8000406c:	4a6080e7          	jalr	1190(ra) # 8000650e <acquire>
  while(i < n){
    80004070:	0d405863          	blez	s4,80004140 <pipewrite+0xfc>
    80004074:	f05a                	sd	s6,32(sp)
    80004076:	ec5e                	sd	s7,24(sp)
    80004078:	e862                	sd	s8,16(sp)
  int i = 0;
    8000407a:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    8000407c:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    8000407e:	21848c13          	addi	s8,s1,536
      sleep(&pi->nwrite, &pi->lock);
    80004082:	21c48b93          	addi	s7,s1,540
    80004086:	a089                	j	800040c8 <pipewrite+0x84>
      release(&pi->lock);
    80004088:	8526                	mv	a0,s1
    8000408a:	00002097          	auipc	ra,0x2
    8000408e:	538080e7          	jalr	1336(ra) # 800065c2 <release>
      return -1;
    80004092:	597d                	li	s2,-1
    80004094:	7b02                	ld	s6,32(sp)
    80004096:	6be2                	ld	s7,24(sp)
    80004098:	6c42                	ld	s8,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    8000409a:	854a                	mv	a0,s2
    8000409c:	60e6                	ld	ra,88(sp)
    8000409e:	6446                	ld	s0,80(sp)
    800040a0:	64a6                	ld	s1,72(sp)
    800040a2:	6906                	ld	s2,64(sp)
    800040a4:	79e2                	ld	s3,56(sp)
    800040a6:	7a42                	ld	s4,48(sp)
    800040a8:	7aa2                	ld	s5,40(sp)
    800040aa:	6125                	addi	sp,sp,96
    800040ac:	8082                	ret
      wakeup(&pi->nread);
    800040ae:	8562                	mv	a0,s8
    800040b0:	ffffd097          	auipc	ra,0xffffd
    800040b4:	5ba080e7          	jalr	1466(ra) # 8000166a <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    800040b8:	85a6                	mv	a1,s1
    800040ba:	855e                	mv	a0,s7
    800040bc:	ffffd097          	auipc	ra,0xffffd
    800040c0:	54a080e7          	jalr	1354(ra) # 80001606 <sleep>
  while(i < n){
    800040c4:	05495f63          	bge	s2,s4,80004122 <pipewrite+0xde>
    if(pi->readopen == 0 || killed(pr)){
    800040c8:	2204a783          	lw	a5,544(s1)
    800040cc:	dfd5                	beqz	a5,80004088 <pipewrite+0x44>
    800040ce:	854e                	mv	a0,s3
    800040d0:	ffffd097          	auipc	ra,0xffffd
    800040d4:	7de080e7          	jalr	2014(ra) # 800018ae <killed>
    800040d8:	f945                	bnez	a0,80004088 <pipewrite+0x44>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    800040da:	2184a783          	lw	a5,536(s1)
    800040de:	21c4a703          	lw	a4,540(s1)
    800040e2:	2007879b          	addiw	a5,a5,512
    800040e6:	fcf704e3          	beq	a4,a5,800040ae <pipewrite+0x6a>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    800040ea:	4685                	li	a3,1
    800040ec:	01590633          	add	a2,s2,s5
    800040f0:	faf40593          	addi	a1,s0,-81
    800040f4:	0509b503          	ld	a0,80(s3)
    800040f8:	ffffd097          	auipc	ra,0xffffd
    800040fc:	b32080e7          	jalr	-1230(ra) # 80000c2a <copyin>
    80004100:	05650263          	beq	a0,s6,80004144 <pipewrite+0x100>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80004104:	21c4a783          	lw	a5,540(s1)
    80004108:	0017871b          	addiw	a4,a5,1
    8000410c:	20e4ae23          	sw	a4,540(s1)
    80004110:	1ff7f793          	andi	a5,a5,511
    80004114:	97a6                	add	a5,a5,s1
    80004116:	faf44703          	lbu	a4,-81(s0)
    8000411a:	00e78c23          	sb	a4,24(a5)
      i++;
    8000411e:	2905                	addiw	s2,s2,1
    80004120:	b755                	j	800040c4 <pipewrite+0x80>
    80004122:	7b02                	ld	s6,32(sp)
    80004124:	6be2                	ld	s7,24(sp)
    80004126:	6c42                	ld	s8,16(sp)
  wakeup(&pi->nread);
    80004128:	21848513          	addi	a0,s1,536
    8000412c:	ffffd097          	auipc	ra,0xffffd
    80004130:	53e080e7          	jalr	1342(ra) # 8000166a <wakeup>
  release(&pi->lock);
    80004134:	8526                	mv	a0,s1
    80004136:	00002097          	auipc	ra,0x2
    8000413a:	48c080e7          	jalr	1164(ra) # 800065c2 <release>
  return i;
    8000413e:	bfb1                	j	8000409a <pipewrite+0x56>
  int i = 0;
    80004140:	4901                	li	s2,0
    80004142:	b7dd                	j	80004128 <pipewrite+0xe4>
    80004144:	7b02                	ld	s6,32(sp)
    80004146:	6be2                	ld	s7,24(sp)
    80004148:	6c42                	ld	s8,16(sp)
    8000414a:	bff9                	j	80004128 <pipewrite+0xe4>

000000008000414c <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    8000414c:	715d                	addi	sp,sp,-80
    8000414e:	e486                	sd	ra,72(sp)
    80004150:	e0a2                	sd	s0,64(sp)
    80004152:	fc26                	sd	s1,56(sp)
    80004154:	f84a                	sd	s2,48(sp)
    80004156:	f44e                	sd	s3,40(sp)
    80004158:	f052                	sd	s4,32(sp)
    8000415a:	ec56                	sd	s5,24(sp)
    8000415c:	0880                	addi	s0,sp,80
    8000415e:	84aa                	mv	s1,a0
    80004160:	892e                	mv	s2,a1
    80004162:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80004164:	ffffd097          	auipc	ra,0xffffd
    80004168:	da2080e7          	jalr	-606(ra) # 80000f06 <myproc>
    8000416c:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    8000416e:	8526                	mv	a0,s1
    80004170:	00002097          	auipc	ra,0x2
    80004174:	39e080e7          	jalr	926(ra) # 8000650e <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004178:	2184a703          	lw	a4,536(s1)
    8000417c:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004180:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004184:	02f71963          	bne	a4,a5,800041b6 <piperead+0x6a>
    80004188:	2244a783          	lw	a5,548(s1)
    8000418c:	cf95                	beqz	a5,800041c8 <piperead+0x7c>
    if(killed(pr)){
    8000418e:	8552                	mv	a0,s4
    80004190:	ffffd097          	auipc	ra,0xffffd
    80004194:	71e080e7          	jalr	1822(ra) # 800018ae <killed>
    80004198:	e10d                	bnez	a0,800041ba <piperead+0x6e>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    8000419a:	85a6                	mv	a1,s1
    8000419c:	854e                	mv	a0,s3
    8000419e:	ffffd097          	auipc	ra,0xffffd
    800041a2:	468080e7          	jalr	1128(ra) # 80001606 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800041a6:	2184a703          	lw	a4,536(s1)
    800041aa:	21c4a783          	lw	a5,540(s1)
    800041ae:	fcf70de3          	beq	a4,a5,80004188 <piperead+0x3c>
    800041b2:	e85a                	sd	s6,16(sp)
    800041b4:	a819                	j	800041ca <piperead+0x7e>
    800041b6:	e85a                	sd	s6,16(sp)
    800041b8:	a809                	j	800041ca <piperead+0x7e>
      release(&pi->lock);
    800041ba:	8526                	mv	a0,s1
    800041bc:	00002097          	auipc	ra,0x2
    800041c0:	406080e7          	jalr	1030(ra) # 800065c2 <release>
      return -1;
    800041c4:	59fd                	li	s3,-1
    800041c6:	a0a5                	j	8000422e <piperead+0xe2>
    800041c8:	e85a                	sd	s6,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    800041ca:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    800041cc:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    800041ce:	05505463          	blez	s5,80004216 <piperead+0xca>
    if(pi->nread == pi->nwrite)
    800041d2:	2184a783          	lw	a5,536(s1)
    800041d6:	21c4a703          	lw	a4,540(s1)
    800041da:	02f70e63          	beq	a4,a5,80004216 <piperead+0xca>
    ch = pi->data[pi->nread++ % PIPESIZE];
    800041de:	0017871b          	addiw	a4,a5,1
    800041e2:	20e4ac23          	sw	a4,536(s1)
    800041e6:	1ff7f793          	andi	a5,a5,511
    800041ea:	97a6                	add	a5,a5,s1
    800041ec:	0187c783          	lbu	a5,24(a5)
    800041f0:	faf40fa3          	sb	a5,-65(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    800041f4:	4685                	li	a3,1
    800041f6:	fbf40613          	addi	a2,s0,-65
    800041fa:	85ca                	mv	a1,s2
    800041fc:	050a3503          	ld	a0,80(s4)
    80004200:	ffffd097          	auipc	ra,0xffffd
    80004204:	94c080e7          	jalr	-1716(ra) # 80000b4c <copyout>
    80004208:	01650763          	beq	a0,s6,80004216 <piperead+0xca>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    8000420c:	2985                	addiw	s3,s3,1
    8000420e:	0905                	addi	s2,s2,1
    80004210:	fd3a91e3          	bne	s5,s3,800041d2 <piperead+0x86>
    80004214:	89d6                	mv	s3,s5
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80004216:	21c48513          	addi	a0,s1,540
    8000421a:	ffffd097          	auipc	ra,0xffffd
    8000421e:	450080e7          	jalr	1104(ra) # 8000166a <wakeup>
  release(&pi->lock);
    80004222:	8526                	mv	a0,s1
    80004224:	00002097          	auipc	ra,0x2
    80004228:	39e080e7          	jalr	926(ra) # 800065c2 <release>
    8000422c:	6b42                	ld	s6,16(sp)
  return i;
}
    8000422e:	854e                	mv	a0,s3
    80004230:	60a6                	ld	ra,72(sp)
    80004232:	6406                	ld	s0,64(sp)
    80004234:	74e2                	ld	s1,56(sp)
    80004236:	7942                	ld	s2,48(sp)
    80004238:	79a2                	ld	s3,40(sp)
    8000423a:	7a02                	ld	s4,32(sp)
    8000423c:	6ae2                	ld	s5,24(sp)
    8000423e:	6161                	addi	sp,sp,80
    80004240:	8082                	ret

0000000080004242 <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    80004242:	1141                	addi	sp,sp,-16
    80004244:	e422                	sd	s0,8(sp)
    80004246:	0800                	addi	s0,sp,16
    80004248:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    8000424a:	8905                	andi	a0,a0,1
    8000424c:	050e                	slli	a0,a0,0x3
      perm = PTE_X;
    if(flags & 0x2)
    8000424e:	8b89                	andi	a5,a5,2
    80004250:	c399                	beqz	a5,80004256 <flags2perm+0x14>
      perm |= PTE_W;
    80004252:	00456513          	ori	a0,a0,4
    return perm;
}
    80004256:	6422                	ld	s0,8(sp)
    80004258:	0141                	addi	sp,sp,16
    8000425a:	8082                	ret

000000008000425c <exec>:

int
exec(char *path, char **argv)
{
    8000425c:	df010113          	addi	sp,sp,-528
    80004260:	20113423          	sd	ra,520(sp)
    80004264:	20813023          	sd	s0,512(sp)
    80004268:	ffa6                	sd	s1,504(sp)
    8000426a:	fbca                	sd	s2,496(sp)
    8000426c:	0c00                	addi	s0,sp,528
    8000426e:	892a                	mv	s2,a0
    80004270:	dea43c23          	sd	a0,-520(s0)
    80004274:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004278:	ffffd097          	auipc	ra,0xffffd
    8000427c:	c8e080e7          	jalr	-882(ra) # 80000f06 <myproc>
    80004280:	84aa                	mv	s1,a0

  begin_op();
    80004282:	fffff097          	auipc	ra,0xfffff
    80004286:	43a080e7          	jalr	1082(ra) # 800036bc <begin_op>

  if((ip = namei(path)) == 0){
    8000428a:	854a                	mv	a0,s2
    8000428c:	fffff097          	auipc	ra,0xfffff
    80004290:	230080e7          	jalr	560(ra) # 800034bc <namei>
    80004294:	c135                	beqz	a0,800042f8 <exec+0x9c>
    80004296:	f3d2                	sd	s4,480(sp)
    80004298:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    8000429a:	fffff097          	auipc	ra,0xfffff
    8000429e:	a54080e7          	jalr	-1452(ra) # 80002cee <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    800042a2:	04000713          	li	a4,64
    800042a6:	4681                	li	a3,0
    800042a8:	e5040613          	addi	a2,s0,-432
    800042ac:	4581                	li	a1,0
    800042ae:	8552                	mv	a0,s4
    800042b0:	fffff097          	auipc	ra,0xfffff
    800042b4:	cf6080e7          	jalr	-778(ra) # 80002fa6 <readi>
    800042b8:	04000793          	li	a5,64
    800042bc:	00f51a63          	bne	a0,a5,800042d0 <exec+0x74>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    800042c0:	e5042703          	lw	a4,-432(s0)
    800042c4:	464c47b7          	lui	a5,0x464c4
    800042c8:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    800042cc:	02f70c63          	beq	a4,a5,80004304 <exec+0xa8>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    800042d0:	8552                	mv	a0,s4
    800042d2:	fffff097          	auipc	ra,0xfffff
    800042d6:	c82080e7          	jalr	-894(ra) # 80002f54 <iunlockput>
    end_op();
    800042da:	fffff097          	auipc	ra,0xfffff
    800042de:	45c080e7          	jalr	1116(ra) # 80003736 <end_op>
  }
  return -1;
    800042e2:	557d                	li	a0,-1
    800042e4:	7a1e                	ld	s4,480(sp)
}
    800042e6:	20813083          	ld	ra,520(sp)
    800042ea:	20013403          	ld	s0,512(sp)
    800042ee:	74fe                	ld	s1,504(sp)
    800042f0:	795e                	ld	s2,496(sp)
    800042f2:	21010113          	addi	sp,sp,528
    800042f6:	8082                	ret
    end_op();
    800042f8:	fffff097          	auipc	ra,0xfffff
    800042fc:	43e080e7          	jalr	1086(ra) # 80003736 <end_op>
    return -1;
    80004300:	557d                	li	a0,-1
    80004302:	b7d5                	j	800042e6 <exec+0x8a>
    80004304:	ebda                	sd	s6,464(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    80004306:	8526                	mv	a0,s1
    80004308:	ffffd097          	auipc	ra,0xffffd
    8000430c:	cc6080e7          	jalr	-826(ra) # 80000fce <proc_pagetable>
    80004310:	8b2a                	mv	s6,a0
    80004312:	30050f63          	beqz	a0,80004630 <exec+0x3d4>
    80004316:	f7ce                	sd	s3,488(sp)
    80004318:	efd6                	sd	s5,472(sp)
    8000431a:	e7de                	sd	s7,456(sp)
    8000431c:	e3e2                	sd	s8,448(sp)
    8000431e:	ff66                	sd	s9,440(sp)
    80004320:	fb6a                	sd	s10,432(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004322:	e7042d03          	lw	s10,-400(s0)
    80004326:	e8845783          	lhu	a5,-376(s0)
    8000432a:	14078d63          	beqz	a5,80004484 <exec+0x228>
    8000432e:	f76e                	sd	s11,424(sp)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004330:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004332:	4d81                	li	s11,0
    if(ph.vaddr % PGSIZE != 0)
    80004334:	6c85                	lui	s9,0x1
    80004336:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    8000433a:	def43823          	sd	a5,-528(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    8000433e:	6a85                	lui	s5,0x1
    80004340:	a0b5                	j	800043ac <exec+0x150>
      panic("loadseg: address should exist");
    80004342:	00004517          	auipc	a0,0x4
    80004346:	25650513          	addi	a0,a0,598 # 80008598 <etext+0x598>
    8000434a:	00002097          	auipc	ra,0x2
    8000434e:	c42080e7          	jalr	-958(ra) # 80005f8c <panic>
    if(sz - i < PGSIZE)
    80004352:	2481                	sext.w	s1,s1
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80004354:	8726                	mv	a4,s1
    80004356:	012c06bb          	addw	a3,s8,s2
    8000435a:	4581                	li	a1,0
    8000435c:	8552                	mv	a0,s4
    8000435e:	fffff097          	auipc	ra,0xfffff
    80004362:	c48080e7          	jalr	-952(ra) # 80002fa6 <readi>
    80004366:	2501                	sext.w	a0,a0
    80004368:	28a49863          	bne	s1,a0,800045f8 <exec+0x39c>
  for(i = 0; i < sz; i += PGSIZE){
    8000436c:	012a893b          	addw	s2,s5,s2
    80004370:	03397563          	bgeu	s2,s3,8000439a <exec+0x13e>
    pa = walkaddr(pagetable, va + i);
    80004374:	02091593          	slli	a1,s2,0x20
    80004378:	9181                	srli	a1,a1,0x20
    8000437a:	95de                	add	a1,a1,s7
    8000437c:	855a                	mv	a0,s6
    8000437e:	ffffc097          	auipc	ra,0xffffc
    80004382:	17e080e7          	jalr	382(ra) # 800004fc <walkaddr>
    80004386:	862a                	mv	a2,a0
    if(pa == 0)
    80004388:	dd4d                	beqz	a0,80004342 <exec+0xe6>
    if(sz - i < PGSIZE)
    8000438a:	412984bb          	subw	s1,s3,s2
    8000438e:	0004879b          	sext.w	a5,s1
    80004392:	fcfcf0e3          	bgeu	s9,a5,80004352 <exec+0xf6>
    80004396:	84d6                	mv	s1,s5
    80004398:	bf6d                	j	80004352 <exec+0xf6>
    sz = sz1;
    8000439a:	e0843903          	ld	s2,-504(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    8000439e:	2d85                	addiw	s11,s11,1
    800043a0:	038d0d1b          	addiw	s10,s10,56 # 1038 <_entry-0x7fffefc8>
    800043a4:	e8845783          	lhu	a5,-376(s0)
    800043a8:	08fdd663          	bge	s11,a5,80004434 <exec+0x1d8>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    800043ac:	2d01                	sext.w	s10,s10
    800043ae:	03800713          	li	a4,56
    800043b2:	86ea                	mv	a3,s10
    800043b4:	e1840613          	addi	a2,s0,-488
    800043b8:	4581                	li	a1,0
    800043ba:	8552                	mv	a0,s4
    800043bc:	fffff097          	auipc	ra,0xfffff
    800043c0:	bea080e7          	jalr	-1046(ra) # 80002fa6 <readi>
    800043c4:	03800793          	li	a5,56
    800043c8:	20f51063          	bne	a0,a5,800045c8 <exec+0x36c>
    if(ph.type != ELF_PROG_LOAD)
    800043cc:	e1842783          	lw	a5,-488(s0)
    800043d0:	4705                	li	a4,1
    800043d2:	fce796e3          	bne	a5,a4,8000439e <exec+0x142>
    if(ph.memsz < ph.filesz)
    800043d6:	e4043483          	ld	s1,-448(s0)
    800043da:	e3843783          	ld	a5,-456(s0)
    800043de:	1ef4e963          	bltu	s1,a5,800045d0 <exec+0x374>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    800043e2:	e2843783          	ld	a5,-472(s0)
    800043e6:	94be                	add	s1,s1,a5
    800043e8:	1ef4e863          	bltu	s1,a5,800045d8 <exec+0x37c>
    if(ph.vaddr % PGSIZE != 0)
    800043ec:	df043703          	ld	a4,-528(s0)
    800043f0:	8ff9                	and	a5,a5,a4
    800043f2:	1e079763          	bnez	a5,800045e0 <exec+0x384>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    800043f6:	e1c42503          	lw	a0,-484(s0)
    800043fa:	00000097          	auipc	ra,0x0
    800043fe:	e48080e7          	jalr	-440(ra) # 80004242 <flags2perm>
    80004402:	86aa                	mv	a3,a0
    80004404:	8626                	mv	a2,s1
    80004406:	85ca                	mv	a1,s2
    80004408:	855a                	mv	a0,s6
    8000440a:	ffffc097          	auipc	ra,0xffffc
    8000440e:	4da080e7          	jalr	1242(ra) # 800008e4 <uvmalloc>
    80004412:	e0a43423          	sd	a0,-504(s0)
    80004416:	1c050963          	beqz	a0,800045e8 <exec+0x38c>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    8000441a:	e2843b83          	ld	s7,-472(s0)
    8000441e:	e2042c03          	lw	s8,-480(s0)
    80004422:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004426:	00098463          	beqz	s3,8000442e <exec+0x1d2>
    8000442a:	4901                	li	s2,0
    8000442c:	b7a1                	j	80004374 <exec+0x118>
    sz = sz1;
    8000442e:	e0843903          	ld	s2,-504(s0)
    80004432:	b7b5                	j	8000439e <exec+0x142>
    80004434:	7dba                	ld	s11,424(sp)
  iunlockput(ip);
    80004436:	8552                	mv	a0,s4
    80004438:	fffff097          	auipc	ra,0xfffff
    8000443c:	b1c080e7          	jalr	-1252(ra) # 80002f54 <iunlockput>
  end_op();
    80004440:	fffff097          	auipc	ra,0xfffff
    80004444:	2f6080e7          	jalr	758(ra) # 80003736 <end_op>
  p = myproc();
    80004448:	ffffd097          	auipc	ra,0xffffd
    8000444c:	abe080e7          	jalr	-1346(ra) # 80000f06 <myproc>
    80004450:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    80004452:	04853c83          	ld	s9,72(a0)
  sz = PGROUNDUP(sz);
    80004456:	6985                	lui	s3,0x1
    80004458:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    8000445a:	99ca                	add	s3,s3,s2
    8000445c:	77fd                	lui	a5,0xfffff
    8000445e:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + 2*PGSIZE, PTE_W)) == 0)
    80004462:	4691                	li	a3,4
    80004464:	6609                	lui	a2,0x2
    80004466:	964e                	add	a2,a2,s3
    80004468:	85ce                	mv	a1,s3
    8000446a:	855a                	mv	a0,s6
    8000446c:	ffffc097          	auipc	ra,0xffffc
    80004470:	478080e7          	jalr	1144(ra) # 800008e4 <uvmalloc>
    80004474:	892a                	mv	s2,a0
    80004476:	e0a43423          	sd	a0,-504(s0)
    8000447a:	e519                	bnez	a0,80004488 <exec+0x22c>
  if(pagetable)
    8000447c:	e1343423          	sd	s3,-504(s0)
    80004480:	4a01                	li	s4,0
    80004482:	aaa5                	j	800045fa <exec+0x39e>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004484:	4901                	li	s2,0
    80004486:	bf45                	j	80004436 <exec+0x1da>
  uvmclear(pagetable, sz-2*PGSIZE);
    80004488:	75f9                	lui	a1,0xffffe
    8000448a:	95aa                	add	a1,a1,a0
    8000448c:	855a                	mv	a0,s6
    8000448e:	ffffc097          	auipc	ra,0xffffc
    80004492:	68c080e7          	jalr	1676(ra) # 80000b1a <uvmclear>
  stackbase = sp - PGSIZE;
    80004496:	7bfd                	lui	s7,0xfffff
    80004498:	9bca                	add	s7,s7,s2
  for(argc = 0; argv[argc]; argc++) {
    8000449a:	e0043783          	ld	a5,-512(s0)
    8000449e:	6388                	ld	a0,0(a5)
    800044a0:	c52d                	beqz	a0,8000450a <exec+0x2ae>
    800044a2:	e9040993          	addi	s3,s0,-368
    800044a6:	f9040c13          	addi	s8,s0,-112
    800044aa:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    800044ac:	ffffc097          	auipc	ra,0xffffc
    800044b0:	e42080e7          	jalr	-446(ra) # 800002ee <strlen>
    800044b4:	0015079b          	addiw	a5,a0,1
    800044b8:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    800044bc:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    800044c0:	13796863          	bltu	s2,s7,800045f0 <exec+0x394>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    800044c4:	e0043d03          	ld	s10,-512(s0)
    800044c8:	000d3a03          	ld	s4,0(s10)
    800044cc:	8552                	mv	a0,s4
    800044ce:	ffffc097          	auipc	ra,0xffffc
    800044d2:	e20080e7          	jalr	-480(ra) # 800002ee <strlen>
    800044d6:	0015069b          	addiw	a3,a0,1
    800044da:	8652                	mv	a2,s4
    800044dc:	85ca                	mv	a1,s2
    800044de:	855a                	mv	a0,s6
    800044e0:	ffffc097          	auipc	ra,0xffffc
    800044e4:	66c080e7          	jalr	1644(ra) # 80000b4c <copyout>
    800044e8:	10054663          	bltz	a0,800045f4 <exec+0x398>
    ustack[argc] = sp;
    800044ec:	0129b023          	sd	s2,0(s3)
  for(argc = 0; argv[argc]; argc++) {
    800044f0:	0485                	addi	s1,s1,1
    800044f2:	008d0793          	addi	a5,s10,8
    800044f6:	e0f43023          	sd	a5,-512(s0)
    800044fa:	008d3503          	ld	a0,8(s10)
    800044fe:	c909                	beqz	a0,80004510 <exec+0x2b4>
    if(argc >= MAXARG)
    80004500:	09a1                	addi	s3,s3,8
    80004502:	fb8995e3          	bne	s3,s8,800044ac <exec+0x250>
  ip = 0;
    80004506:	4a01                	li	s4,0
    80004508:	a8cd                	j	800045fa <exec+0x39e>
  sp = sz;
    8000450a:	e0843903          	ld	s2,-504(s0)
  for(argc = 0; argv[argc]; argc++) {
    8000450e:	4481                	li	s1,0
  ustack[argc] = 0;
    80004510:	00349793          	slli	a5,s1,0x3
    80004514:	f9078793          	addi	a5,a5,-112 # ffffffffffffef90 <end+0xffffffff7ffd74d0>
    80004518:	97a2                	add	a5,a5,s0
    8000451a:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    8000451e:	00148693          	addi	a3,s1,1
    80004522:	068e                	slli	a3,a3,0x3
    80004524:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80004528:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    8000452c:	e0843983          	ld	s3,-504(s0)
  if(sp < stackbase)
    80004530:	f57966e3          	bltu	s2,s7,8000447c <exec+0x220>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80004534:	e9040613          	addi	a2,s0,-368
    80004538:	85ca                	mv	a1,s2
    8000453a:	855a                	mv	a0,s6
    8000453c:	ffffc097          	auipc	ra,0xffffc
    80004540:	610080e7          	jalr	1552(ra) # 80000b4c <copyout>
    80004544:	0e054863          	bltz	a0,80004634 <exec+0x3d8>
  p->trapframe->a1 = sp;
    80004548:	058ab783          	ld	a5,88(s5) # 1058 <_entry-0x7fffefa8>
    8000454c:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80004550:	df843783          	ld	a5,-520(s0)
    80004554:	0007c703          	lbu	a4,0(a5)
    80004558:	cf11                	beqz	a4,80004574 <exec+0x318>
    8000455a:	0785                	addi	a5,a5,1
    if(*s == '/')
    8000455c:	02f00693          	li	a3,47
    80004560:	a039                	j	8000456e <exec+0x312>
      last = s+1;
    80004562:	def43c23          	sd	a5,-520(s0)
  for(last=s=path; *s; s++)
    80004566:	0785                	addi	a5,a5,1
    80004568:	fff7c703          	lbu	a4,-1(a5)
    8000456c:	c701                	beqz	a4,80004574 <exec+0x318>
    if(*s == '/')
    8000456e:	fed71ce3          	bne	a4,a3,80004566 <exec+0x30a>
    80004572:	bfc5                	j	80004562 <exec+0x306>
  safestrcpy(p->name, last, sizeof(p->name));
    80004574:	4641                	li	a2,16
    80004576:	df843583          	ld	a1,-520(s0)
    8000457a:	158a8513          	addi	a0,s5,344
    8000457e:	ffffc097          	auipc	ra,0xffffc
    80004582:	d3e080e7          	jalr	-706(ra) # 800002bc <safestrcpy>
  oldpagetable = p->pagetable;
    80004586:	050ab503          	ld	a0,80(s5)
  p->pagetable = pagetable;
    8000458a:	056ab823          	sd	s6,80(s5)
  p->sz = sz;
    8000458e:	e0843783          	ld	a5,-504(s0)
    80004592:	04fab423          	sd	a5,72(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    80004596:	058ab783          	ld	a5,88(s5)
    8000459a:	e6843703          	ld	a4,-408(s0)
    8000459e:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    800045a0:	058ab783          	ld	a5,88(s5)
    800045a4:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    800045a8:	85e6                	mv	a1,s9
    800045aa:	ffffd097          	auipc	ra,0xffffd
    800045ae:	ac0080e7          	jalr	-1344(ra) # 8000106a <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    800045b2:	0004851b          	sext.w	a0,s1
    800045b6:	79be                	ld	s3,488(sp)
    800045b8:	7a1e                	ld	s4,480(sp)
    800045ba:	6afe                	ld	s5,472(sp)
    800045bc:	6b5e                	ld	s6,464(sp)
    800045be:	6bbe                	ld	s7,456(sp)
    800045c0:	6c1e                	ld	s8,448(sp)
    800045c2:	7cfa                	ld	s9,440(sp)
    800045c4:	7d5a                	ld	s10,432(sp)
    800045c6:	b305                	j	800042e6 <exec+0x8a>
    800045c8:	e1243423          	sd	s2,-504(s0)
    800045cc:	7dba                	ld	s11,424(sp)
    800045ce:	a035                	j	800045fa <exec+0x39e>
    800045d0:	e1243423          	sd	s2,-504(s0)
    800045d4:	7dba                	ld	s11,424(sp)
    800045d6:	a015                	j	800045fa <exec+0x39e>
    800045d8:	e1243423          	sd	s2,-504(s0)
    800045dc:	7dba                	ld	s11,424(sp)
    800045de:	a831                	j	800045fa <exec+0x39e>
    800045e0:	e1243423          	sd	s2,-504(s0)
    800045e4:	7dba                	ld	s11,424(sp)
    800045e6:	a811                	j	800045fa <exec+0x39e>
    800045e8:	e1243423          	sd	s2,-504(s0)
    800045ec:	7dba                	ld	s11,424(sp)
    800045ee:	a031                	j	800045fa <exec+0x39e>
  ip = 0;
    800045f0:	4a01                	li	s4,0
    800045f2:	a021                	j	800045fa <exec+0x39e>
    800045f4:	4a01                	li	s4,0
  if(pagetable)
    800045f6:	a011                	j	800045fa <exec+0x39e>
    800045f8:	7dba                	ld	s11,424(sp)
    proc_freepagetable(pagetable, sz);
    800045fa:	e0843583          	ld	a1,-504(s0)
    800045fe:	855a                	mv	a0,s6
    80004600:	ffffd097          	auipc	ra,0xffffd
    80004604:	a6a080e7          	jalr	-1430(ra) # 8000106a <proc_freepagetable>
  return -1;
    80004608:	557d                	li	a0,-1
  if(ip){
    8000460a:	000a1b63          	bnez	s4,80004620 <exec+0x3c4>
    8000460e:	79be                	ld	s3,488(sp)
    80004610:	7a1e                	ld	s4,480(sp)
    80004612:	6afe                	ld	s5,472(sp)
    80004614:	6b5e                	ld	s6,464(sp)
    80004616:	6bbe                	ld	s7,456(sp)
    80004618:	6c1e                	ld	s8,448(sp)
    8000461a:	7cfa                	ld	s9,440(sp)
    8000461c:	7d5a                	ld	s10,432(sp)
    8000461e:	b1e1                	j	800042e6 <exec+0x8a>
    80004620:	79be                	ld	s3,488(sp)
    80004622:	6afe                	ld	s5,472(sp)
    80004624:	6b5e                	ld	s6,464(sp)
    80004626:	6bbe                	ld	s7,456(sp)
    80004628:	6c1e                	ld	s8,448(sp)
    8000462a:	7cfa                	ld	s9,440(sp)
    8000462c:	7d5a                	ld	s10,432(sp)
    8000462e:	b14d                	j	800042d0 <exec+0x74>
    80004630:	6b5e                	ld	s6,464(sp)
    80004632:	b979                	j	800042d0 <exec+0x74>
  sz = sz1;
    80004634:	e0843983          	ld	s3,-504(s0)
    80004638:	b591                	j	8000447c <exec+0x220>

000000008000463a <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    8000463a:	7179                	addi	sp,sp,-48
    8000463c:	f406                	sd	ra,40(sp)
    8000463e:	f022                	sd	s0,32(sp)
    80004640:	ec26                	sd	s1,24(sp)
    80004642:	e84a                	sd	s2,16(sp)
    80004644:	1800                	addi	s0,sp,48
    80004646:	892e                	mv	s2,a1
    80004648:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    8000464a:	fdc40593          	addi	a1,s0,-36
    8000464e:	ffffe097          	auipc	ra,0xffffe
    80004652:	a74080e7          	jalr	-1420(ra) # 800020c2 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80004656:	fdc42703          	lw	a4,-36(s0)
    8000465a:	47bd                	li	a5,15
    8000465c:	02e7eb63          	bltu	a5,a4,80004692 <argfd+0x58>
    80004660:	ffffd097          	auipc	ra,0xffffd
    80004664:	8a6080e7          	jalr	-1882(ra) # 80000f06 <myproc>
    80004668:	fdc42703          	lw	a4,-36(s0)
    8000466c:	01a70793          	addi	a5,a4,26
    80004670:	078e                	slli	a5,a5,0x3
    80004672:	953e                	add	a0,a0,a5
    80004674:	611c                	ld	a5,0(a0)
    80004676:	c385                	beqz	a5,80004696 <argfd+0x5c>
    return -1;
  if(pfd)
    80004678:	00090463          	beqz	s2,80004680 <argfd+0x46>
    *pfd = fd;
    8000467c:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80004680:	4501                	li	a0,0
  if(pf)
    80004682:	c091                	beqz	s1,80004686 <argfd+0x4c>
    *pf = f;
    80004684:	e09c                	sd	a5,0(s1)
}
    80004686:	70a2                	ld	ra,40(sp)
    80004688:	7402                	ld	s0,32(sp)
    8000468a:	64e2                	ld	s1,24(sp)
    8000468c:	6942                	ld	s2,16(sp)
    8000468e:	6145                	addi	sp,sp,48
    80004690:	8082                	ret
    return -1;
    80004692:	557d                	li	a0,-1
    80004694:	bfcd                	j	80004686 <argfd+0x4c>
    80004696:	557d                	li	a0,-1
    80004698:	b7fd                	j	80004686 <argfd+0x4c>

000000008000469a <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    8000469a:	1101                	addi	sp,sp,-32
    8000469c:	ec06                	sd	ra,24(sp)
    8000469e:	e822                	sd	s0,16(sp)
    800046a0:	e426                	sd	s1,8(sp)
    800046a2:	1000                	addi	s0,sp,32
    800046a4:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    800046a6:	ffffd097          	auipc	ra,0xffffd
    800046aa:	860080e7          	jalr	-1952(ra) # 80000f06 <myproc>
    800046ae:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    800046b0:	0d050793          	addi	a5,a0,208
    800046b4:	4501                	li	a0,0
    800046b6:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    800046b8:	6398                	ld	a4,0(a5)
    800046ba:	cb19                	beqz	a4,800046d0 <fdalloc+0x36>
  for(fd = 0; fd < NOFILE; fd++){
    800046bc:	2505                	addiw	a0,a0,1
    800046be:	07a1                	addi	a5,a5,8
    800046c0:	fed51ce3          	bne	a0,a3,800046b8 <fdalloc+0x1e>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    800046c4:	557d                	li	a0,-1
}
    800046c6:	60e2                	ld	ra,24(sp)
    800046c8:	6442                	ld	s0,16(sp)
    800046ca:	64a2                	ld	s1,8(sp)
    800046cc:	6105                	addi	sp,sp,32
    800046ce:	8082                	ret
      p->ofile[fd] = f;
    800046d0:	01a50793          	addi	a5,a0,26
    800046d4:	078e                	slli	a5,a5,0x3
    800046d6:	963e                	add	a2,a2,a5
    800046d8:	e204                	sd	s1,0(a2)
      return fd;
    800046da:	b7f5                	j	800046c6 <fdalloc+0x2c>

00000000800046dc <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    800046dc:	715d                	addi	sp,sp,-80
    800046de:	e486                	sd	ra,72(sp)
    800046e0:	e0a2                	sd	s0,64(sp)
    800046e2:	fc26                	sd	s1,56(sp)
    800046e4:	f84a                	sd	s2,48(sp)
    800046e6:	f44e                	sd	s3,40(sp)
    800046e8:	ec56                	sd	s5,24(sp)
    800046ea:	e85a                	sd	s6,16(sp)
    800046ec:	0880                	addi	s0,sp,80
    800046ee:	8b2e                	mv	s6,a1
    800046f0:	89b2                	mv	s3,a2
    800046f2:	8936                	mv	s2,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    800046f4:	fb040593          	addi	a1,s0,-80
    800046f8:	fffff097          	auipc	ra,0xfffff
    800046fc:	de2080e7          	jalr	-542(ra) # 800034da <nameiparent>
    80004700:	84aa                	mv	s1,a0
    80004702:	14050e63          	beqz	a0,8000485e <create+0x182>
    return 0;

  ilock(dp);
    80004706:	ffffe097          	auipc	ra,0xffffe
    8000470a:	5e8080e7          	jalr	1512(ra) # 80002cee <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    8000470e:	4601                	li	a2,0
    80004710:	fb040593          	addi	a1,s0,-80
    80004714:	8526                	mv	a0,s1
    80004716:	fffff097          	auipc	ra,0xfffff
    8000471a:	ae4080e7          	jalr	-1308(ra) # 800031fa <dirlookup>
    8000471e:	8aaa                	mv	s5,a0
    80004720:	c539                	beqz	a0,8000476e <create+0x92>
    iunlockput(dp);
    80004722:	8526                	mv	a0,s1
    80004724:	fffff097          	auipc	ra,0xfffff
    80004728:	830080e7          	jalr	-2000(ra) # 80002f54 <iunlockput>
    ilock(ip);
    8000472c:	8556                	mv	a0,s5
    8000472e:	ffffe097          	auipc	ra,0xffffe
    80004732:	5c0080e7          	jalr	1472(ra) # 80002cee <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004736:	4789                	li	a5,2
    80004738:	02fb1463          	bne	s6,a5,80004760 <create+0x84>
    8000473c:	044ad783          	lhu	a5,68(s5)
    80004740:	37f9                	addiw	a5,a5,-2
    80004742:	17c2                	slli	a5,a5,0x30
    80004744:	93c1                	srli	a5,a5,0x30
    80004746:	4705                	li	a4,1
    80004748:	00f76c63          	bltu	a4,a5,80004760 <create+0x84>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    8000474c:	8556                	mv	a0,s5
    8000474e:	60a6                	ld	ra,72(sp)
    80004750:	6406                	ld	s0,64(sp)
    80004752:	74e2                	ld	s1,56(sp)
    80004754:	7942                	ld	s2,48(sp)
    80004756:	79a2                	ld	s3,40(sp)
    80004758:	6ae2                	ld	s5,24(sp)
    8000475a:	6b42                	ld	s6,16(sp)
    8000475c:	6161                	addi	sp,sp,80
    8000475e:	8082                	ret
    iunlockput(ip);
    80004760:	8556                	mv	a0,s5
    80004762:	ffffe097          	auipc	ra,0xffffe
    80004766:	7f2080e7          	jalr	2034(ra) # 80002f54 <iunlockput>
    return 0;
    8000476a:	4a81                	li	s5,0
    8000476c:	b7c5                	j	8000474c <create+0x70>
    8000476e:	f052                	sd	s4,32(sp)
  if((ip = ialloc(dp->dev, type)) == 0){
    80004770:	85da                	mv	a1,s6
    80004772:	4088                	lw	a0,0(s1)
    80004774:	ffffe097          	auipc	ra,0xffffe
    80004778:	3d6080e7          	jalr	982(ra) # 80002b4a <ialloc>
    8000477c:	8a2a                	mv	s4,a0
    8000477e:	c531                	beqz	a0,800047ca <create+0xee>
  ilock(ip);
    80004780:	ffffe097          	auipc	ra,0xffffe
    80004784:	56e080e7          	jalr	1390(ra) # 80002cee <ilock>
  ip->major = major;
    80004788:	053a1323          	sh	s3,70(s4)
  ip->minor = minor;
    8000478c:	052a1423          	sh	s2,72(s4)
  ip->nlink = 1;
    80004790:	4905                	li	s2,1
    80004792:	052a1523          	sh	s2,74(s4)
  iupdate(ip);
    80004796:	8552                	mv	a0,s4
    80004798:	ffffe097          	auipc	ra,0xffffe
    8000479c:	48a080e7          	jalr	1162(ra) # 80002c22 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    800047a0:	032b0d63          	beq	s6,s2,800047da <create+0xfe>
  if(dirlink(dp, name, ip->inum) < 0)
    800047a4:	004a2603          	lw	a2,4(s4)
    800047a8:	fb040593          	addi	a1,s0,-80
    800047ac:	8526                	mv	a0,s1
    800047ae:	fffff097          	auipc	ra,0xfffff
    800047b2:	c5c080e7          	jalr	-932(ra) # 8000340a <dirlink>
    800047b6:	08054163          	bltz	a0,80004838 <create+0x15c>
  iunlockput(dp);
    800047ba:	8526                	mv	a0,s1
    800047bc:	ffffe097          	auipc	ra,0xffffe
    800047c0:	798080e7          	jalr	1944(ra) # 80002f54 <iunlockput>
  return ip;
    800047c4:	8ad2                	mv	s5,s4
    800047c6:	7a02                	ld	s4,32(sp)
    800047c8:	b751                	j	8000474c <create+0x70>
    iunlockput(dp);
    800047ca:	8526                	mv	a0,s1
    800047cc:	ffffe097          	auipc	ra,0xffffe
    800047d0:	788080e7          	jalr	1928(ra) # 80002f54 <iunlockput>
    return 0;
    800047d4:	8ad2                	mv	s5,s4
    800047d6:	7a02                	ld	s4,32(sp)
    800047d8:	bf95                	j	8000474c <create+0x70>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    800047da:	004a2603          	lw	a2,4(s4)
    800047de:	00004597          	auipc	a1,0x4
    800047e2:	dda58593          	addi	a1,a1,-550 # 800085b8 <etext+0x5b8>
    800047e6:	8552                	mv	a0,s4
    800047e8:	fffff097          	auipc	ra,0xfffff
    800047ec:	c22080e7          	jalr	-990(ra) # 8000340a <dirlink>
    800047f0:	04054463          	bltz	a0,80004838 <create+0x15c>
    800047f4:	40d0                	lw	a2,4(s1)
    800047f6:	00004597          	auipc	a1,0x4
    800047fa:	dca58593          	addi	a1,a1,-566 # 800085c0 <etext+0x5c0>
    800047fe:	8552                	mv	a0,s4
    80004800:	fffff097          	auipc	ra,0xfffff
    80004804:	c0a080e7          	jalr	-1014(ra) # 8000340a <dirlink>
    80004808:	02054863          	bltz	a0,80004838 <create+0x15c>
  if(dirlink(dp, name, ip->inum) < 0)
    8000480c:	004a2603          	lw	a2,4(s4)
    80004810:	fb040593          	addi	a1,s0,-80
    80004814:	8526                	mv	a0,s1
    80004816:	fffff097          	auipc	ra,0xfffff
    8000481a:	bf4080e7          	jalr	-1036(ra) # 8000340a <dirlink>
    8000481e:	00054d63          	bltz	a0,80004838 <create+0x15c>
    dp->nlink++;  // for ".."
    80004822:	04a4d783          	lhu	a5,74(s1)
    80004826:	2785                	addiw	a5,a5,1
    80004828:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    8000482c:	8526                	mv	a0,s1
    8000482e:	ffffe097          	auipc	ra,0xffffe
    80004832:	3f4080e7          	jalr	1012(ra) # 80002c22 <iupdate>
    80004836:	b751                	j	800047ba <create+0xde>
  ip->nlink = 0;
    80004838:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    8000483c:	8552                	mv	a0,s4
    8000483e:	ffffe097          	auipc	ra,0xffffe
    80004842:	3e4080e7          	jalr	996(ra) # 80002c22 <iupdate>
  iunlockput(ip);
    80004846:	8552                	mv	a0,s4
    80004848:	ffffe097          	auipc	ra,0xffffe
    8000484c:	70c080e7          	jalr	1804(ra) # 80002f54 <iunlockput>
  iunlockput(dp);
    80004850:	8526                	mv	a0,s1
    80004852:	ffffe097          	auipc	ra,0xffffe
    80004856:	702080e7          	jalr	1794(ra) # 80002f54 <iunlockput>
  return 0;
    8000485a:	7a02                	ld	s4,32(sp)
    8000485c:	bdc5                	j	8000474c <create+0x70>
    return 0;
    8000485e:	8aaa                	mv	s5,a0
    80004860:	b5f5                	j	8000474c <create+0x70>

0000000080004862 <sys_dup>:
{
    80004862:	7179                	addi	sp,sp,-48
    80004864:	f406                	sd	ra,40(sp)
    80004866:	f022                	sd	s0,32(sp)
    80004868:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    8000486a:	fd840613          	addi	a2,s0,-40
    8000486e:	4581                	li	a1,0
    80004870:	4501                	li	a0,0
    80004872:	00000097          	auipc	ra,0x0
    80004876:	dc8080e7          	jalr	-568(ra) # 8000463a <argfd>
    return -1;
    8000487a:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    8000487c:	02054763          	bltz	a0,800048aa <sys_dup+0x48>
    80004880:	ec26                	sd	s1,24(sp)
    80004882:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80004884:	fd843903          	ld	s2,-40(s0)
    80004888:	854a                	mv	a0,s2
    8000488a:	00000097          	auipc	ra,0x0
    8000488e:	e10080e7          	jalr	-496(ra) # 8000469a <fdalloc>
    80004892:	84aa                	mv	s1,a0
    return -1;
    80004894:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80004896:	00054f63          	bltz	a0,800048b4 <sys_dup+0x52>
  filedup(f);
    8000489a:	854a                	mv	a0,s2
    8000489c:	fffff097          	auipc	ra,0xfffff
    800048a0:	298080e7          	jalr	664(ra) # 80003b34 <filedup>
  return fd;
    800048a4:	87a6                	mv	a5,s1
    800048a6:	64e2                	ld	s1,24(sp)
    800048a8:	6942                	ld	s2,16(sp)
}
    800048aa:	853e                	mv	a0,a5
    800048ac:	70a2                	ld	ra,40(sp)
    800048ae:	7402                	ld	s0,32(sp)
    800048b0:	6145                	addi	sp,sp,48
    800048b2:	8082                	ret
    800048b4:	64e2                	ld	s1,24(sp)
    800048b6:	6942                	ld	s2,16(sp)
    800048b8:	bfcd                	j	800048aa <sys_dup+0x48>

00000000800048ba <sys_read>:
{
    800048ba:	7179                	addi	sp,sp,-48
    800048bc:	f406                	sd	ra,40(sp)
    800048be:	f022                	sd	s0,32(sp)
    800048c0:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    800048c2:	fd840593          	addi	a1,s0,-40
    800048c6:	4505                	li	a0,1
    800048c8:	ffffe097          	auipc	ra,0xffffe
    800048cc:	81a080e7          	jalr	-2022(ra) # 800020e2 <argaddr>
  argint(2, &n);
    800048d0:	fe440593          	addi	a1,s0,-28
    800048d4:	4509                	li	a0,2
    800048d6:	ffffd097          	auipc	ra,0xffffd
    800048da:	7ec080e7          	jalr	2028(ra) # 800020c2 <argint>
  if(argfd(0, 0, &f) < 0)
    800048de:	fe840613          	addi	a2,s0,-24
    800048e2:	4581                	li	a1,0
    800048e4:	4501                	li	a0,0
    800048e6:	00000097          	auipc	ra,0x0
    800048ea:	d54080e7          	jalr	-684(ra) # 8000463a <argfd>
    800048ee:	87aa                	mv	a5,a0
    return -1;
    800048f0:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800048f2:	0007cc63          	bltz	a5,8000490a <sys_read+0x50>
  return fileread(f, p, n);
    800048f6:	fe442603          	lw	a2,-28(s0)
    800048fa:	fd843583          	ld	a1,-40(s0)
    800048fe:	fe843503          	ld	a0,-24(s0)
    80004902:	fffff097          	auipc	ra,0xfffff
    80004906:	3d8080e7          	jalr	984(ra) # 80003cda <fileread>
}
    8000490a:	70a2                	ld	ra,40(sp)
    8000490c:	7402                	ld	s0,32(sp)
    8000490e:	6145                	addi	sp,sp,48
    80004910:	8082                	ret

0000000080004912 <sys_write>:
{
    80004912:	7179                	addi	sp,sp,-48
    80004914:	f406                	sd	ra,40(sp)
    80004916:	f022                	sd	s0,32(sp)
    80004918:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    8000491a:	fd840593          	addi	a1,s0,-40
    8000491e:	4505                	li	a0,1
    80004920:	ffffd097          	auipc	ra,0xffffd
    80004924:	7c2080e7          	jalr	1986(ra) # 800020e2 <argaddr>
  argint(2, &n);
    80004928:	fe440593          	addi	a1,s0,-28
    8000492c:	4509                	li	a0,2
    8000492e:	ffffd097          	auipc	ra,0xffffd
    80004932:	794080e7          	jalr	1940(ra) # 800020c2 <argint>
  if(argfd(0, 0, &f) < 0)
    80004936:	fe840613          	addi	a2,s0,-24
    8000493a:	4581                	li	a1,0
    8000493c:	4501                	li	a0,0
    8000493e:	00000097          	auipc	ra,0x0
    80004942:	cfc080e7          	jalr	-772(ra) # 8000463a <argfd>
    80004946:	87aa                	mv	a5,a0
    return -1;
    80004948:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    8000494a:	0007cc63          	bltz	a5,80004962 <sys_write+0x50>
  return filewrite(f, p, n);
    8000494e:	fe442603          	lw	a2,-28(s0)
    80004952:	fd843583          	ld	a1,-40(s0)
    80004956:	fe843503          	ld	a0,-24(s0)
    8000495a:	fffff097          	auipc	ra,0xfffff
    8000495e:	452080e7          	jalr	1106(ra) # 80003dac <filewrite>
}
    80004962:	70a2                	ld	ra,40(sp)
    80004964:	7402                	ld	s0,32(sp)
    80004966:	6145                	addi	sp,sp,48
    80004968:	8082                	ret

000000008000496a <sys_close>:
{
    8000496a:	1101                	addi	sp,sp,-32
    8000496c:	ec06                	sd	ra,24(sp)
    8000496e:	e822                	sd	s0,16(sp)
    80004970:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80004972:	fe040613          	addi	a2,s0,-32
    80004976:	fec40593          	addi	a1,s0,-20
    8000497a:	4501                	li	a0,0
    8000497c:	00000097          	auipc	ra,0x0
    80004980:	cbe080e7          	jalr	-834(ra) # 8000463a <argfd>
    return -1;
    80004984:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80004986:	02054463          	bltz	a0,800049ae <sys_close+0x44>
  myproc()->ofile[fd] = 0;
    8000498a:	ffffc097          	auipc	ra,0xffffc
    8000498e:	57c080e7          	jalr	1404(ra) # 80000f06 <myproc>
    80004992:	fec42783          	lw	a5,-20(s0)
    80004996:	07e9                	addi	a5,a5,26
    80004998:	078e                	slli	a5,a5,0x3
    8000499a:	953e                	add	a0,a0,a5
    8000499c:	00053023          	sd	zero,0(a0)
  fileclose(f);
    800049a0:	fe043503          	ld	a0,-32(s0)
    800049a4:	fffff097          	auipc	ra,0xfffff
    800049a8:	1e2080e7          	jalr	482(ra) # 80003b86 <fileclose>
  return 0;
    800049ac:	4781                	li	a5,0
}
    800049ae:	853e                	mv	a0,a5
    800049b0:	60e2                	ld	ra,24(sp)
    800049b2:	6442                	ld	s0,16(sp)
    800049b4:	6105                	addi	sp,sp,32
    800049b6:	8082                	ret

00000000800049b8 <sys_fstat>:
{
    800049b8:	1101                	addi	sp,sp,-32
    800049ba:	ec06                	sd	ra,24(sp)
    800049bc:	e822                	sd	s0,16(sp)
    800049be:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    800049c0:	fe040593          	addi	a1,s0,-32
    800049c4:	4505                	li	a0,1
    800049c6:	ffffd097          	auipc	ra,0xffffd
    800049ca:	71c080e7          	jalr	1820(ra) # 800020e2 <argaddr>
  if(argfd(0, 0, &f) < 0)
    800049ce:	fe840613          	addi	a2,s0,-24
    800049d2:	4581                	li	a1,0
    800049d4:	4501                	li	a0,0
    800049d6:	00000097          	auipc	ra,0x0
    800049da:	c64080e7          	jalr	-924(ra) # 8000463a <argfd>
    800049de:	87aa                	mv	a5,a0
    return -1;
    800049e0:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800049e2:	0007ca63          	bltz	a5,800049f6 <sys_fstat+0x3e>
  return filestat(f, st);
    800049e6:	fe043583          	ld	a1,-32(s0)
    800049ea:	fe843503          	ld	a0,-24(s0)
    800049ee:	fffff097          	auipc	ra,0xfffff
    800049f2:	27a080e7          	jalr	634(ra) # 80003c68 <filestat>
}
    800049f6:	60e2                	ld	ra,24(sp)
    800049f8:	6442                	ld	s0,16(sp)
    800049fa:	6105                	addi	sp,sp,32
    800049fc:	8082                	ret

00000000800049fe <sys_link>:
{
    800049fe:	7169                	addi	sp,sp,-304
    80004a00:	f606                	sd	ra,296(sp)
    80004a02:	f222                	sd	s0,288(sp)
    80004a04:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004a06:	08000613          	li	a2,128
    80004a0a:	ed040593          	addi	a1,s0,-304
    80004a0e:	4501                	li	a0,0
    80004a10:	ffffd097          	auipc	ra,0xffffd
    80004a14:	6f2080e7          	jalr	1778(ra) # 80002102 <argstr>
    return -1;
    80004a18:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004a1a:	12054663          	bltz	a0,80004b46 <sys_link+0x148>
    80004a1e:	08000613          	li	a2,128
    80004a22:	f5040593          	addi	a1,s0,-176
    80004a26:	4505                	li	a0,1
    80004a28:	ffffd097          	auipc	ra,0xffffd
    80004a2c:	6da080e7          	jalr	1754(ra) # 80002102 <argstr>
    return -1;
    80004a30:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004a32:	10054a63          	bltz	a0,80004b46 <sys_link+0x148>
    80004a36:	ee26                	sd	s1,280(sp)
  begin_op();
    80004a38:	fffff097          	auipc	ra,0xfffff
    80004a3c:	c84080e7          	jalr	-892(ra) # 800036bc <begin_op>
  if((ip = namei(old)) == 0){
    80004a40:	ed040513          	addi	a0,s0,-304
    80004a44:	fffff097          	auipc	ra,0xfffff
    80004a48:	a78080e7          	jalr	-1416(ra) # 800034bc <namei>
    80004a4c:	84aa                	mv	s1,a0
    80004a4e:	c949                	beqz	a0,80004ae0 <sys_link+0xe2>
  ilock(ip);
    80004a50:	ffffe097          	auipc	ra,0xffffe
    80004a54:	29e080e7          	jalr	670(ra) # 80002cee <ilock>
  if(ip->type == T_DIR){
    80004a58:	04449703          	lh	a4,68(s1)
    80004a5c:	4785                	li	a5,1
    80004a5e:	08f70863          	beq	a4,a5,80004aee <sys_link+0xf0>
    80004a62:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004a64:	04a4d783          	lhu	a5,74(s1)
    80004a68:	2785                	addiw	a5,a5,1
    80004a6a:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004a6e:	8526                	mv	a0,s1
    80004a70:	ffffe097          	auipc	ra,0xffffe
    80004a74:	1b2080e7          	jalr	434(ra) # 80002c22 <iupdate>
  iunlock(ip);
    80004a78:	8526                	mv	a0,s1
    80004a7a:	ffffe097          	auipc	ra,0xffffe
    80004a7e:	33a080e7          	jalr	826(ra) # 80002db4 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80004a82:	fd040593          	addi	a1,s0,-48
    80004a86:	f5040513          	addi	a0,s0,-176
    80004a8a:	fffff097          	auipc	ra,0xfffff
    80004a8e:	a50080e7          	jalr	-1456(ra) # 800034da <nameiparent>
    80004a92:	892a                	mv	s2,a0
    80004a94:	cd35                	beqz	a0,80004b10 <sys_link+0x112>
  ilock(dp);
    80004a96:	ffffe097          	auipc	ra,0xffffe
    80004a9a:	258080e7          	jalr	600(ra) # 80002cee <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80004a9e:	00092703          	lw	a4,0(s2)
    80004aa2:	409c                	lw	a5,0(s1)
    80004aa4:	06f71163          	bne	a4,a5,80004b06 <sys_link+0x108>
    80004aa8:	40d0                	lw	a2,4(s1)
    80004aaa:	fd040593          	addi	a1,s0,-48
    80004aae:	854a                	mv	a0,s2
    80004ab0:	fffff097          	auipc	ra,0xfffff
    80004ab4:	95a080e7          	jalr	-1702(ra) # 8000340a <dirlink>
    80004ab8:	04054763          	bltz	a0,80004b06 <sys_link+0x108>
  iunlockput(dp);
    80004abc:	854a                	mv	a0,s2
    80004abe:	ffffe097          	auipc	ra,0xffffe
    80004ac2:	496080e7          	jalr	1174(ra) # 80002f54 <iunlockput>
  iput(ip);
    80004ac6:	8526                	mv	a0,s1
    80004ac8:	ffffe097          	auipc	ra,0xffffe
    80004acc:	3e4080e7          	jalr	996(ra) # 80002eac <iput>
  end_op();
    80004ad0:	fffff097          	auipc	ra,0xfffff
    80004ad4:	c66080e7          	jalr	-922(ra) # 80003736 <end_op>
  return 0;
    80004ad8:	4781                	li	a5,0
    80004ada:	64f2                	ld	s1,280(sp)
    80004adc:	6952                	ld	s2,272(sp)
    80004ade:	a0a5                	j	80004b46 <sys_link+0x148>
    end_op();
    80004ae0:	fffff097          	auipc	ra,0xfffff
    80004ae4:	c56080e7          	jalr	-938(ra) # 80003736 <end_op>
    return -1;
    80004ae8:	57fd                	li	a5,-1
    80004aea:	64f2                	ld	s1,280(sp)
    80004aec:	a8a9                	j	80004b46 <sys_link+0x148>
    iunlockput(ip);
    80004aee:	8526                	mv	a0,s1
    80004af0:	ffffe097          	auipc	ra,0xffffe
    80004af4:	464080e7          	jalr	1124(ra) # 80002f54 <iunlockput>
    end_op();
    80004af8:	fffff097          	auipc	ra,0xfffff
    80004afc:	c3e080e7          	jalr	-962(ra) # 80003736 <end_op>
    return -1;
    80004b00:	57fd                	li	a5,-1
    80004b02:	64f2                	ld	s1,280(sp)
    80004b04:	a089                	j	80004b46 <sys_link+0x148>
    iunlockput(dp);
    80004b06:	854a                	mv	a0,s2
    80004b08:	ffffe097          	auipc	ra,0xffffe
    80004b0c:	44c080e7          	jalr	1100(ra) # 80002f54 <iunlockput>
  ilock(ip);
    80004b10:	8526                	mv	a0,s1
    80004b12:	ffffe097          	auipc	ra,0xffffe
    80004b16:	1dc080e7          	jalr	476(ra) # 80002cee <ilock>
  ip->nlink--;
    80004b1a:	04a4d783          	lhu	a5,74(s1)
    80004b1e:	37fd                	addiw	a5,a5,-1
    80004b20:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004b24:	8526                	mv	a0,s1
    80004b26:	ffffe097          	auipc	ra,0xffffe
    80004b2a:	0fc080e7          	jalr	252(ra) # 80002c22 <iupdate>
  iunlockput(ip);
    80004b2e:	8526                	mv	a0,s1
    80004b30:	ffffe097          	auipc	ra,0xffffe
    80004b34:	424080e7          	jalr	1060(ra) # 80002f54 <iunlockput>
  end_op();
    80004b38:	fffff097          	auipc	ra,0xfffff
    80004b3c:	bfe080e7          	jalr	-1026(ra) # 80003736 <end_op>
  return -1;
    80004b40:	57fd                	li	a5,-1
    80004b42:	64f2                	ld	s1,280(sp)
    80004b44:	6952                	ld	s2,272(sp)
}
    80004b46:	853e                	mv	a0,a5
    80004b48:	70b2                	ld	ra,296(sp)
    80004b4a:	7412                	ld	s0,288(sp)
    80004b4c:	6155                	addi	sp,sp,304
    80004b4e:	8082                	ret

0000000080004b50 <sys_unlink>:
{
    80004b50:	7151                	addi	sp,sp,-240
    80004b52:	f586                	sd	ra,232(sp)
    80004b54:	f1a2                	sd	s0,224(sp)
    80004b56:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80004b58:	08000613          	li	a2,128
    80004b5c:	f3040593          	addi	a1,s0,-208
    80004b60:	4501                	li	a0,0
    80004b62:	ffffd097          	auipc	ra,0xffffd
    80004b66:	5a0080e7          	jalr	1440(ra) # 80002102 <argstr>
    80004b6a:	1a054a63          	bltz	a0,80004d1e <sys_unlink+0x1ce>
    80004b6e:	eda6                	sd	s1,216(sp)
  begin_op();
    80004b70:	fffff097          	auipc	ra,0xfffff
    80004b74:	b4c080e7          	jalr	-1204(ra) # 800036bc <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80004b78:	fb040593          	addi	a1,s0,-80
    80004b7c:	f3040513          	addi	a0,s0,-208
    80004b80:	fffff097          	auipc	ra,0xfffff
    80004b84:	95a080e7          	jalr	-1702(ra) # 800034da <nameiparent>
    80004b88:	84aa                	mv	s1,a0
    80004b8a:	cd71                	beqz	a0,80004c66 <sys_unlink+0x116>
  ilock(dp);
    80004b8c:	ffffe097          	auipc	ra,0xffffe
    80004b90:	162080e7          	jalr	354(ra) # 80002cee <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80004b94:	00004597          	auipc	a1,0x4
    80004b98:	a2458593          	addi	a1,a1,-1500 # 800085b8 <etext+0x5b8>
    80004b9c:	fb040513          	addi	a0,s0,-80
    80004ba0:	ffffe097          	auipc	ra,0xffffe
    80004ba4:	640080e7          	jalr	1600(ra) # 800031e0 <namecmp>
    80004ba8:	14050c63          	beqz	a0,80004d00 <sys_unlink+0x1b0>
    80004bac:	00004597          	auipc	a1,0x4
    80004bb0:	a1458593          	addi	a1,a1,-1516 # 800085c0 <etext+0x5c0>
    80004bb4:	fb040513          	addi	a0,s0,-80
    80004bb8:	ffffe097          	auipc	ra,0xffffe
    80004bbc:	628080e7          	jalr	1576(ra) # 800031e0 <namecmp>
    80004bc0:	14050063          	beqz	a0,80004d00 <sys_unlink+0x1b0>
    80004bc4:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    80004bc6:	f2c40613          	addi	a2,s0,-212
    80004bca:	fb040593          	addi	a1,s0,-80
    80004bce:	8526                	mv	a0,s1
    80004bd0:	ffffe097          	auipc	ra,0xffffe
    80004bd4:	62a080e7          	jalr	1578(ra) # 800031fa <dirlookup>
    80004bd8:	892a                	mv	s2,a0
    80004bda:	12050263          	beqz	a0,80004cfe <sys_unlink+0x1ae>
  ilock(ip);
    80004bde:	ffffe097          	auipc	ra,0xffffe
    80004be2:	110080e7          	jalr	272(ra) # 80002cee <ilock>
  if(ip->nlink < 1)
    80004be6:	04a91783          	lh	a5,74(s2)
    80004bea:	08f05563          	blez	a5,80004c74 <sys_unlink+0x124>
  if(ip->type == T_DIR && !isdirempty(ip)){
    80004bee:	04491703          	lh	a4,68(s2)
    80004bf2:	4785                	li	a5,1
    80004bf4:	08f70963          	beq	a4,a5,80004c86 <sys_unlink+0x136>
  memset(&de, 0, sizeof(de));
    80004bf8:	4641                	li	a2,16
    80004bfa:	4581                	li	a1,0
    80004bfc:	fc040513          	addi	a0,s0,-64
    80004c00:	ffffb097          	auipc	ra,0xffffb
    80004c04:	57a080e7          	jalr	1402(ra) # 8000017a <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004c08:	4741                	li	a4,16
    80004c0a:	f2c42683          	lw	a3,-212(s0)
    80004c0e:	fc040613          	addi	a2,s0,-64
    80004c12:	4581                	li	a1,0
    80004c14:	8526                	mv	a0,s1
    80004c16:	ffffe097          	auipc	ra,0xffffe
    80004c1a:	4a0080e7          	jalr	1184(ra) # 800030b6 <writei>
    80004c1e:	47c1                	li	a5,16
    80004c20:	0af51b63          	bne	a0,a5,80004cd6 <sys_unlink+0x186>
  if(ip->type == T_DIR){
    80004c24:	04491703          	lh	a4,68(s2)
    80004c28:	4785                	li	a5,1
    80004c2a:	0af70f63          	beq	a4,a5,80004ce8 <sys_unlink+0x198>
  iunlockput(dp);
    80004c2e:	8526                	mv	a0,s1
    80004c30:	ffffe097          	auipc	ra,0xffffe
    80004c34:	324080e7          	jalr	804(ra) # 80002f54 <iunlockput>
  ip->nlink--;
    80004c38:	04a95783          	lhu	a5,74(s2)
    80004c3c:	37fd                	addiw	a5,a5,-1
    80004c3e:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004c42:	854a                	mv	a0,s2
    80004c44:	ffffe097          	auipc	ra,0xffffe
    80004c48:	fde080e7          	jalr	-34(ra) # 80002c22 <iupdate>
  iunlockput(ip);
    80004c4c:	854a                	mv	a0,s2
    80004c4e:	ffffe097          	auipc	ra,0xffffe
    80004c52:	306080e7          	jalr	774(ra) # 80002f54 <iunlockput>
  end_op();
    80004c56:	fffff097          	auipc	ra,0xfffff
    80004c5a:	ae0080e7          	jalr	-1312(ra) # 80003736 <end_op>
  return 0;
    80004c5e:	4501                	li	a0,0
    80004c60:	64ee                	ld	s1,216(sp)
    80004c62:	694e                	ld	s2,208(sp)
    80004c64:	a84d                	j	80004d16 <sys_unlink+0x1c6>
    end_op();
    80004c66:	fffff097          	auipc	ra,0xfffff
    80004c6a:	ad0080e7          	jalr	-1328(ra) # 80003736 <end_op>
    return -1;
    80004c6e:	557d                	li	a0,-1
    80004c70:	64ee                	ld	s1,216(sp)
    80004c72:	a055                	j	80004d16 <sys_unlink+0x1c6>
    80004c74:	e5ce                	sd	s3,200(sp)
    panic("unlink: nlink < 1");
    80004c76:	00004517          	auipc	a0,0x4
    80004c7a:	95250513          	addi	a0,a0,-1710 # 800085c8 <etext+0x5c8>
    80004c7e:	00001097          	auipc	ra,0x1
    80004c82:	30e080e7          	jalr	782(ra) # 80005f8c <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004c86:	04c92703          	lw	a4,76(s2)
    80004c8a:	02000793          	li	a5,32
    80004c8e:	f6e7f5e3          	bgeu	a5,a4,80004bf8 <sys_unlink+0xa8>
    80004c92:	e5ce                	sd	s3,200(sp)
    80004c94:	02000993          	li	s3,32
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004c98:	4741                	li	a4,16
    80004c9a:	86ce                	mv	a3,s3
    80004c9c:	f1840613          	addi	a2,s0,-232
    80004ca0:	4581                	li	a1,0
    80004ca2:	854a                	mv	a0,s2
    80004ca4:	ffffe097          	auipc	ra,0xffffe
    80004ca8:	302080e7          	jalr	770(ra) # 80002fa6 <readi>
    80004cac:	47c1                	li	a5,16
    80004cae:	00f51c63          	bne	a0,a5,80004cc6 <sys_unlink+0x176>
    if(de.inum != 0)
    80004cb2:	f1845783          	lhu	a5,-232(s0)
    80004cb6:	e7b5                	bnez	a5,80004d22 <sys_unlink+0x1d2>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004cb8:	29c1                	addiw	s3,s3,16
    80004cba:	04c92783          	lw	a5,76(s2)
    80004cbe:	fcf9ede3          	bltu	s3,a5,80004c98 <sys_unlink+0x148>
    80004cc2:	69ae                	ld	s3,200(sp)
    80004cc4:	bf15                	j	80004bf8 <sys_unlink+0xa8>
      panic("isdirempty: readi");
    80004cc6:	00004517          	auipc	a0,0x4
    80004cca:	91a50513          	addi	a0,a0,-1766 # 800085e0 <etext+0x5e0>
    80004cce:	00001097          	auipc	ra,0x1
    80004cd2:	2be080e7          	jalr	702(ra) # 80005f8c <panic>
    80004cd6:	e5ce                	sd	s3,200(sp)
    panic("unlink: writei");
    80004cd8:	00004517          	auipc	a0,0x4
    80004cdc:	92050513          	addi	a0,a0,-1760 # 800085f8 <etext+0x5f8>
    80004ce0:	00001097          	auipc	ra,0x1
    80004ce4:	2ac080e7          	jalr	684(ra) # 80005f8c <panic>
    dp->nlink--;
    80004ce8:	04a4d783          	lhu	a5,74(s1)
    80004cec:	37fd                	addiw	a5,a5,-1
    80004cee:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004cf2:	8526                	mv	a0,s1
    80004cf4:	ffffe097          	auipc	ra,0xffffe
    80004cf8:	f2e080e7          	jalr	-210(ra) # 80002c22 <iupdate>
    80004cfc:	bf0d                	j	80004c2e <sys_unlink+0xde>
    80004cfe:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    80004d00:	8526                	mv	a0,s1
    80004d02:	ffffe097          	auipc	ra,0xffffe
    80004d06:	252080e7          	jalr	594(ra) # 80002f54 <iunlockput>
  end_op();
    80004d0a:	fffff097          	auipc	ra,0xfffff
    80004d0e:	a2c080e7          	jalr	-1492(ra) # 80003736 <end_op>
  return -1;
    80004d12:	557d                	li	a0,-1
    80004d14:	64ee                	ld	s1,216(sp)
}
    80004d16:	70ae                	ld	ra,232(sp)
    80004d18:	740e                	ld	s0,224(sp)
    80004d1a:	616d                	addi	sp,sp,240
    80004d1c:	8082                	ret
    return -1;
    80004d1e:	557d                	li	a0,-1
    80004d20:	bfdd                	j	80004d16 <sys_unlink+0x1c6>
    iunlockput(ip);
    80004d22:	854a                	mv	a0,s2
    80004d24:	ffffe097          	auipc	ra,0xffffe
    80004d28:	230080e7          	jalr	560(ra) # 80002f54 <iunlockput>
    goto bad;
    80004d2c:	694e                	ld	s2,208(sp)
    80004d2e:	69ae                	ld	s3,200(sp)
    80004d30:	bfc1                	j	80004d00 <sys_unlink+0x1b0>

0000000080004d32 <sys_open>:

uint64
sys_open(void)
{
    80004d32:	7131                	addi	sp,sp,-192
    80004d34:	fd06                	sd	ra,184(sp)
    80004d36:	f922                	sd	s0,176(sp)
    80004d38:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80004d3a:	f4c40593          	addi	a1,s0,-180
    80004d3e:	4505                	li	a0,1
    80004d40:	ffffd097          	auipc	ra,0xffffd
    80004d44:	382080e7          	jalr	898(ra) # 800020c2 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    80004d48:	08000613          	li	a2,128
    80004d4c:	f5040593          	addi	a1,s0,-176
    80004d50:	4501                	li	a0,0
    80004d52:	ffffd097          	auipc	ra,0xffffd
    80004d56:	3b0080e7          	jalr	944(ra) # 80002102 <argstr>
    80004d5a:	87aa                	mv	a5,a0
    return -1;
    80004d5c:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    80004d5e:	0a07ce63          	bltz	a5,80004e1a <sys_open+0xe8>
    80004d62:	f526                	sd	s1,168(sp)

  begin_op();
    80004d64:	fffff097          	auipc	ra,0xfffff
    80004d68:	958080e7          	jalr	-1704(ra) # 800036bc <begin_op>

  if(omode & O_CREATE){
    80004d6c:	f4c42783          	lw	a5,-180(s0)
    80004d70:	2007f793          	andi	a5,a5,512
    80004d74:	cfd5                	beqz	a5,80004e30 <sys_open+0xfe>
    ip = create(path, T_FILE, 0, 0);
    80004d76:	4681                	li	a3,0
    80004d78:	4601                	li	a2,0
    80004d7a:	4589                	li	a1,2
    80004d7c:	f5040513          	addi	a0,s0,-176
    80004d80:	00000097          	auipc	ra,0x0
    80004d84:	95c080e7          	jalr	-1700(ra) # 800046dc <create>
    80004d88:	84aa                	mv	s1,a0
    if(ip == 0){
    80004d8a:	cd41                	beqz	a0,80004e22 <sys_open+0xf0>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    80004d8c:	04449703          	lh	a4,68(s1)
    80004d90:	478d                	li	a5,3
    80004d92:	00f71763          	bne	a4,a5,80004da0 <sys_open+0x6e>
    80004d96:	0464d703          	lhu	a4,70(s1)
    80004d9a:	47a5                	li	a5,9
    80004d9c:	0ee7e163          	bltu	a5,a4,80004e7e <sys_open+0x14c>
    80004da0:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    80004da2:	fffff097          	auipc	ra,0xfffff
    80004da6:	d28080e7          	jalr	-728(ra) # 80003aca <filealloc>
    80004daa:	892a                	mv	s2,a0
    80004dac:	c97d                	beqz	a0,80004ea2 <sys_open+0x170>
    80004dae:	ed4e                	sd	s3,152(sp)
    80004db0:	00000097          	auipc	ra,0x0
    80004db4:	8ea080e7          	jalr	-1814(ra) # 8000469a <fdalloc>
    80004db8:	89aa                	mv	s3,a0
    80004dba:	0c054e63          	bltz	a0,80004e96 <sys_open+0x164>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80004dbe:	04449703          	lh	a4,68(s1)
    80004dc2:	478d                	li	a5,3
    80004dc4:	0ef70c63          	beq	a4,a5,80004ebc <sys_open+0x18a>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80004dc8:	4789                	li	a5,2
    80004dca:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    80004dce:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    80004dd2:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    80004dd6:	f4c42783          	lw	a5,-180(s0)
    80004dda:	0017c713          	xori	a4,a5,1
    80004dde:	8b05                	andi	a4,a4,1
    80004de0:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80004de4:	0037f713          	andi	a4,a5,3
    80004de8:	00e03733          	snez	a4,a4
    80004dec:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    80004df0:	4007f793          	andi	a5,a5,1024
    80004df4:	c791                	beqz	a5,80004e00 <sys_open+0xce>
    80004df6:	04449703          	lh	a4,68(s1)
    80004dfa:	4789                	li	a5,2
    80004dfc:	0cf70763          	beq	a4,a5,80004eca <sys_open+0x198>
    itrunc(ip);
  }

  iunlock(ip);
    80004e00:	8526                	mv	a0,s1
    80004e02:	ffffe097          	auipc	ra,0xffffe
    80004e06:	fb2080e7          	jalr	-78(ra) # 80002db4 <iunlock>
  end_op();
    80004e0a:	fffff097          	auipc	ra,0xfffff
    80004e0e:	92c080e7          	jalr	-1748(ra) # 80003736 <end_op>

  return fd;
    80004e12:	854e                	mv	a0,s3
    80004e14:	74aa                	ld	s1,168(sp)
    80004e16:	790a                	ld	s2,160(sp)
    80004e18:	69ea                	ld	s3,152(sp)
}
    80004e1a:	70ea                	ld	ra,184(sp)
    80004e1c:	744a                	ld	s0,176(sp)
    80004e1e:	6129                	addi	sp,sp,192
    80004e20:	8082                	ret
      end_op();
    80004e22:	fffff097          	auipc	ra,0xfffff
    80004e26:	914080e7          	jalr	-1772(ra) # 80003736 <end_op>
      return -1;
    80004e2a:	557d                	li	a0,-1
    80004e2c:	74aa                	ld	s1,168(sp)
    80004e2e:	b7f5                	j	80004e1a <sys_open+0xe8>
    if((ip = namei(path)) == 0){
    80004e30:	f5040513          	addi	a0,s0,-176
    80004e34:	ffffe097          	auipc	ra,0xffffe
    80004e38:	688080e7          	jalr	1672(ra) # 800034bc <namei>
    80004e3c:	84aa                	mv	s1,a0
    80004e3e:	c90d                	beqz	a0,80004e70 <sys_open+0x13e>
    ilock(ip);
    80004e40:	ffffe097          	auipc	ra,0xffffe
    80004e44:	eae080e7          	jalr	-338(ra) # 80002cee <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    80004e48:	04449703          	lh	a4,68(s1)
    80004e4c:	4785                	li	a5,1
    80004e4e:	f2f71fe3          	bne	a4,a5,80004d8c <sys_open+0x5a>
    80004e52:	f4c42783          	lw	a5,-180(s0)
    80004e56:	d7a9                	beqz	a5,80004da0 <sys_open+0x6e>
      iunlockput(ip);
    80004e58:	8526                	mv	a0,s1
    80004e5a:	ffffe097          	auipc	ra,0xffffe
    80004e5e:	0fa080e7          	jalr	250(ra) # 80002f54 <iunlockput>
      end_op();
    80004e62:	fffff097          	auipc	ra,0xfffff
    80004e66:	8d4080e7          	jalr	-1836(ra) # 80003736 <end_op>
      return -1;
    80004e6a:	557d                	li	a0,-1
    80004e6c:	74aa                	ld	s1,168(sp)
    80004e6e:	b775                	j	80004e1a <sys_open+0xe8>
      end_op();
    80004e70:	fffff097          	auipc	ra,0xfffff
    80004e74:	8c6080e7          	jalr	-1850(ra) # 80003736 <end_op>
      return -1;
    80004e78:	557d                	li	a0,-1
    80004e7a:	74aa                	ld	s1,168(sp)
    80004e7c:	bf79                	j	80004e1a <sys_open+0xe8>
    iunlockput(ip);
    80004e7e:	8526                	mv	a0,s1
    80004e80:	ffffe097          	auipc	ra,0xffffe
    80004e84:	0d4080e7          	jalr	212(ra) # 80002f54 <iunlockput>
    end_op();
    80004e88:	fffff097          	auipc	ra,0xfffff
    80004e8c:	8ae080e7          	jalr	-1874(ra) # 80003736 <end_op>
    return -1;
    80004e90:	557d                	li	a0,-1
    80004e92:	74aa                	ld	s1,168(sp)
    80004e94:	b759                	j	80004e1a <sys_open+0xe8>
      fileclose(f);
    80004e96:	854a                	mv	a0,s2
    80004e98:	fffff097          	auipc	ra,0xfffff
    80004e9c:	cee080e7          	jalr	-786(ra) # 80003b86 <fileclose>
    80004ea0:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80004ea2:	8526                	mv	a0,s1
    80004ea4:	ffffe097          	auipc	ra,0xffffe
    80004ea8:	0b0080e7          	jalr	176(ra) # 80002f54 <iunlockput>
    end_op();
    80004eac:	fffff097          	auipc	ra,0xfffff
    80004eb0:	88a080e7          	jalr	-1910(ra) # 80003736 <end_op>
    return -1;
    80004eb4:	557d                	li	a0,-1
    80004eb6:	74aa                	ld	s1,168(sp)
    80004eb8:	790a                	ld	s2,160(sp)
    80004eba:	b785                	j	80004e1a <sys_open+0xe8>
    f->type = FD_DEVICE;
    80004ebc:	00f92023          	sw	a5,0(s2)
    f->major = ip->major;
    80004ec0:	04649783          	lh	a5,70(s1)
    80004ec4:	02f91223          	sh	a5,36(s2)
    80004ec8:	b729                	j	80004dd2 <sys_open+0xa0>
    itrunc(ip);
    80004eca:	8526                	mv	a0,s1
    80004ecc:	ffffe097          	auipc	ra,0xffffe
    80004ed0:	f34080e7          	jalr	-204(ra) # 80002e00 <itrunc>
    80004ed4:	b735                	j	80004e00 <sys_open+0xce>

0000000080004ed6 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80004ed6:	7175                	addi	sp,sp,-144
    80004ed8:	e506                	sd	ra,136(sp)
    80004eda:	e122                	sd	s0,128(sp)
    80004edc:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80004ede:	ffffe097          	auipc	ra,0xffffe
    80004ee2:	7de080e7          	jalr	2014(ra) # 800036bc <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    80004ee6:	08000613          	li	a2,128
    80004eea:	f7040593          	addi	a1,s0,-144
    80004eee:	4501                	li	a0,0
    80004ef0:	ffffd097          	auipc	ra,0xffffd
    80004ef4:	212080e7          	jalr	530(ra) # 80002102 <argstr>
    80004ef8:	02054963          	bltz	a0,80004f2a <sys_mkdir+0x54>
    80004efc:	4681                	li	a3,0
    80004efe:	4601                	li	a2,0
    80004f00:	4585                	li	a1,1
    80004f02:	f7040513          	addi	a0,s0,-144
    80004f06:	fffff097          	auipc	ra,0xfffff
    80004f0a:	7d6080e7          	jalr	2006(ra) # 800046dc <create>
    80004f0e:	cd11                	beqz	a0,80004f2a <sys_mkdir+0x54>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80004f10:	ffffe097          	auipc	ra,0xffffe
    80004f14:	044080e7          	jalr	68(ra) # 80002f54 <iunlockput>
  end_op();
    80004f18:	fffff097          	auipc	ra,0xfffff
    80004f1c:	81e080e7          	jalr	-2018(ra) # 80003736 <end_op>
  return 0;
    80004f20:	4501                	li	a0,0
}
    80004f22:	60aa                	ld	ra,136(sp)
    80004f24:	640a                	ld	s0,128(sp)
    80004f26:	6149                	addi	sp,sp,144
    80004f28:	8082                	ret
    end_op();
    80004f2a:	fffff097          	auipc	ra,0xfffff
    80004f2e:	80c080e7          	jalr	-2036(ra) # 80003736 <end_op>
    return -1;
    80004f32:	557d                	li	a0,-1
    80004f34:	b7fd                	j	80004f22 <sys_mkdir+0x4c>

0000000080004f36 <sys_mknod>:

uint64
sys_mknod(void)
{
    80004f36:	7135                	addi	sp,sp,-160
    80004f38:	ed06                	sd	ra,152(sp)
    80004f3a:	e922                	sd	s0,144(sp)
    80004f3c:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80004f3e:	ffffe097          	auipc	ra,0xffffe
    80004f42:	77e080e7          	jalr	1918(ra) # 800036bc <begin_op>
  argint(1, &major);
    80004f46:	f6c40593          	addi	a1,s0,-148
    80004f4a:	4505                	li	a0,1
    80004f4c:	ffffd097          	auipc	ra,0xffffd
    80004f50:	176080e7          	jalr	374(ra) # 800020c2 <argint>
  argint(2, &minor);
    80004f54:	f6840593          	addi	a1,s0,-152
    80004f58:	4509                	li	a0,2
    80004f5a:	ffffd097          	auipc	ra,0xffffd
    80004f5e:	168080e7          	jalr	360(ra) # 800020c2 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004f62:	08000613          	li	a2,128
    80004f66:	f7040593          	addi	a1,s0,-144
    80004f6a:	4501                	li	a0,0
    80004f6c:	ffffd097          	auipc	ra,0xffffd
    80004f70:	196080e7          	jalr	406(ra) # 80002102 <argstr>
    80004f74:	02054b63          	bltz	a0,80004faa <sys_mknod+0x74>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    80004f78:	f6841683          	lh	a3,-152(s0)
    80004f7c:	f6c41603          	lh	a2,-148(s0)
    80004f80:	458d                	li	a1,3
    80004f82:	f7040513          	addi	a0,s0,-144
    80004f86:	fffff097          	auipc	ra,0xfffff
    80004f8a:	756080e7          	jalr	1878(ra) # 800046dc <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004f8e:	cd11                	beqz	a0,80004faa <sys_mknod+0x74>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80004f90:	ffffe097          	auipc	ra,0xffffe
    80004f94:	fc4080e7          	jalr	-60(ra) # 80002f54 <iunlockput>
  end_op();
    80004f98:	ffffe097          	auipc	ra,0xffffe
    80004f9c:	79e080e7          	jalr	1950(ra) # 80003736 <end_op>
  return 0;
    80004fa0:	4501                	li	a0,0
}
    80004fa2:	60ea                	ld	ra,152(sp)
    80004fa4:	644a                	ld	s0,144(sp)
    80004fa6:	610d                	addi	sp,sp,160
    80004fa8:	8082                	ret
    end_op();
    80004faa:	ffffe097          	auipc	ra,0xffffe
    80004fae:	78c080e7          	jalr	1932(ra) # 80003736 <end_op>
    return -1;
    80004fb2:	557d                	li	a0,-1
    80004fb4:	b7fd                	j	80004fa2 <sys_mknod+0x6c>

0000000080004fb6 <sys_chdir>:

uint64
sys_chdir(void)
{
    80004fb6:	7135                	addi	sp,sp,-160
    80004fb8:	ed06                	sd	ra,152(sp)
    80004fba:	e922                	sd	s0,144(sp)
    80004fbc:	e14a                	sd	s2,128(sp)
    80004fbe:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80004fc0:	ffffc097          	auipc	ra,0xffffc
    80004fc4:	f46080e7          	jalr	-186(ra) # 80000f06 <myproc>
    80004fc8:	892a                	mv	s2,a0
  
  begin_op();
    80004fca:	ffffe097          	auipc	ra,0xffffe
    80004fce:	6f2080e7          	jalr	1778(ra) # 800036bc <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    80004fd2:	08000613          	li	a2,128
    80004fd6:	f6040593          	addi	a1,s0,-160
    80004fda:	4501                	li	a0,0
    80004fdc:	ffffd097          	auipc	ra,0xffffd
    80004fe0:	126080e7          	jalr	294(ra) # 80002102 <argstr>
    80004fe4:	04054d63          	bltz	a0,8000503e <sys_chdir+0x88>
    80004fe8:	e526                	sd	s1,136(sp)
    80004fea:	f6040513          	addi	a0,s0,-160
    80004fee:	ffffe097          	auipc	ra,0xffffe
    80004ff2:	4ce080e7          	jalr	1230(ra) # 800034bc <namei>
    80004ff6:	84aa                	mv	s1,a0
    80004ff8:	c131                	beqz	a0,8000503c <sys_chdir+0x86>
    end_op();
    return -1;
  }
  ilock(ip);
    80004ffa:	ffffe097          	auipc	ra,0xffffe
    80004ffe:	cf4080e7          	jalr	-780(ra) # 80002cee <ilock>
  if(ip->type != T_DIR){
    80005002:	04449703          	lh	a4,68(s1)
    80005006:	4785                	li	a5,1
    80005008:	04f71163          	bne	a4,a5,8000504a <sys_chdir+0x94>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    8000500c:	8526                	mv	a0,s1
    8000500e:	ffffe097          	auipc	ra,0xffffe
    80005012:	da6080e7          	jalr	-602(ra) # 80002db4 <iunlock>
  iput(p->cwd);
    80005016:	15093503          	ld	a0,336(s2)
    8000501a:	ffffe097          	auipc	ra,0xffffe
    8000501e:	e92080e7          	jalr	-366(ra) # 80002eac <iput>
  end_op();
    80005022:	ffffe097          	auipc	ra,0xffffe
    80005026:	714080e7          	jalr	1812(ra) # 80003736 <end_op>
  p->cwd = ip;
    8000502a:	14993823          	sd	s1,336(s2)
  return 0;
    8000502e:	4501                	li	a0,0
    80005030:	64aa                	ld	s1,136(sp)
}
    80005032:	60ea                	ld	ra,152(sp)
    80005034:	644a                	ld	s0,144(sp)
    80005036:	690a                	ld	s2,128(sp)
    80005038:	610d                	addi	sp,sp,160
    8000503a:	8082                	ret
    8000503c:	64aa                	ld	s1,136(sp)
    end_op();
    8000503e:	ffffe097          	auipc	ra,0xffffe
    80005042:	6f8080e7          	jalr	1784(ra) # 80003736 <end_op>
    return -1;
    80005046:	557d                	li	a0,-1
    80005048:	b7ed                	j	80005032 <sys_chdir+0x7c>
    iunlockput(ip);
    8000504a:	8526                	mv	a0,s1
    8000504c:	ffffe097          	auipc	ra,0xffffe
    80005050:	f08080e7          	jalr	-248(ra) # 80002f54 <iunlockput>
    end_op();
    80005054:	ffffe097          	auipc	ra,0xffffe
    80005058:	6e2080e7          	jalr	1762(ra) # 80003736 <end_op>
    return -1;
    8000505c:	557d                	li	a0,-1
    8000505e:	64aa                	ld	s1,136(sp)
    80005060:	bfc9                	j	80005032 <sys_chdir+0x7c>

0000000080005062 <sys_exec>:

uint64
sys_exec(void)
{
    80005062:	7121                	addi	sp,sp,-448
    80005064:	ff06                	sd	ra,440(sp)
    80005066:	fb22                	sd	s0,432(sp)
    80005068:	0380                	addi	s0,sp,448
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    8000506a:	e4840593          	addi	a1,s0,-440
    8000506e:	4505                	li	a0,1
    80005070:	ffffd097          	auipc	ra,0xffffd
    80005074:	072080e7          	jalr	114(ra) # 800020e2 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80005078:	08000613          	li	a2,128
    8000507c:	f5040593          	addi	a1,s0,-176
    80005080:	4501                	li	a0,0
    80005082:	ffffd097          	auipc	ra,0xffffd
    80005086:	080080e7          	jalr	128(ra) # 80002102 <argstr>
    8000508a:	87aa                	mv	a5,a0
    return -1;
    8000508c:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    8000508e:	0e07c263          	bltz	a5,80005172 <sys_exec+0x110>
    80005092:	f726                	sd	s1,424(sp)
    80005094:	f34a                	sd	s2,416(sp)
    80005096:	ef4e                	sd	s3,408(sp)
    80005098:	eb52                	sd	s4,400(sp)
  }
  memset(argv, 0, sizeof(argv));
    8000509a:	10000613          	li	a2,256
    8000509e:	4581                	li	a1,0
    800050a0:	e5040513          	addi	a0,s0,-432
    800050a4:	ffffb097          	auipc	ra,0xffffb
    800050a8:	0d6080e7          	jalr	214(ra) # 8000017a <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    800050ac:	e5040493          	addi	s1,s0,-432
  memset(argv, 0, sizeof(argv));
    800050b0:	89a6                	mv	s3,s1
    800050b2:	4901                	li	s2,0
    if(i >= NELEM(argv)){
    800050b4:	02000a13          	li	s4,32
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    800050b8:	00391513          	slli	a0,s2,0x3
    800050bc:	e4040593          	addi	a1,s0,-448
    800050c0:	e4843783          	ld	a5,-440(s0)
    800050c4:	953e                	add	a0,a0,a5
    800050c6:	ffffd097          	auipc	ra,0xffffd
    800050ca:	f5e080e7          	jalr	-162(ra) # 80002024 <fetchaddr>
    800050ce:	02054a63          	bltz	a0,80005102 <sys_exec+0xa0>
      goto bad;
    }
    if(uarg == 0){
    800050d2:	e4043783          	ld	a5,-448(s0)
    800050d6:	c7b9                	beqz	a5,80005124 <sys_exec+0xc2>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    800050d8:	ffffb097          	auipc	ra,0xffffb
    800050dc:	042080e7          	jalr	66(ra) # 8000011a <kalloc>
    800050e0:	85aa                	mv	a1,a0
    800050e2:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    800050e6:	cd11                	beqz	a0,80005102 <sys_exec+0xa0>
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800050e8:	6605                	lui	a2,0x1
    800050ea:	e4043503          	ld	a0,-448(s0)
    800050ee:	ffffd097          	auipc	ra,0xffffd
    800050f2:	f88080e7          	jalr	-120(ra) # 80002076 <fetchstr>
    800050f6:	00054663          	bltz	a0,80005102 <sys_exec+0xa0>
    if(i >= NELEM(argv)){
    800050fa:	0905                	addi	s2,s2,1
    800050fc:	09a1                	addi	s3,s3,8
    800050fe:	fb491de3          	bne	s2,s4,800050b8 <sys_exec+0x56>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005102:	f5040913          	addi	s2,s0,-176
    80005106:	6088                	ld	a0,0(s1)
    80005108:	c125                	beqz	a0,80005168 <sys_exec+0x106>
    kfree(argv[i]);
    8000510a:	ffffb097          	auipc	ra,0xffffb
    8000510e:	f12080e7          	jalr	-238(ra) # 8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005112:	04a1                	addi	s1,s1,8
    80005114:	ff2499e3          	bne	s1,s2,80005106 <sys_exec+0xa4>
  return -1;
    80005118:	557d                	li	a0,-1
    8000511a:	74ba                	ld	s1,424(sp)
    8000511c:	791a                	ld	s2,416(sp)
    8000511e:	69fa                	ld	s3,408(sp)
    80005120:	6a5a                	ld	s4,400(sp)
    80005122:	a881                	j	80005172 <sys_exec+0x110>
      argv[i] = 0;
    80005124:	0009079b          	sext.w	a5,s2
    80005128:	078e                	slli	a5,a5,0x3
    8000512a:	fd078793          	addi	a5,a5,-48
    8000512e:	97a2                	add	a5,a5,s0
    80005130:	e807b023          	sd	zero,-384(a5)
  int ret = exec(path, argv);
    80005134:	e5040593          	addi	a1,s0,-432
    80005138:	f5040513          	addi	a0,s0,-176
    8000513c:	fffff097          	auipc	ra,0xfffff
    80005140:	120080e7          	jalr	288(ra) # 8000425c <exec>
    80005144:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005146:	f5040993          	addi	s3,s0,-176
    8000514a:	6088                	ld	a0,0(s1)
    8000514c:	c901                	beqz	a0,8000515c <sys_exec+0xfa>
    kfree(argv[i]);
    8000514e:	ffffb097          	auipc	ra,0xffffb
    80005152:	ece080e7          	jalr	-306(ra) # 8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005156:	04a1                	addi	s1,s1,8
    80005158:	ff3499e3          	bne	s1,s3,8000514a <sys_exec+0xe8>
  return ret;
    8000515c:	854a                	mv	a0,s2
    8000515e:	74ba                	ld	s1,424(sp)
    80005160:	791a                	ld	s2,416(sp)
    80005162:	69fa                	ld	s3,408(sp)
    80005164:	6a5a                	ld	s4,400(sp)
    80005166:	a031                	j	80005172 <sys_exec+0x110>
  return -1;
    80005168:	557d                	li	a0,-1
    8000516a:	74ba                	ld	s1,424(sp)
    8000516c:	791a                	ld	s2,416(sp)
    8000516e:	69fa                	ld	s3,408(sp)
    80005170:	6a5a                	ld	s4,400(sp)
}
    80005172:	70fa                	ld	ra,440(sp)
    80005174:	745a                	ld	s0,432(sp)
    80005176:	6139                	addi	sp,sp,448
    80005178:	8082                	ret

000000008000517a <sys_pipe>:

uint64
sys_pipe(void)
{
    8000517a:	7139                	addi	sp,sp,-64
    8000517c:	fc06                	sd	ra,56(sp)
    8000517e:	f822                	sd	s0,48(sp)
    80005180:	f426                	sd	s1,40(sp)
    80005182:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80005184:	ffffc097          	auipc	ra,0xffffc
    80005188:	d82080e7          	jalr	-638(ra) # 80000f06 <myproc>
    8000518c:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    8000518e:	fd840593          	addi	a1,s0,-40
    80005192:	4501                	li	a0,0
    80005194:	ffffd097          	auipc	ra,0xffffd
    80005198:	f4e080e7          	jalr	-178(ra) # 800020e2 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    8000519c:	fc840593          	addi	a1,s0,-56
    800051a0:	fd040513          	addi	a0,s0,-48
    800051a4:	fffff097          	auipc	ra,0xfffff
    800051a8:	d50080e7          	jalr	-688(ra) # 80003ef4 <pipealloc>
    return -1;
    800051ac:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    800051ae:	0c054463          	bltz	a0,80005276 <sys_pipe+0xfc>
  fd0 = -1;
    800051b2:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    800051b6:	fd043503          	ld	a0,-48(s0)
    800051ba:	fffff097          	auipc	ra,0xfffff
    800051be:	4e0080e7          	jalr	1248(ra) # 8000469a <fdalloc>
    800051c2:	fca42223          	sw	a0,-60(s0)
    800051c6:	08054b63          	bltz	a0,8000525c <sys_pipe+0xe2>
    800051ca:	fc843503          	ld	a0,-56(s0)
    800051ce:	fffff097          	auipc	ra,0xfffff
    800051d2:	4cc080e7          	jalr	1228(ra) # 8000469a <fdalloc>
    800051d6:	fca42023          	sw	a0,-64(s0)
    800051da:	06054863          	bltz	a0,8000524a <sys_pipe+0xd0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800051de:	4691                	li	a3,4
    800051e0:	fc440613          	addi	a2,s0,-60
    800051e4:	fd843583          	ld	a1,-40(s0)
    800051e8:	68a8                	ld	a0,80(s1)
    800051ea:	ffffc097          	auipc	ra,0xffffc
    800051ee:	962080e7          	jalr	-1694(ra) # 80000b4c <copyout>
    800051f2:	02054063          	bltz	a0,80005212 <sys_pipe+0x98>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    800051f6:	4691                	li	a3,4
    800051f8:	fc040613          	addi	a2,s0,-64
    800051fc:	fd843583          	ld	a1,-40(s0)
    80005200:	0591                	addi	a1,a1,4
    80005202:	68a8                	ld	a0,80(s1)
    80005204:	ffffc097          	auipc	ra,0xffffc
    80005208:	948080e7          	jalr	-1720(ra) # 80000b4c <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    8000520c:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    8000520e:	06055463          	bgez	a0,80005276 <sys_pipe+0xfc>
    p->ofile[fd0] = 0;
    80005212:	fc442783          	lw	a5,-60(s0)
    80005216:	07e9                	addi	a5,a5,26
    80005218:	078e                	slli	a5,a5,0x3
    8000521a:	97a6                	add	a5,a5,s1
    8000521c:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    80005220:	fc042783          	lw	a5,-64(s0)
    80005224:	07e9                	addi	a5,a5,26
    80005226:	078e                	slli	a5,a5,0x3
    80005228:	94be                	add	s1,s1,a5
    8000522a:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    8000522e:	fd043503          	ld	a0,-48(s0)
    80005232:	fffff097          	auipc	ra,0xfffff
    80005236:	954080e7          	jalr	-1708(ra) # 80003b86 <fileclose>
    fileclose(wf);
    8000523a:	fc843503          	ld	a0,-56(s0)
    8000523e:	fffff097          	auipc	ra,0xfffff
    80005242:	948080e7          	jalr	-1720(ra) # 80003b86 <fileclose>
    return -1;
    80005246:	57fd                	li	a5,-1
    80005248:	a03d                	j	80005276 <sys_pipe+0xfc>
    if(fd0 >= 0)
    8000524a:	fc442783          	lw	a5,-60(s0)
    8000524e:	0007c763          	bltz	a5,8000525c <sys_pipe+0xe2>
      p->ofile[fd0] = 0;
    80005252:	07e9                	addi	a5,a5,26
    80005254:	078e                	slli	a5,a5,0x3
    80005256:	97a6                	add	a5,a5,s1
    80005258:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    8000525c:	fd043503          	ld	a0,-48(s0)
    80005260:	fffff097          	auipc	ra,0xfffff
    80005264:	926080e7          	jalr	-1754(ra) # 80003b86 <fileclose>
    fileclose(wf);
    80005268:	fc843503          	ld	a0,-56(s0)
    8000526c:	fffff097          	auipc	ra,0xfffff
    80005270:	91a080e7          	jalr	-1766(ra) # 80003b86 <fileclose>
    return -1;
    80005274:	57fd                	li	a5,-1
}
    80005276:	853e                	mv	a0,a5
    80005278:	70e2                	ld	ra,56(sp)
    8000527a:	7442                	ld	s0,48(sp)
    8000527c:	74a2                	ld	s1,40(sp)
    8000527e:	6121                	addi	sp,sp,64
    80005280:	8082                	ret
	...

0000000080005290 <kernelvec>:
    80005290:	7111                	addi	sp,sp,-256
    80005292:	e006                	sd	ra,0(sp)
    80005294:	e40a                	sd	sp,8(sp)
    80005296:	e80e                	sd	gp,16(sp)
    80005298:	ec12                	sd	tp,24(sp)
    8000529a:	f016                	sd	t0,32(sp)
    8000529c:	f41a                	sd	t1,40(sp)
    8000529e:	f81e                	sd	t2,48(sp)
    800052a0:	fc22                	sd	s0,56(sp)
    800052a2:	e0a6                	sd	s1,64(sp)
    800052a4:	e4aa                	sd	a0,72(sp)
    800052a6:	e8ae                	sd	a1,80(sp)
    800052a8:	ecb2                	sd	a2,88(sp)
    800052aa:	f0b6                	sd	a3,96(sp)
    800052ac:	f4ba                	sd	a4,104(sp)
    800052ae:	f8be                	sd	a5,112(sp)
    800052b0:	fcc2                	sd	a6,120(sp)
    800052b2:	e146                	sd	a7,128(sp)
    800052b4:	e54a                	sd	s2,136(sp)
    800052b6:	e94e                	sd	s3,144(sp)
    800052b8:	ed52                	sd	s4,152(sp)
    800052ba:	f156                	sd	s5,160(sp)
    800052bc:	f55a                	sd	s6,168(sp)
    800052be:	f95e                	sd	s7,176(sp)
    800052c0:	fd62                	sd	s8,184(sp)
    800052c2:	e1e6                	sd	s9,192(sp)
    800052c4:	e5ea                	sd	s10,200(sp)
    800052c6:	e9ee                	sd	s11,208(sp)
    800052c8:	edf2                	sd	t3,216(sp)
    800052ca:	f1f6                	sd	t4,224(sp)
    800052cc:	f5fa                	sd	t5,232(sp)
    800052ce:	f9fe                	sd	t6,240(sp)
    800052d0:	c21fc0ef          	jal	80001ef0 <kerneltrap>
    800052d4:	6082                	ld	ra,0(sp)
    800052d6:	6122                	ld	sp,8(sp)
    800052d8:	61c2                	ld	gp,16(sp)
    800052da:	7282                	ld	t0,32(sp)
    800052dc:	7322                	ld	t1,40(sp)
    800052de:	73c2                	ld	t2,48(sp)
    800052e0:	7462                	ld	s0,56(sp)
    800052e2:	6486                	ld	s1,64(sp)
    800052e4:	6526                	ld	a0,72(sp)
    800052e6:	65c6                	ld	a1,80(sp)
    800052e8:	6666                	ld	a2,88(sp)
    800052ea:	7686                	ld	a3,96(sp)
    800052ec:	7726                	ld	a4,104(sp)
    800052ee:	77c6                	ld	a5,112(sp)
    800052f0:	7866                	ld	a6,120(sp)
    800052f2:	688a                	ld	a7,128(sp)
    800052f4:	692a                	ld	s2,136(sp)
    800052f6:	69ca                	ld	s3,144(sp)
    800052f8:	6a6a                	ld	s4,152(sp)
    800052fa:	7a8a                	ld	s5,160(sp)
    800052fc:	7b2a                	ld	s6,168(sp)
    800052fe:	7bca                	ld	s7,176(sp)
    80005300:	7c6a                	ld	s8,184(sp)
    80005302:	6c8e                	ld	s9,192(sp)
    80005304:	6d2e                	ld	s10,200(sp)
    80005306:	6dce                	ld	s11,208(sp)
    80005308:	6e6e                	ld	t3,216(sp)
    8000530a:	7e8e                	ld	t4,224(sp)
    8000530c:	7f2e                	ld	t5,232(sp)
    8000530e:	7fce                	ld	t6,240(sp)
    80005310:	6111                	addi	sp,sp,256
    80005312:	10200073          	sret
    80005316:	00000013          	nop
    8000531a:	00000013          	nop
    8000531e:	0001                	nop

0000000080005320 <timervec>:
    80005320:	34051573          	csrrw	a0,mscratch,a0
    80005324:	e10c                	sd	a1,0(a0)
    80005326:	e510                	sd	a2,8(a0)
    80005328:	e914                	sd	a3,16(a0)
    8000532a:	6d0c                	ld	a1,24(a0)
    8000532c:	7110                	ld	a2,32(a0)
    8000532e:	6194                	ld	a3,0(a1)
    80005330:	96b2                	add	a3,a3,a2
    80005332:	e194                	sd	a3,0(a1)
    80005334:	4589                	li	a1,2
    80005336:	14459073          	csrw	sip,a1
    8000533a:	6914                	ld	a3,16(a0)
    8000533c:	6510                	ld	a2,8(a0)
    8000533e:	610c                	ld	a1,0(a0)
    80005340:	34051573          	csrrw	a0,mscratch,a0
    80005344:	30200073          	mret
	...

000000008000534a <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000534a:	1141                	addi	sp,sp,-16
    8000534c:	e422                	sd	s0,8(sp)
    8000534e:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80005350:	0c0007b7          	lui	a5,0xc000
    80005354:	4705                	li	a4,1
    80005356:	d798                	sw	a4,40(a5)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    80005358:	0c0007b7          	lui	a5,0xc000
    8000535c:	c3d8                	sw	a4,4(a5)
}
    8000535e:	6422                	ld	s0,8(sp)
    80005360:	0141                	addi	sp,sp,16
    80005362:	8082                	ret

0000000080005364 <plicinithart>:

void
plicinithart(void)
{
    80005364:	1141                	addi	sp,sp,-16
    80005366:	e406                	sd	ra,8(sp)
    80005368:	e022                	sd	s0,0(sp)
    8000536a:	0800                	addi	s0,sp,16
  int hart = cpuid();
    8000536c:	ffffc097          	auipc	ra,0xffffc
    80005370:	b6e080e7          	jalr	-1170(ra) # 80000eda <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80005374:	0085171b          	slliw	a4,a0,0x8
    80005378:	0c0027b7          	lui	a5,0xc002
    8000537c:	97ba                	add	a5,a5,a4
    8000537e:	40200713          	li	a4,1026
    80005382:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80005386:	00d5151b          	slliw	a0,a0,0xd
    8000538a:	0c2017b7          	lui	a5,0xc201
    8000538e:	97aa                	add	a5,a5,a0
    80005390:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80005394:	60a2                	ld	ra,8(sp)
    80005396:	6402                	ld	s0,0(sp)
    80005398:	0141                	addi	sp,sp,16
    8000539a:	8082                	ret

000000008000539c <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    8000539c:	1141                	addi	sp,sp,-16
    8000539e:	e406                	sd	ra,8(sp)
    800053a0:	e022                	sd	s0,0(sp)
    800053a2:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800053a4:	ffffc097          	auipc	ra,0xffffc
    800053a8:	b36080e7          	jalr	-1226(ra) # 80000eda <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    800053ac:	00d5151b          	slliw	a0,a0,0xd
    800053b0:	0c2017b7          	lui	a5,0xc201
    800053b4:	97aa                	add	a5,a5,a0
  return irq;
}
    800053b6:	43c8                	lw	a0,4(a5)
    800053b8:	60a2                	ld	ra,8(sp)
    800053ba:	6402                	ld	s0,0(sp)
    800053bc:	0141                	addi	sp,sp,16
    800053be:	8082                	ret

00000000800053c0 <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    800053c0:	1101                	addi	sp,sp,-32
    800053c2:	ec06                	sd	ra,24(sp)
    800053c4:	e822                	sd	s0,16(sp)
    800053c6:	e426                	sd	s1,8(sp)
    800053c8:	1000                	addi	s0,sp,32
    800053ca:	84aa                	mv	s1,a0
  int hart = cpuid();
    800053cc:	ffffc097          	auipc	ra,0xffffc
    800053d0:	b0e080e7          	jalr	-1266(ra) # 80000eda <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    800053d4:	00d5151b          	slliw	a0,a0,0xd
    800053d8:	0c2017b7          	lui	a5,0xc201
    800053dc:	97aa                	add	a5,a5,a0
    800053de:	c3c4                	sw	s1,4(a5)
}
    800053e0:	60e2                	ld	ra,24(sp)
    800053e2:	6442                	ld	s0,16(sp)
    800053e4:	64a2                	ld	s1,8(sp)
    800053e6:	6105                	addi	sp,sp,32
    800053e8:	8082                	ret

00000000800053ea <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    800053ea:	1141                	addi	sp,sp,-16
    800053ec:	e406                	sd	ra,8(sp)
    800053ee:	e022                	sd	s0,0(sp)
    800053f0:	0800                	addi	s0,sp,16
  if(i >= NUM)
    800053f2:	479d                	li	a5,7
    800053f4:	04a7cc63          	blt	a5,a0,8000544c <free_desc+0x62>
    panic("free_desc 1");
  if(disk.free[i])
    800053f8:	0001a797          	auipc	a5,0x1a
    800053fc:	34878793          	addi	a5,a5,840 # 8001f740 <disk>
    80005400:	97aa                	add	a5,a5,a0
    80005402:	0187c783          	lbu	a5,24(a5)
    80005406:	ebb9                	bnez	a5,8000545c <free_desc+0x72>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005408:	00451693          	slli	a3,a0,0x4
    8000540c:	0001a797          	auipc	a5,0x1a
    80005410:	33478793          	addi	a5,a5,820 # 8001f740 <disk>
    80005414:	6398                	ld	a4,0(a5)
    80005416:	9736                	add	a4,a4,a3
    80005418:	00073023          	sd	zero,0(a4)
  disk.desc[i].len = 0;
    8000541c:	6398                	ld	a4,0(a5)
    8000541e:	9736                	add	a4,a4,a3
    80005420:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    80005424:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005428:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    8000542c:	97aa                	add	a5,a5,a0
    8000542e:	4705                	li	a4,1
    80005430:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    80005434:	0001a517          	auipc	a0,0x1a
    80005438:	32450513          	addi	a0,a0,804 # 8001f758 <disk+0x18>
    8000543c:	ffffc097          	auipc	ra,0xffffc
    80005440:	22e080e7          	jalr	558(ra) # 8000166a <wakeup>
}
    80005444:	60a2                	ld	ra,8(sp)
    80005446:	6402                	ld	s0,0(sp)
    80005448:	0141                	addi	sp,sp,16
    8000544a:	8082                	ret
    panic("free_desc 1");
    8000544c:	00003517          	auipc	a0,0x3
    80005450:	1bc50513          	addi	a0,a0,444 # 80008608 <etext+0x608>
    80005454:	00001097          	auipc	ra,0x1
    80005458:	b38080e7          	jalr	-1224(ra) # 80005f8c <panic>
    panic("free_desc 2");
    8000545c:	00003517          	auipc	a0,0x3
    80005460:	1bc50513          	addi	a0,a0,444 # 80008618 <etext+0x618>
    80005464:	00001097          	auipc	ra,0x1
    80005468:	b28080e7          	jalr	-1240(ra) # 80005f8c <panic>

000000008000546c <virtio_disk_init>:
{
    8000546c:	1101                	addi	sp,sp,-32
    8000546e:	ec06                	sd	ra,24(sp)
    80005470:	e822                	sd	s0,16(sp)
    80005472:	e426                	sd	s1,8(sp)
    80005474:	e04a                	sd	s2,0(sp)
    80005476:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80005478:	00003597          	auipc	a1,0x3
    8000547c:	1b058593          	addi	a1,a1,432 # 80008628 <etext+0x628>
    80005480:	0001a517          	auipc	a0,0x1a
    80005484:	3e850513          	addi	a0,a0,1000 # 8001f868 <disk+0x128>
    80005488:	00001097          	auipc	ra,0x1
    8000548c:	ff6080e7          	jalr	-10(ra) # 8000647e <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005490:	100017b7          	lui	a5,0x10001
    80005494:	4398                	lw	a4,0(a5)
    80005496:	2701                	sext.w	a4,a4
    80005498:	747277b7          	lui	a5,0x74727
    8000549c:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    800054a0:	18f71c63          	bne	a4,a5,80005638 <virtio_disk_init+0x1cc>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800054a4:	100017b7          	lui	a5,0x10001
    800054a8:	0791                	addi	a5,a5,4 # 10001004 <_entry-0x6fffeffc>
    800054aa:	439c                	lw	a5,0(a5)
    800054ac:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800054ae:	4709                	li	a4,2
    800054b0:	18e79463          	bne	a5,a4,80005638 <virtio_disk_init+0x1cc>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800054b4:	100017b7          	lui	a5,0x10001
    800054b8:	07a1                	addi	a5,a5,8 # 10001008 <_entry-0x6fffeff8>
    800054ba:	439c                	lw	a5,0(a5)
    800054bc:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800054be:	16e79d63          	bne	a5,a4,80005638 <virtio_disk_init+0x1cc>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    800054c2:	100017b7          	lui	a5,0x10001
    800054c6:	47d8                	lw	a4,12(a5)
    800054c8:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800054ca:	554d47b7          	lui	a5,0x554d4
    800054ce:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    800054d2:	16f71363          	bne	a4,a5,80005638 <virtio_disk_init+0x1cc>
  *R(VIRTIO_MMIO_STATUS) = status;
    800054d6:	100017b7          	lui	a5,0x10001
    800054da:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    800054de:	4705                	li	a4,1
    800054e0:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800054e2:	470d                	li	a4,3
    800054e4:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    800054e6:	10001737          	lui	a4,0x10001
    800054ea:	4b14                	lw	a3,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    800054ec:	c7ffe737          	lui	a4,0xc7ffe
    800054f0:	75f70713          	addi	a4,a4,1887 # ffffffffc7ffe75f <end+0xffffffff47fd6c9f>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    800054f4:	8ef9                	and	a3,a3,a4
    800054f6:	10001737          	lui	a4,0x10001
    800054fa:	d314                	sw	a3,32(a4)
  *R(VIRTIO_MMIO_STATUS) = status;
    800054fc:	472d                	li	a4,11
    800054fe:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005500:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    80005504:	439c                	lw	a5,0(a5)
    80005506:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    8000550a:	8ba1                	andi	a5,a5,8
    8000550c:	12078e63          	beqz	a5,80005648 <virtio_disk_init+0x1dc>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005510:	100017b7          	lui	a5,0x10001
    80005514:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80005518:	100017b7          	lui	a5,0x10001
    8000551c:	04478793          	addi	a5,a5,68 # 10001044 <_entry-0x6fffefbc>
    80005520:	439c                	lw	a5,0(a5)
    80005522:	2781                	sext.w	a5,a5
    80005524:	12079a63          	bnez	a5,80005658 <virtio_disk_init+0x1ec>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005528:	100017b7          	lui	a5,0x10001
    8000552c:	03478793          	addi	a5,a5,52 # 10001034 <_entry-0x6fffefcc>
    80005530:	439c                	lw	a5,0(a5)
    80005532:	2781                	sext.w	a5,a5
  if(max == 0)
    80005534:	12078a63          	beqz	a5,80005668 <virtio_disk_init+0x1fc>
  if(max < NUM)
    80005538:	471d                	li	a4,7
    8000553a:	12f77f63          	bgeu	a4,a5,80005678 <virtio_disk_init+0x20c>
  disk.desc = kalloc();
    8000553e:	ffffb097          	auipc	ra,0xffffb
    80005542:	bdc080e7          	jalr	-1060(ra) # 8000011a <kalloc>
    80005546:	0001a497          	auipc	s1,0x1a
    8000554a:	1fa48493          	addi	s1,s1,506 # 8001f740 <disk>
    8000554e:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80005550:	ffffb097          	auipc	ra,0xffffb
    80005554:	bca080e7          	jalr	-1078(ra) # 8000011a <kalloc>
    80005558:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    8000555a:	ffffb097          	auipc	ra,0xffffb
    8000555e:	bc0080e7          	jalr	-1088(ra) # 8000011a <kalloc>
    80005562:	87aa                	mv	a5,a0
    80005564:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80005566:	6088                	ld	a0,0(s1)
    80005568:	12050063          	beqz	a0,80005688 <virtio_disk_init+0x21c>
    8000556c:	0001a717          	auipc	a4,0x1a
    80005570:	1dc73703          	ld	a4,476(a4) # 8001f748 <disk+0x8>
    80005574:	10070a63          	beqz	a4,80005688 <virtio_disk_init+0x21c>
    80005578:	10078863          	beqz	a5,80005688 <virtio_disk_init+0x21c>
  memset(disk.desc, 0, PGSIZE);
    8000557c:	6605                	lui	a2,0x1
    8000557e:	4581                	li	a1,0
    80005580:	ffffb097          	auipc	ra,0xffffb
    80005584:	bfa080e7          	jalr	-1030(ra) # 8000017a <memset>
  memset(disk.avail, 0, PGSIZE);
    80005588:	0001a497          	auipc	s1,0x1a
    8000558c:	1b848493          	addi	s1,s1,440 # 8001f740 <disk>
    80005590:	6605                	lui	a2,0x1
    80005592:	4581                	li	a1,0
    80005594:	6488                	ld	a0,8(s1)
    80005596:	ffffb097          	auipc	ra,0xffffb
    8000559a:	be4080e7          	jalr	-1052(ra) # 8000017a <memset>
  memset(disk.used, 0, PGSIZE);
    8000559e:	6605                	lui	a2,0x1
    800055a0:	4581                	li	a1,0
    800055a2:	6888                	ld	a0,16(s1)
    800055a4:	ffffb097          	auipc	ra,0xffffb
    800055a8:	bd6080e7          	jalr	-1066(ra) # 8000017a <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    800055ac:	100017b7          	lui	a5,0x10001
    800055b0:	4721                	li	a4,8
    800055b2:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    800055b4:	4098                	lw	a4,0(s1)
    800055b6:	100017b7          	lui	a5,0x10001
    800055ba:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    800055be:	40d8                	lw	a4,4(s1)
    800055c0:	100017b7          	lui	a5,0x10001
    800055c4:	08e7a223          	sw	a4,132(a5) # 10001084 <_entry-0x6fffef7c>
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    800055c8:	649c                	ld	a5,8(s1)
    800055ca:	0007869b          	sext.w	a3,a5
    800055ce:	10001737          	lui	a4,0x10001
    800055d2:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    800055d6:	9781                	srai	a5,a5,0x20
    800055d8:	10001737          	lui	a4,0x10001
    800055dc:	08f72a23          	sw	a5,148(a4) # 10001094 <_entry-0x6fffef6c>
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    800055e0:	689c                	ld	a5,16(s1)
    800055e2:	0007869b          	sext.w	a3,a5
    800055e6:	10001737          	lui	a4,0x10001
    800055ea:	0ad72023          	sw	a3,160(a4) # 100010a0 <_entry-0x6fffef60>
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    800055ee:	9781                	srai	a5,a5,0x20
    800055f0:	10001737          	lui	a4,0x10001
    800055f4:	0af72223          	sw	a5,164(a4) # 100010a4 <_entry-0x6fffef5c>
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    800055f8:	10001737          	lui	a4,0x10001
    800055fc:	4785                	li	a5,1
    800055fe:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80005600:	00f48c23          	sb	a5,24(s1)
    80005604:	00f48ca3          	sb	a5,25(s1)
    80005608:	00f48d23          	sb	a5,26(s1)
    8000560c:	00f48da3          	sb	a5,27(s1)
    80005610:	00f48e23          	sb	a5,28(s1)
    80005614:	00f48ea3          	sb	a5,29(s1)
    80005618:	00f48f23          	sb	a5,30(s1)
    8000561c:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005620:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005624:	100017b7          	lui	a5,0x10001
    80005628:	0727a823          	sw	s2,112(a5) # 10001070 <_entry-0x6fffef90>
}
    8000562c:	60e2                	ld	ra,24(sp)
    8000562e:	6442                	ld	s0,16(sp)
    80005630:	64a2                	ld	s1,8(sp)
    80005632:	6902                	ld	s2,0(sp)
    80005634:	6105                	addi	sp,sp,32
    80005636:	8082                	ret
    panic("could not find virtio disk");
    80005638:	00003517          	auipc	a0,0x3
    8000563c:	00050513          	mv	a0,a0
    80005640:	00001097          	auipc	ra,0x1
    80005644:	94c080e7          	jalr	-1716(ra) # 80005f8c <panic>
    panic("virtio disk FEATURES_OK unset");
    80005648:	00003517          	auipc	a0,0x3
    8000564c:	01050513          	addi	a0,a0,16 # 80008658 <etext+0x658>
    80005650:	00001097          	auipc	ra,0x1
    80005654:	93c080e7          	jalr	-1732(ra) # 80005f8c <panic>
    panic("virtio disk should not be ready");
    80005658:	00003517          	auipc	a0,0x3
    8000565c:	02050513          	addi	a0,a0,32 # 80008678 <etext+0x678>
    80005660:	00001097          	auipc	ra,0x1
    80005664:	92c080e7          	jalr	-1748(ra) # 80005f8c <panic>
    panic("virtio disk has no queue 0");
    80005668:	00003517          	auipc	a0,0x3
    8000566c:	03050513          	addi	a0,a0,48 # 80008698 <etext+0x698>
    80005670:	00001097          	auipc	ra,0x1
    80005674:	91c080e7          	jalr	-1764(ra) # 80005f8c <panic>
    panic("virtio disk max queue too short");
    80005678:	00003517          	auipc	a0,0x3
    8000567c:	04050513          	addi	a0,a0,64 # 800086b8 <etext+0x6b8>
    80005680:	00001097          	auipc	ra,0x1
    80005684:	90c080e7          	jalr	-1780(ra) # 80005f8c <panic>
    panic("virtio disk kalloc");
    80005688:	00003517          	auipc	a0,0x3
    8000568c:	05050513          	addi	a0,a0,80 # 800086d8 <etext+0x6d8>
    80005690:	00001097          	auipc	ra,0x1
    80005694:	8fc080e7          	jalr	-1796(ra) # 80005f8c <panic>

0000000080005698 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80005698:	7159                	addi	sp,sp,-112
    8000569a:	f486                	sd	ra,104(sp)
    8000569c:	f0a2                	sd	s0,96(sp)
    8000569e:	eca6                	sd	s1,88(sp)
    800056a0:	e8ca                	sd	s2,80(sp)
    800056a2:	e4ce                	sd	s3,72(sp)
    800056a4:	e0d2                	sd	s4,64(sp)
    800056a6:	fc56                	sd	s5,56(sp)
    800056a8:	f85a                	sd	s6,48(sp)
    800056aa:	f45e                	sd	s7,40(sp)
    800056ac:	f062                	sd	s8,32(sp)
    800056ae:	ec66                	sd	s9,24(sp)
    800056b0:	1880                	addi	s0,sp,112
    800056b2:	8a2a                	mv	s4,a0
    800056b4:	8bae                	mv	s7,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    800056b6:	00c52c83          	lw	s9,12(a0)
    800056ba:	001c9c9b          	slliw	s9,s9,0x1
    800056be:	1c82                	slli	s9,s9,0x20
    800056c0:	020cdc93          	srli	s9,s9,0x20

  acquire(&disk.vdisk_lock);
    800056c4:	0001a517          	auipc	a0,0x1a
    800056c8:	1a450513          	addi	a0,a0,420 # 8001f868 <disk+0x128>
    800056cc:	00001097          	auipc	ra,0x1
    800056d0:	e42080e7          	jalr	-446(ra) # 8000650e <acquire>
  for(int i = 0; i < 3; i++){
    800056d4:	4981                	li	s3,0
  for(int i = 0; i < NUM; i++){
    800056d6:	44a1                	li	s1,8
      disk.free[i] = 0;
    800056d8:	0001ab17          	auipc	s6,0x1a
    800056dc:	068b0b13          	addi	s6,s6,104 # 8001f740 <disk>
  for(int i = 0; i < 3; i++){
    800056e0:	4a8d                	li	s5,3
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    800056e2:	0001ac17          	auipc	s8,0x1a
    800056e6:	186c0c13          	addi	s8,s8,390 # 8001f868 <disk+0x128>
    800056ea:	a0ad                	j	80005754 <virtio_disk_rw+0xbc>
      disk.free[i] = 0;
    800056ec:	00fb0733          	add	a4,s6,a5
    800056f0:	00070c23          	sb	zero,24(a4) # 10001018 <_entry-0x6fffefe8>
    idx[i] = alloc_desc();
    800056f4:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    800056f6:	0207c563          	bltz	a5,80005720 <virtio_disk_rw+0x88>
  for(int i = 0; i < 3; i++){
    800056fa:	2905                	addiw	s2,s2,1
    800056fc:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    800056fe:	05590f63          	beq	s2,s5,8000575c <virtio_disk_rw+0xc4>
    idx[i] = alloc_desc();
    80005702:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80005704:	0001a717          	auipc	a4,0x1a
    80005708:	03c70713          	addi	a4,a4,60 # 8001f740 <disk>
    8000570c:	87ce                	mv	a5,s3
    if(disk.free[i]){
    8000570e:	01874683          	lbu	a3,24(a4)
    80005712:	fee9                	bnez	a3,800056ec <virtio_disk_rw+0x54>
  for(int i = 0; i < NUM; i++){
    80005714:	2785                	addiw	a5,a5,1
    80005716:	0705                	addi	a4,a4,1
    80005718:	fe979be3          	bne	a5,s1,8000570e <virtio_disk_rw+0x76>
    idx[i] = alloc_desc();
    8000571c:	57fd                	li	a5,-1
    8000571e:	c19c                	sw	a5,0(a1)
      for(int j = 0; j < i; j++)
    80005720:	03205163          	blez	s2,80005742 <virtio_disk_rw+0xaa>
        free_desc(idx[j]);
    80005724:	f9042503          	lw	a0,-112(s0)
    80005728:	00000097          	auipc	ra,0x0
    8000572c:	cc2080e7          	jalr	-830(ra) # 800053ea <free_desc>
      for(int j = 0; j < i; j++)
    80005730:	4785                	li	a5,1
    80005732:	0127d863          	bge	a5,s2,80005742 <virtio_disk_rw+0xaa>
        free_desc(idx[j]);
    80005736:	f9442503          	lw	a0,-108(s0)
    8000573a:	00000097          	auipc	ra,0x0
    8000573e:	cb0080e7          	jalr	-848(ra) # 800053ea <free_desc>
    sleep(&disk.free[0], &disk.vdisk_lock);
    80005742:	85e2                	mv	a1,s8
    80005744:	0001a517          	auipc	a0,0x1a
    80005748:	01450513          	addi	a0,a0,20 # 8001f758 <disk+0x18>
    8000574c:	ffffc097          	auipc	ra,0xffffc
    80005750:	eba080e7          	jalr	-326(ra) # 80001606 <sleep>
  for(int i = 0; i < 3; i++){
    80005754:	f9040613          	addi	a2,s0,-112
    80005758:	894e                	mv	s2,s3
    8000575a:	b765                	j	80005702 <virtio_disk_rw+0x6a>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    8000575c:	f9042503          	lw	a0,-112(s0)
    80005760:	00451693          	slli	a3,a0,0x4

  if(write)
    80005764:	0001a797          	auipc	a5,0x1a
    80005768:	fdc78793          	addi	a5,a5,-36 # 8001f740 <disk>
    8000576c:	00a50713          	addi	a4,a0,10
    80005770:	0712                	slli	a4,a4,0x4
    80005772:	973e                	add	a4,a4,a5
    80005774:	01703633          	snez	a2,s7
    80005778:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    8000577a:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    8000577e:	01973823          	sd	s9,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80005782:	6398                	ld	a4,0(a5)
    80005784:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005786:	0a868613          	addi	a2,a3,168
    8000578a:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    8000578c:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    8000578e:	6390                	ld	a2,0(a5)
    80005790:	00d605b3          	add	a1,a2,a3
    80005794:	4741                	li	a4,16
    80005796:	c598                	sw	a4,8(a1)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005798:	4805                	li	a6,1
    8000579a:	01059623          	sh	a6,12(a1)
  disk.desc[idx[0]].next = idx[1];
    8000579e:	f9442703          	lw	a4,-108(s0)
    800057a2:	00e59723          	sh	a4,14(a1)

  disk.desc[idx[1]].addr = (uint64) b->data;
    800057a6:	0712                	slli	a4,a4,0x4
    800057a8:	963a                	add	a2,a2,a4
    800057aa:	058a0593          	addi	a1,s4,88
    800057ae:	e20c                	sd	a1,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    800057b0:	0007b883          	ld	a7,0(a5)
    800057b4:	9746                	add	a4,a4,a7
    800057b6:	40000613          	li	a2,1024
    800057ba:	c710                	sw	a2,8(a4)
  if(write)
    800057bc:	001bb613          	seqz	a2,s7
    800057c0:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    800057c4:	00166613          	ori	a2,a2,1
    800057c8:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    800057cc:	f9842583          	lw	a1,-104(s0)
    800057d0:	00b71723          	sh	a1,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    800057d4:	00250613          	addi	a2,a0,2
    800057d8:	0612                	slli	a2,a2,0x4
    800057da:	963e                	add	a2,a2,a5
    800057dc:	577d                	li	a4,-1
    800057de:	00e60823          	sb	a4,16(a2)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    800057e2:	0592                	slli	a1,a1,0x4
    800057e4:	98ae                	add	a7,a7,a1
    800057e6:	03068713          	addi	a4,a3,48
    800057ea:	973e                	add	a4,a4,a5
    800057ec:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    800057f0:	6398                	ld	a4,0(a5)
    800057f2:	972e                	add	a4,a4,a1
    800057f4:	01072423          	sw	a6,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    800057f8:	4689                	li	a3,2
    800057fa:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    800057fe:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80005802:	010a2223          	sw	a6,4(s4)
  disk.info[idx[0]].b = b;
    80005806:	01463423          	sd	s4,8(a2)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    8000580a:	6794                	ld	a3,8(a5)
    8000580c:	0026d703          	lhu	a4,2(a3)
    80005810:	8b1d                	andi	a4,a4,7
    80005812:	0706                	slli	a4,a4,0x1
    80005814:	96ba                	add	a3,a3,a4
    80005816:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    8000581a:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    8000581e:	6798                	ld	a4,8(a5)
    80005820:	00275783          	lhu	a5,2(a4)
    80005824:	2785                	addiw	a5,a5,1
    80005826:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    8000582a:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    8000582e:	100017b7          	lui	a5,0x10001
    80005832:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80005836:	004a2783          	lw	a5,4(s4)
    sleep(b, &disk.vdisk_lock);
    8000583a:	0001a917          	auipc	s2,0x1a
    8000583e:	02e90913          	addi	s2,s2,46 # 8001f868 <disk+0x128>
  while(b->disk == 1) {
    80005842:	4485                	li	s1,1
    80005844:	01079c63          	bne	a5,a6,8000585c <virtio_disk_rw+0x1c4>
    sleep(b, &disk.vdisk_lock);
    80005848:	85ca                	mv	a1,s2
    8000584a:	8552                	mv	a0,s4
    8000584c:	ffffc097          	auipc	ra,0xffffc
    80005850:	dba080e7          	jalr	-582(ra) # 80001606 <sleep>
  while(b->disk == 1) {
    80005854:	004a2783          	lw	a5,4(s4)
    80005858:	fe9788e3          	beq	a5,s1,80005848 <virtio_disk_rw+0x1b0>
  }

  disk.info[idx[0]].b = 0;
    8000585c:	f9042903          	lw	s2,-112(s0)
    80005860:	00290713          	addi	a4,s2,2
    80005864:	0712                	slli	a4,a4,0x4
    80005866:	0001a797          	auipc	a5,0x1a
    8000586a:	eda78793          	addi	a5,a5,-294 # 8001f740 <disk>
    8000586e:	97ba                	add	a5,a5,a4
    80005870:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80005874:	0001a997          	auipc	s3,0x1a
    80005878:	ecc98993          	addi	s3,s3,-308 # 8001f740 <disk>
    8000587c:	00491713          	slli	a4,s2,0x4
    80005880:	0009b783          	ld	a5,0(s3)
    80005884:	97ba                	add	a5,a5,a4
    80005886:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    8000588a:	854a                	mv	a0,s2
    8000588c:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005890:	00000097          	auipc	ra,0x0
    80005894:	b5a080e7          	jalr	-1190(ra) # 800053ea <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80005898:	8885                	andi	s1,s1,1
    8000589a:	f0ed                	bnez	s1,8000587c <virtio_disk_rw+0x1e4>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    8000589c:	0001a517          	auipc	a0,0x1a
    800058a0:	fcc50513          	addi	a0,a0,-52 # 8001f868 <disk+0x128>
    800058a4:	00001097          	auipc	ra,0x1
    800058a8:	d1e080e7          	jalr	-738(ra) # 800065c2 <release>
}
    800058ac:	70a6                	ld	ra,104(sp)
    800058ae:	7406                	ld	s0,96(sp)
    800058b0:	64e6                	ld	s1,88(sp)
    800058b2:	6946                	ld	s2,80(sp)
    800058b4:	69a6                	ld	s3,72(sp)
    800058b6:	6a06                	ld	s4,64(sp)
    800058b8:	7ae2                	ld	s5,56(sp)
    800058ba:	7b42                	ld	s6,48(sp)
    800058bc:	7ba2                	ld	s7,40(sp)
    800058be:	7c02                	ld	s8,32(sp)
    800058c0:	6ce2                	ld	s9,24(sp)
    800058c2:	6165                	addi	sp,sp,112
    800058c4:	8082                	ret

00000000800058c6 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    800058c6:	1101                	addi	sp,sp,-32
    800058c8:	ec06                	sd	ra,24(sp)
    800058ca:	e822                	sd	s0,16(sp)
    800058cc:	e426                	sd	s1,8(sp)
    800058ce:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    800058d0:	0001a497          	auipc	s1,0x1a
    800058d4:	e7048493          	addi	s1,s1,-400 # 8001f740 <disk>
    800058d8:	0001a517          	auipc	a0,0x1a
    800058dc:	f9050513          	addi	a0,a0,-112 # 8001f868 <disk+0x128>
    800058e0:	00001097          	auipc	ra,0x1
    800058e4:	c2e080e7          	jalr	-978(ra) # 8000650e <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    800058e8:	100017b7          	lui	a5,0x10001
    800058ec:	53b8                	lw	a4,96(a5)
    800058ee:	8b0d                	andi	a4,a4,3
    800058f0:	100017b7          	lui	a5,0x10001
    800058f4:	d3f8                	sw	a4,100(a5)

  __sync_synchronize();
    800058f6:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    800058fa:	689c                	ld	a5,16(s1)
    800058fc:	0204d703          	lhu	a4,32(s1)
    80005900:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80005904:	04f70863          	beq	a4,a5,80005954 <virtio_disk_intr+0x8e>
    __sync_synchronize();
    80005908:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    8000590c:	6898                	ld	a4,16(s1)
    8000590e:	0204d783          	lhu	a5,32(s1)
    80005912:	8b9d                	andi	a5,a5,7
    80005914:	078e                	slli	a5,a5,0x3
    80005916:	97ba                	add	a5,a5,a4
    80005918:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    8000591a:	00278713          	addi	a4,a5,2
    8000591e:	0712                	slli	a4,a4,0x4
    80005920:	9726                	add	a4,a4,s1
    80005922:	01074703          	lbu	a4,16(a4)
    80005926:	e721                	bnez	a4,8000596e <virtio_disk_intr+0xa8>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005928:	0789                	addi	a5,a5,2
    8000592a:	0792                	slli	a5,a5,0x4
    8000592c:	97a6                	add	a5,a5,s1
    8000592e:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80005930:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005934:	ffffc097          	auipc	ra,0xffffc
    80005938:	d36080e7          	jalr	-714(ra) # 8000166a <wakeup>

    disk.used_idx += 1;
    8000593c:	0204d783          	lhu	a5,32(s1)
    80005940:	2785                	addiw	a5,a5,1
    80005942:	17c2                	slli	a5,a5,0x30
    80005944:	93c1                	srli	a5,a5,0x30
    80005946:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    8000594a:	6898                	ld	a4,16(s1)
    8000594c:	00275703          	lhu	a4,2(a4)
    80005950:	faf71ce3          	bne	a4,a5,80005908 <virtio_disk_intr+0x42>
  }

  release(&disk.vdisk_lock);
    80005954:	0001a517          	auipc	a0,0x1a
    80005958:	f1450513          	addi	a0,a0,-236 # 8001f868 <disk+0x128>
    8000595c:	00001097          	auipc	ra,0x1
    80005960:	c66080e7          	jalr	-922(ra) # 800065c2 <release>
}
    80005964:	60e2                	ld	ra,24(sp)
    80005966:	6442                	ld	s0,16(sp)
    80005968:	64a2                	ld	s1,8(sp)
    8000596a:	6105                	addi	sp,sp,32
    8000596c:	8082                	ret
      panic("virtio_disk_intr status");
    8000596e:	00003517          	auipc	a0,0x3
    80005972:	d8250513          	addi	a0,a0,-638 # 800086f0 <etext+0x6f0>
    80005976:	00000097          	auipc	ra,0x0
    8000597a:	616080e7          	jalr	1558(ra) # 80005f8c <panic>

000000008000597e <timerinit>:
// at timervec in kernelvec.S,
// which turns them into software interrupts for
// devintr() in trap.c.
void
timerinit()
{
    8000597e:	1141                	addi	sp,sp,-16
    80005980:	e422                	sd	s0,8(sp)
    80005982:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    80005984:	f14027f3          	csrr	a5,mhartid
  // each CPU has a separate source of timer interrupts.
  int id = r_mhartid();
    80005988:	0007859b          	sext.w	a1,a5

  // ask the CLINT for a timer interrupt.
  int interval = 1000000; // cycles; about 1/10th second in qemu.
  *(uint64*)CLINT_MTIMECMP(id) = *(uint64*)CLINT_MTIME + interval;
    8000598c:	0037979b          	slliw	a5,a5,0x3
    80005990:	02004737          	lui	a4,0x2004
    80005994:	97ba                	add	a5,a5,a4
    80005996:	0200c737          	lui	a4,0x200c
    8000599a:	1761                	addi	a4,a4,-8 # 200bff8 <_entry-0x7dff4008>
    8000599c:	6318                	ld	a4,0(a4)
    8000599e:	000f4637          	lui	a2,0xf4
    800059a2:	24060613          	addi	a2,a2,576 # f4240 <_entry-0x7ff0bdc0>
    800059a6:	9732                	add	a4,a4,a2
    800059a8:	e398                	sd	a4,0(a5)

  // prepare information in scratch[] for timervec.
  // scratch[0..2] : space for timervec to save registers.
  // scratch[3] : address of CLINT MTIMECMP register.
  // scratch[4] : desired interval (in cycles) between timer interrupts.
  uint64 *scratch = &timer_scratch[id][0];
    800059aa:	00259693          	slli	a3,a1,0x2
    800059ae:	96ae                	add	a3,a3,a1
    800059b0:	068e                	slli	a3,a3,0x3
    800059b2:	0001a717          	auipc	a4,0x1a
    800059b6:	ece70713          	addi	a4,a4,-306 # 8001f880 <timer_scratch>
    800059ba:	9736                	add	a4,a4,a3
  scratch[3] = CLINT_MTIMECMP(id);
    800059bc:	ef1c                	sd	a5,24(a4)
  scratch[4] = interval;
    800059be:	f310                	sd	a2,32(a4)
  asm volatile("csrw mscratch, %0" : : "r" (x));
    800059c0:	34071073          	csrw	mscratch,a4
  asm volatile("csrw mtvec, %0" : : "r" (x));
    800059c4:	00000797          	auipc	a5,0x0
    800059c8:	95c78793          	addi	a5,a5,-1700 # 80005320 <timervec>
    800059cc:	30579073          	csrw	mtvec,a5
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    800059d0:	300027f3          	csrr	a5,mstatus

  // set the machine-mode trap handler.
  w_mtvec((uint64)timervec);

  // enable machine-mode interrupts.
  w_mstatus(r_mstatus() | MSTATUS_MIE);
    800059d4:	0087e793          	ori	a5,a5,8
  asm volatile("csrw mstatus, %0" : : "r" (x));
    800059d8:	30079073          	csrw	mstatus,a5
  asm volatile("csrr %0, mie" : "=r" (x) );
    800059dc:	304027f3          	csrr	a5,mie

  // enable machine-mode timer interrupts.
  w_mie(r_mie() | MIE_MTIE);
    800059e0:	0807e793          	ori	a5,a5,128
  asm volatile("csrw mie, %0" : : "r" (x));
    800059e4:	30479073          	csrw	mie,a5
}
    800059e8:	6422                	ld	s0,8(sp)
    800059ea:	0141                	addi	sp,sp,16
    800059ec:	8082                	ret

00000000800059ee <start>:
{
    800059ee:	1141                	addi	sp,sp,-16
    800059f0:	e406                	sd	ra,8(sp)
    800059f2:	e022                	sd	s0,0(sp)
    800059f4:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    800059f6:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    800059fa:	7779                	lui	a4,0xffffe
    800059fc:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffd6d3f>
    80005a00:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80005a02:	6705                	lui	a4,0x1
    80005a04:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    80005a08:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80005a0a:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80005a0e:	ffffb797          	auipc	a5,0xffffb
    80005a12:	90a78793          	addi	a5,a5,-1782 # 80000318 <main>
    80005a16:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80005a1a:	4781                	li	a5,0
    80005a1c:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80005a20:	67c1                	lui	a5,0x10
    80005a22:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    80005a24:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    80005a28:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    80005a2c:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    80005a30:	2227e793          	ori	a5,a5,546
  asm volatile("csrw sie, %0" : : "r" (x));
    80005a34:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    80005a38:	57fd                	li	a5,-1
    80005a3a:	83a9                	srli	a5,a5,0xa
    80005a3c:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    80005a40:	47bd                	li	a5,15
    80005a42:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    80005a46:	00000097          	auipc	ra,0x0
    80005a4a:	f38080e7          	jalr	-200(ra) # 8000597e <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    80005a4e:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    80005a52:	2781                	sext.w	a5,a5
  asm volatile("mv tp, %0" : : "r" (x));
    80005a54:	823e                	mv	tp,a5
  asm volatile("mret");
    80005a56:	30200073          	mret
}
    80005a5a:	60a2                	ld	ra,8(sp)
    80005a5c:	6402                	ld	s0,0(sp)
    80005a5e:	0141                	addi	sp,sp,16
    80005a60:	8082                	ret

0000000080005a62 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    80005a62:	715d                	addi	sp,sp,-80
    80005a64:	e486                	sd	ra,72(sp)
    80005a66:	e0a2                	sd	s0,64(sp)
    80005a68:	f84a                	sd	s2,48(sp)
    80005a6a:	0880                	addi	s0,sp,80
  int i;

  for(i = 0; i < n; i++){
    80005a6c:	04c05663          	blez	a2,80005ab8 <consolewrite+0x56>
    80005a70:	fc26                	sd	s1,56(sp)
    80005a72:	f44e                	sd	s3,40(sp)
    80005a74:	f052                	sd	s4,32(sp)
    80005a76:	ec56                	sd	s5,24(sp)
    80005a78:	8a2a                	mv	s4,a0
    80005a7a:	84ae                	mv	s1,a1
    80005a7c:	89b2                	mv	s3,a2
    80005a7e:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    80005a80:	5afd                	li	s5,-1
    80005a82:	4685                	li	a3,1
    80005a84:	8626                	mv	a2,s1
    80005a86:	85d2                	mv	a1,s4
    80005a88:	fbf40513          	addi	a0,s0,-65
    80005a8c:	ffffc097          	auipc	ra,0xffffc
    80005a90:	fd8080e7          	jalr	-40(ra) # 80001a64 <either_copyin>
    80005a94:	03550463          	beq	a0,s5,80005abc <consolewrite+0x5a>
      break;
    uartputc(c);
    80005a98:	fbf44503          	lbu	a0,-65(s0)
    80005a9c:	00001097          	auipc	ra,0x1
    80005aa0:	8b6080e7          	jalr	-1866(ra) # 80006352 <uartputc>
  for(i = 0; i < n; i++){
    80005aa4:	2905                	addiw	s2,s2,1
    80005aa6:	0485                	addi	s1,s1,1
    80005aa8:	fd299de3          	bne	s3,s2,80005a82 <consolewrite+0x20>
    80005aac:	894e                	mv	s2,s3
    80005aae:	74e2                	ld	s1,56(sp)
    80005ab0:	79a2                	ld	s3,40(sp)
    80005ab2:	7a02                	ld	s4,32(sp)
    80005ab4:	6ae2                	ld	s5,24(sp)
    80005ab6:	a039                	j	80005ac4 <consolewrite+0x62>
    80005ab8:	4901                	li	s2,0
    80005aba:	a029                	j	80005ac4 <consolewrite+0x62>
    80005abc:	74e2                	ld	s1,56(sp)
    80005abe:	79a2                	ld	s3,40(sp)
    80005ac0:	7a02                	ld	s4,32(sp)
    80005ac2:	6ae2                	ld	s5,24(sp)
  }

  return i;
}
    80005ac4:	854a                	mv	a0,s2
    80005ac6:	60a6                	ld	ra,72(sp)
    80005ac8:	6406                	ld	s0,64(sp)
    80005aca:	7942                	ld	s2,48(sp)
    80005acc:	6161                	addi	sp,sp,80
    80005ace:	8082                	ret

0000000080005ad0 <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80005ad0:	711d                	addi	sp,sp,-96
    80005ad2:	ec86                	sd	ra,88(sp)
    80005ad4:	e8a2                	sd	s0,80(sp)
    80005ad6:	e4a6                	sd	s1,72(sp)
    80005ad8:	e0ca                	sd	s2,64(sp)
    80005ada:	fc4e                	sd	s3,56(sp)
    80005adc:	f852                	sd	s4,48(sp)
    80005ade:	f456                	sd	s5,40(sp)
    80005ae0:	f05a                	sd	s6,32(sp)
    80005ae2:	1080                	addi	s0,sp,96
    80005ae4:	8aaa                	mv	s5,a0
    80005ae6:	8a2e                	mv	s4,a1
    80005ae8:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80005aea:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    80005aee:	00022517          	auipc	a0,0x22
    80005af2:	ed250513          	addi	a0,a0,-302 # 800279c0 <cons>
    80005af6:	00001097          	auipc	ra,0x1
    80005afa:	a18080e7          	jalr	-1512(ra) # 8000650e <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80005afe:	00022497          	auipc	s1,0x22
    80005b02:	ec248493          	addi	s1,s1,-318 # 800279c0 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    80005b06:	00022917          	auipc	s2,0x22
    80005b0a:	f5290913          	addi	s2,s2,-174 # 80027a58 <cons+0x98>
  while(n > 0){
    80005b0e:	0d305763          	blez	s3,80005bdc <consoleread+0x10c>
    while(cons.r == cons.w){
    80005b12:	0984a783          	lw	a5,152(s1)
    80005b16:	09c4a703          	lw	a4,156(s1)
    80005b1a:	0af71c63          	bne	a4,a5,80005bd2 <consoleread+0x102>
      if(killed(myproc())){
    80005b1e:	ffffb097          	auipc	ra,0xffffb
    80005b22:	3e8080e7          	jalr	1000(ra) # 80000f06 <myproc>
    80005b26:	ffffc097          	auipc	ra,0xffffc
    80005b2a:	d88080e7          	jalr	-632(ra) # 800018ae <killed>
    80005b2e:	e52d                	bnez	a0,80005b98 <consoleread+0xc8>
      sleep(&cons.r, &cons.lock);
    80005b30:	85a6                	mv	a1,s1
    80005b32:	854a                	mv	a0,s2
    80005b34:	ffffc097          	auipc	ra,0xffffc
    80005b38:	ad2080e7          	jalr	-1326(ra) # 80001606 <sleep>
    while(cons.r == cons.w){
    80005b3c:	0984a783          	lw	a5,152(s1)
    80005b40:	09c4a703          	lw	a4,156(s1)
    80005b44:	fcf70de3          	beq	a4,a5,80005b1e <consoleread+0x4e>
    80005b48:	ec5e                	sd	s7,24(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    80005b4a:	00022717          	auipc	a4,0x22
    80005b4e:	e7670713          	addi	a4,a4,-394 # 800279c0 <cons>
    80005b52:	0017869b          	addiw	a3,a5,1
    80005b56:	08d72c23          	sw	a3,152(a4)
    80005b5a:	07f7f693          	andi	a3,a5,127
    80005b5e:	9736                	add	a4,a4,a3
    80005b60:	01874703          	lbu	a4,24(a4)
    80005b64:	00070b9b          	sext.w	s7,a4

    if(c == C('D')){  // end-of-file
    80005b68:	4691                	li	a3,4
    80005b6a:	04db8a63          	beq	s7,a3,80005bbe <consoleread+0xee>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    80005b6e:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80005b72:	4685                	li	a3,1
    80005b74:	faf40613          	addi	a2,s0,-81
    80005b78:	85d2                	mv	a1,s4
    80005b7a:	8556                	mv	a0,s5
    80005b7c:	ffffc097          	auipc	ra,0xffffc
    80005b80:	e92080e7          	jalr	-366(ra) # 80001a0e <either_copyout>
    80005b84:	57fd                	li	a5,-1
    80005b86:	04f50a63          	beq	a0,a5,80005bda <consoleread+0x10a>
      break;

    dst++;
    80005b8a:	0a05                	addi	s4,s4,1
    --n;
    80005b8c:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    80005b8e:	47a9                	li	a5,10
    80005b90:	06fb8163          	beq	s7,a5,80005bf2 <consoleread+0x122>
    80005b94:	6be2                	ld	s7,24(sp)
    80005b96:	bfa5                	j	80005b0e <consoleread+0x3e>
        release(&cons.lock);
    80005b98:	00022517          	auipc	a0,0x22
    80005b9c:	e2850513          	addi	a0,a0,-472 # 800279c0 <cons>
    80005ba0:	00001097          	auipc	ra,0x1
    80005ba4:	a22080e7          	jalr	-1502(ra) # 800065c2 <release>
        return -1;
    80005ba8:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80005baa:	60e6                	ld	ra,88(sp)
    80005bac:	6446                	ld	s0,80(sp)
    80005bae:	64a6                	ld	s1,72(sp)
    80005bb0:	6906                	ld	s2,64(sp)
    80005bb2:	79e2                	ld	s3,56(sp)
    80005bb4:	7a42                	ld	s4,48(sp)
    80005bb6:	7aa2                	ld	s5,40(sp)
    80005bb8:	7b02                	ld	s6,32(sp)
    80005bba:	6125                	addi	sp,sp,96
    80005bbc:	8082                	ret
      if(n < target){
    80005bbe:	0009871b          	sext.w	a4,s3
    80005bc2:	01677a63          	bgeu	a4,s6,80005bd6 <consoleread+0x106>
        cons.r--;
    80005bc6:	00022717          	auipc	a4,0x22
    80005bca:	e8f72923          	sw	a5,-366(a4) # 80027a58 <cons+0x98>
    80005bce:	6be2                	ld	s7,24(sp)
    80005bd0:	a031                	j	80005bdc <consoleread+0x10c>
    80005bd2:	ec5e                	sd	s7,24(sp)
    80005bd4:	bf9d                	j	80005b4a <consoleread+0x7a>
    80005bd6:	6be2                	ld	s7,24(sp)
    80005bd8:	a011                	j	80005bdc <consoleread+0x10c>
    80005bda:	6be2                	ld	s7,24(sp)
  release(&cons.lock);
    80005bdc:	00022517          	auipc	a0,0x22
    80005be0:	de450513          	addi	a0,a0,-540 # 800279c0 <cons>
    80005be4:	00001097          	auipc	ra,0x1
    80005be8:	9de080e7          	jalr	-1570(ra) # 800065c2 <release>
  return target - n;
    80005bec:	413b053b          	subw	a0,s6,s3
    80005bf0:	bf6d                	j	80005baa <consoleread+0xda>
    80005bf2:	6be2                	ld	s7,24(sp)
    80005bf4:	b7e5                	j	80005bdc <consoleread+0x10c>

0000000080005bf6 <consputc>:
{
    80005bf6:	1141                	addi	sp,sp,-16
    80005bf8:	e406                	sd	ra,8(sp)
    80005bfa:	e022                	sd	s0,0(sp)
    80005bfc:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80005bfe:	10000793          	li	a5,256
    80005c02:	00f50a63          	beq	a0,a5,80005c16 <consputc+0x20>
    uartputc_sync(c);
    80005c06:	00000097          	auipc	ra,0x0
    80005c0a:	66e080e7          	jalr	1646(ra) # 80006274 <uartputc_sync>
}
    80005c0e:	60a2                	ld	ra,8(sp)
    80005c10:	6402                	ld	s0,0(sp)
    80005c12:	0141                	addi	sp,sp,16
    80005c14:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80005c16:	4521                	li	a0,8
    80005c18:	00000097          	auipc	ra,0x0
    80005c1c:	65c080e7          	jalr	1628(ra) # 80006274 <uartputc_sync>
    80005c20:	02000513          	li	a0,32
    80005c24:	00000097          	auipc	ra,0x0
    80005c28:	650080e7          	jalr	1616(ra) # 80006274 <uartputc_sync>
    80005c2c:	4521                	li	a0,8
    80005c2e:	00000097          	auipc	ra,0x0
    80005c32:	646080e7          	jalr	1606(ra) # 80006274 <uartputc_sync>
    80005c36:	bfe1                	j	80005c0e <consputc+0x18>

0000000080005c38 <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    80005c38:	1101                	addi	sp,sp,-32
    80005c3a:	ec06                	sd	ra,24(sp)
    80005c3c:	e822                	sd	s0,16(sp)
    80005c3e:	e426                	sd	s1,8(sp)
    80005c40:	1000                	addi	s0,sp,32
    80005c42:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    80005c44:	00022517          	auipc	a0,0x22
    80005c48:	d7c50513          	addi	a0,a0,-644 # 800279c0 <cons>
    80005c4c:	00001097          	auipc	ra,0x1
    80005c50:	8c2080e7          	jalr	-1854(ra) # 8000650e <acquire>

  switch(c){
    80005c54:	47d5                	li	a5,21
    80005c56:	0af48563          	beq	s1,a5,80005d00 <consoleintr+0xc8>
    80005c5a:	0297c963          	blt	a5,s1,80005c8c <consoleintr+0x54>
    80005c5e:	47a1                	li	a5,8
    80005c60:	0ef48c63          	beq	s1,a5,80005d58 <consoleintr+0x120>
    80005c64:	47c1                	li	a5,16
    80005c66:	10f49f63          	bne	s1,a5,80005d84 <consoleintr+0x14c>
  case C('P'):  // Print process list.
    procdump();
    80005c6a:	ffffc097          	auipc	ra,0xffffc
    80005c6e:	e50080e7          	jalr	-432(ra) # 80001aba <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    80005c72:	00022517          	auipc	a0,0x22
    80005c76:	d4e50513          	addi	a0,a0,-690 # 800279c0 <cons>
    80005c7a:	00001097          	auipc	ra,0x1
    80005c7e:	948080e7          	jalr	-1720(ra) # 800065c2 <release>
}
    80005c82:	60e2                	ld	ra,24(sp)
    80005c84:	6442                	ld	s0,16(sp)
    80005c86:	64a2                	ld	s1,8(sp)
    80005c88:	6105                	addi	sp,sp,32
    80005c8a:	8082                	ret
  switch(c){
    80005c8c:	07f00793          	li	a5,127
    80005c90:	0cf48463          	beq	s1,a5,80005d58 <consoleintr+0x120>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80005c94:	00022717          	auipc	a4,0x22
    80005c98:	d2c70713          	addi	a4,a4,-724 # 800279c0 <cons>
    80005c9c:	0a072783          	lw	a5,160(a4)
    80005ca0:	09872703          	lw	a4,152(a4)
    80005ca4:	9f99                	subw	a5,a5,a4
    80005ca6:	07f00713          	li	a4,127
    80005caa:	fcf764e3          	bltu	a4,a5,80005c72 <consoleintr+0x3a>
      c = (c == '\r') ? '\n' : c;
    80005cae:	47b5                	li	a5,13
    80005cb0:	0cf48d63          	beq	s1,a5,80005d8a <consoleintr+0x152>
      consputc(c);
    80005cb4:	8526                	mv	a0,s1
    80005cb6:	00000097          	auipc	ra,0x0
    80005cba:	f40080e7          	jalr	-192(ra) # 80005bf6 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80005cbe:	00022797          	auipc	a5,0x22
    80005cc2:	d0278793          	addi	a5,a5,-766 # 800279c0 <cons>
    80005cc6:	0a07a683          	lw	a3,160(a5)
    80005cca:	0016871b          	addiw	a4,a3,1
    80005cce:	0007061b          	sext.w	a2,a4
    80005cd2:	0ae7a023          	sw	a4,160(a5)
    80005cd6:	07f6f693          	andi	a3,a3,127
    80005cda:	97b6                	add	a5,a5,a3
    80005cdc:	00978c23          	sb	s1,24(a5)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80005ce0:	47a9                	li	a5,10
    80005ce2:	0cf48b63          	beq	s1,a5,80005db8 <consoleintr+0x180>
    80005ce6:	4791                	li	a5,4
    80005ce8:	0cf48863          	beq	s1,a5,80005db8 <consoleintr+0x180>
    80005cec:	00022797          	auipc	a5,0x22
    80005cf0:	d6c7a783          	lw	a5,-660(a5) # 80027a58 <cons+0x98>
    80005cf4:	9f1d                	subw	a4,a4,a5
    80005cf6:	08000793          	li	a5,128
    80005cfa:	f6f71ce3          	bne	a4,a5,80005c72 <consoleintr+0x3a>
    80005cfe:	a86d                	j	80005db8 <consoleintr+0x180>
    80005d00:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    80005d02:	00022717          	auipc	a4,0x22
    80005d06:	cbe70713          	addi	a4,a4,-834 # 800279c0 <cons>
    80005d0a:	0a072783          	lw	a5,160(a4)
    80005d0e:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80005d12:	00022497          	auipc	s1,0x22
    80005d16:	cae48493          	addi	s1,s1,-850 # 800279c0 <cons>
    while(cons.e != cons.w &&
    80005d1a:	4929                	li	s2,10
    80005d1c:	02f70a63          	beq	a4,a5,80005d50 <consoleintr+0x118>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80005d20:	37fd                	addiw	a5,a5,-1
    80005d22:	07f7f713          	andi	a4,a5,127
    80005d26:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    80005d28:	01874703          	lbu	a4,24(a4)
    80005d2c:	03270463          	beq	a4,s2,80005d54 <consoleintr+0x11c>
      cons.e--;
    80005d30:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80005d34:	10000513          	li	a0,256
    80005d38:	00000097          	auipc	ra,0x0
    80005d3c:	ebe080e7          	jalr	-322(ra) # 80005bf6 <consputc>
    while(cons.e != cons.w &&
    80005d40:	0a04a783          	lw	a5,160(s1)
    80005d44:	09c4a703          	lw	a4,156(s1)
    80005d48:	fcf71ce3          	bne	a4,a5,80005d20 <consoleintr+0xe8>
    80005d4c:	6902                	ld	s2,0(sp)
    80005d4e:	b715                	j	80005c72 <consoleintr+0x3a>
    80005d50:	6902                	ld	s2,0(sp)
    80005d52:	b705                	j	80005c72 <consoleintr+0x3a>
    80005d54:	6902                	ld	s2,0(sp)
    80005d56:	bf31                	j	80005c72 <consoleintr+0x3a>
    if(cons.e != cons.w){
    80005d58:	00022717          	auipc	a4,0x22
    80005d5c:	c6870713          	addi	a4,a4,-920 # 800279c0 <cons>
    80005d60:	0a072783          	lw	a5,160(a4)
    80005d64:	09c72703          	lw	a4,156(a4)
    80005d68:	f0f705e3          	beq	a4,a5,80005c72 <consoleintr+0x3a>
      cons.e--;
    80005d6c:	37fd                	addiw	a5,a5,-1
    80005d6e:	00022717          	auipc	a4,0x22
    80005d72:	cef72923          	sw	a5,-782(a4) # 80027a60 <cons+0xa0>
      consputc(BACKSPACE);
    80005d76:	10000513          	li	a0,256
    80005d7a:	00000097          	auipc	ra,0x0
    80005d7e:	e7c080e7          	jalr	-388(ra) # 80005bf6 <consputc>
    80005d82:	bdc5                	j	80005c72 <consoleintr+0x3a>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80005d84:	ee0487e3          	beqz	s1,80005c72 <consoleintr+0x3a>
    80005d88:	b731                	j	80005c94 <consoleintr+0x5c>
      consputc(c);
    80005d8a:	4529                	li	a0,10
    80005d8c:	00000097          	auipc	ra,0x0
    80005d90:	e6a080e7          	jalr	-406(ra) # 80005bf6 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80005d94:	00022797          	auipc	a5,0x22
    80005d98:	c2c78793          	addi	a5,a5,-980 # 800279c0 <cons>
    80005d9c:	0a07a703          	lw	a4,160(a5)
    80005da0:	0017069b          	addiw	a3,a4,1
    80005da4:	0006861b          	sext.w	a2,a3
    80005da8:	0ad7a023          	sw	a3,160(a5)
    80005dac:	07f77713          	andi	a4,a4,127
    80005db0:	97ba                	add	a5,a5,a4
    80005db2:	4729                	li	a4,10
    80005db4:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    80005db8:	00022797          	auipc	a5,0x22
    80005dbc:	cac7a223          	sw	a2,-860(a5) # 80027a5c <cons+0x9c>
        wakeup(&cons.r);
    80005dc0:	00022517          	auipc	a0,0x22
    80005dc4:	c9850513          	addi	a0,a0,-872 # 80027a58 <cons+0x98>
    80005dc8:	ffffc097          	auipc	ra,0xffffc
    80005dcc:	8a2080e7          	jalr	-1886(ra) # 8000166a <wakeup>
    80005dd0:	b54d                	j	80005c72 <consoleintr+0x3a>

0000000080005dd2 <consoleinit>:

void
consoleinit(void)
{
    80005dd2:	1141                	addi	sp,sp,-16
    80005dd4:	e406                	sd	ra,8(sp)
    80005dd6:	e022                	sd	s0,0(sp)
    80005dd8:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80005dda:	00003597          	auipc	a1,0x3
    80005dde:	92e58593          	addi	a1,a1,-1746 # 80008708 <etext+0x708>
    80005de2:	00022517          	auipc	a0,0x22
    80005de6:	bde50513          	addi	a0,a0,-1058 # 800279c0 <cons>
    80005dea:	00000097          	auipc	ra,0x0
    80005dee:	694080e7          	jalr	1684(ra) # 8000647e <initlock>

  uartinit();
    80005df2:	00000097          	auipc	ra,0x0
    80005df6:	426080e7          	jalr	1062(ra) # 80006218 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80005dfa:	00019797          	auipc	a5,0x19
    80005dfe:	8ee78793          	addi	a5,a5,-1810 # 8001e6e8 <devsw>
    80005e02:	00000717          	auipc	a4,0x0
    80005e06:	cce70713          	addi	a4,a4,-818 # 80005ad0 <consoleread>
    80005e0a:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80005e0c:	00000717          	auipc	a4,0x0
    80005e10:	c5670713          	addi	a4,a4,-938 # 80005a62 <consolewrite>
    80005e14:	ef98                	sd	a4,24(a5)
}
    80005e16:	60a2                	ld	ra,8(sp)
    80005e18:	6402                	ld	s0,0(sp)
    80005e1a:	0141                	addi	sp,sp,16
    80005e1c:	8082                	ret

0000000080005e1e <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(int xx, int base, int sign)
{
    80005e1e:	7179                	addi	sp,sp,-48
    80005e20:	f406                	sd	ra,40(sp)
    80005e22:	f022                	sd	s0,32(sp)
    80005e24:	1800                	addi	s0,sp,48
  char buf[16];
  int i;
  uint x;

  if(sign && (sign = xx < 0))
    80005e26:	c219                	beqz	a2,80005e2c <printint+0xe>
    80005e28:	08054963          	bltz	a0,80005eba <printint+0x9c>
    x = -xx;
  else
    x = xx;
    80005e2c:	2501                	sext.w	a0,a0
    80005e2e:	4881                	li	a7,0
    80005e30:	fd040693          	addi	a3,s0,-48

  i = 0;
    80005e34:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    80005e36:	2581                	sext.w	a1,a1
    80005e38:	00004617          	auipc	a2,0x4
    80005e3c:	33060613          	addi	a2,a2,816 # 8000a168 <digits>
    80005e40:	883a                	mv	a6,a4
    80005e42:	2705                	addiw	a4,a4,1
    80005e44:	02b577bb          	remuw	a5,a0,a1
    80005e48:	1782                	slli	a5,a5,0x20
    80005e4a:	9381                	srli	a5,a5,0x20
    80005e4c:	97b2                	add	a5,a5,a2
    80005e4e:	0007c783          	lbu	a5,0(a5)
    80005e52:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    80005e56:	0005079b          	sext.w	a5,a0
    80005e5a:	02b5553b          	divuw	a0,a0,a1
    80005e5e:	0685                	addi	a3,a3,1
    80005e60:	feb7f0e3          	bgeu	a5,a1,80005e40 <printint+0x22>

  if(sign)
    80005e64:	00088c63          	beqz	a7,80005e7c <printint+0x5e>
    buf[i++] = '-';
    80005e68:	fe070793          	addi	a5,a4,-32
    80005e6c:	00878733          	add	a4,a5,s0
    80005e70:	02d00793          	li	a5,45
    80005e74:	fef70823          	sb	a5,-16(a4)
    80005e78:	0028071b          	addiw	a4,a6,2

  while(--i >= 0)
    80005e7c:	02e05b63          	blez	a4,80005eb2 <printint+0x94>
    80005e80:	ec26                	sd	s1,24(sp)
    80005e82:	e84a                	sd	s2,16(sp)
    80005e84:	fd040793          	addi	a5,s0,-48
    80005e88:	00e784b3          	add	s1,a5,a4
    80005e8c:	fff78913          	addi	s2,a5,-1
    80005e90:	993a                	add	s2,s2,a4
    80005e92:	377d                	addiw	a4,a4,-1
    80005e94:	1702                	slli	a4,a4,0x20
    80005e96:	9301                	srli	a4,a4,0x20
    80005e98:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    80005e9c:	fff4c503          	lbu	a0,-1(s1)
    80005ea0:	00000097          	auipc	ra,0x0
    80005ea4:	d56080e7          	jalr	-682(ra) # 80005bf6 <consputc>
  while(--i >= 0)
    80005ea8:	14fd                	addi	s1,s1,-1
    80005eaa:	ff2499e3          	bne	s1,s2,80005e9c <printint+0x7e>
    80005eae:	64e2                	ld	s1,24(sp)
    80005eb0:	6942                	ld	s2,16(sp)
}
    80005eb2:	70a2                	ld	ra,40(sp)
    80005eb4:	7402                	ld	s0,32(sp)
    80005eb6:	6145                	addi	sp,sp,48
    80005eb8:	8082                	ret
    x = -xx;
    80005eba:	40a0053b          	negw	a0,a0
  if(sign && (sign = xx < 0))
    80005ebe:	4885                	li	a7,1
    x = -xx;
    80005ec0:	bf85                	j	80005e30 <printint+0x12>
    ;
}

int __attribute__((weak))
lookup_symbol(uint64 addr, char *func_out, char *fileline_out)
{
    80005ec2:	1141                	addi	sp,sp,-16
    80005ec4:	e422                	sd	s0,8(sp)
    80005ec6:	0800                	addi	s0,sp,16
  (void)addr; (void)func_out; (void)fileline_out;
  return -1;
}
    80005ec8:	557d                	li	a0,-1
    80005eca:	6422                	ld	s0,8(sp)
    80005ecc:	0141                	addi	sp,sp,16
    80005ece:	8082                	ret

0000000080005ed0 <backtrace>:

void
backtrace(void)
{
    80005ed0:	7131                	addi	sp,sp,-192
    80005ed2:	fd06                	sd	ra,184(sp)
    80005ed4:	f922                	sd	s0,176(sp)
    80005ed6:	f526                	sd	s1,168(sp)
    80005ed8:	ed4e                	sd	s3,152(sp)
    80005eda:	e952                	sd	s4,144(sp)
    80005edc:	0180                	addi	s0,sp,192

static inline uint64
r_fp()
{
  uint64 x;
  asm volatile("mv %0, s0" : "=r" (x));
    80005ede:	84a2                	mv	s1,s0
  uint64 fp = r_fp();
  uint64 stack_bottom = PGROUNDDOWN(fp);  // đáy của kernel stack page
    80005ee0:	79fd                	lui	s3,0xfffff
    80005ee2:	0134f9b3          	and	s3,s1,s3

  printf("backtrace:\n");
    80005ee6:	00003517          	auipc	a0,0x3
    80005eea:	82a50513          	addi	a0,a0,-2006 # 80008710 <etext+0x710>
    80005eee:	00000097          	auipc	ra,0x0
    80005ef2:	0f0080e7          	jalr	240(ra) # 80005fde <printf>

  while (fp >= stack_bottom + 16 && fp < stack_bottom + PGSIZE) {
    80005ef6:	01098a13          	addi	s4,s3,16 # fffffffffffff010 <end+0xffffffff7ffd7550>
    80005efa:	0744ee63          	bltu	s1,s4,80005f76 <backtrace+0xa6>
    80005efe:	6785                	lui	a5,0x1
    80005f00:	99be                	add	s3,s3,a5
    80005f02:	0734fa63          	bgeu	s1,s3,80005f76 <backtrace+0xa6>
    80005f06:	f14a                	sd	s2,160(sp)
    80005f08:	e556                	sd	s5,136(sp)
    80005f0a:	e15a                	sd	s6,128(sp)

    char func[64], fileline[64];
    if (lookup_symbol(ra, func, fileline) == 0)
      printf("%s (%s)\n", func, fileline);
    else
      printf("%p\n", ra);
    80005f0c:	00003b17          	auipc	s6,0x3
    80005f10:	824b0b13          	addi	s6,s6,-2012 # 80008730 <etext+0x730>
      printf("%s (%s)\n", func, fileline);
    80005f14:	00003a97          	auipc	s5,0x3
    80005f18:	80ca8a93          	addi	s5,s5,-2036 # 80008720 <etext+0x720>
    80005f1c:	a005                	j	80005f3c <backtrace+0x6c>
      printf("%p\n", ra);
    80005f1e:	85ca                	mv	a1,s2
    80005f20:	855a                	mv	a0,s6
    80005f22:	00000097          	auipc	ra,0x0
    80005f26:	0bc080e7          	jalr	188(ra) # 80005fde <printf>

    uint64 prev_fp = *(uint64*)(fp - 16);  // saved fp
    80005f2a:	ff04b783          	ld	a5,-16(s1)
    if (prev_fp <= fp || prev_fp >= stack_bottom + PGSIZE)
    80005f2e:	04f4f163          	bgeu	s1,a5,80005f70 <backtrace+0xa0>
    80005f32:	0537f963          	bgeu	a5,s3,80005f84 <backtrace+0xb4>
  while (fp >= stack_bottom + 16 && fp < stack_bottom + PGSIZE) {
    80005f36:	0347e963          	bltu	a5,s4,80005f68 <backtrace+0x98>
    80005f3a:	84be                	mv	s1,a5
    uint64 ra = *(uint64*)(fp - 8);        // return address
    80005f3c:	ff84b903          	ld	s2,-8(s1)
    if (lookup_symbol(ra, func, fileline) == 0)
    80005f40:	f8040613          	addi	a2,s0,-128
    80005f44:	f4040593          	addi	a1,s0,-192
    80005f48:	854a                	mv	a0,s2
    80005f4a:	00000097          	auipc	ra,0x0
    80005f4e:	6c0080e7          	jalr	1728(ra) # 8000660a <lookup_symbol>
    80005f52:	f571                	bnez	a0,80005f1e <backtrace+0x4e>
      printf("%s (%s)\n", func, fileline);
    80005f54:	f8040613          	addi	a2,s0,-128
    80005f58:	f4040593          	addi	a1,s0,-192
    80005f5c:	8556                	mv	a0,s5
    80005f5e:	00000097          	auipc	ra,0x0
    80005f62:	080080e7          	jalr	128(ra) # 80005fde <printf>
    80005f66:	b7d1                	j	80005f2a <backtrace+0x5a>
    80005f68:	790a                	ld	s2,160(sp)
    80005f6a:	6aaa                	ld	s5,136(sp)
    80005f6c:	6b0a                	ld	s6,128(sp)
    80005f6e:	a021                	j	80005f76 <backtrace+0xa6>
    80005f70:	790a                	ld	s2,160(sp)
    80005f72:	6aaa                	ld	s5,136(sp)
    80005f74:	6b0a                	ld	s6,128(sp)
      break;
    fp = prev_fp;
  }
}
    80005f76:	70ea                	ld	ra,184(sp)
    80005f78:	744a                	ld	s0,176(sp)
    80005f7a:	74aa                	ld	s1,168(sp)
    80005f7c:	69ea                	ld	s3,152(sp)
    80005f7e:	6a4a                	ld	s4,144(sp)
    80005f80:	6129                	addi	sp,sp,192
    80005f82:	8082                	ret
    80005f84:	790a                	ld	s2,160(sp)
    80005f86:	6aaa                	ld	s5,136(sp)
    80005f88:	6b0a                	ld	s6,128(sp)
    80005f8a:	b7f5                	j	80005f76 <backtrace+0xa6>

0000000080005f8c <panic>:
{
    80005f8c:	1101                	addi	sp,sp,-32
    80005f8e:	ec06                	sd	ra,24(sp)
    80005f90:	e822                	sd	s0,16(sp)
    80005f92:	e426                	sd	s1,8(sp)
    80005f94:	1000                	addi	s0,sp,32
    80005f96:	84aa                	mv	s1,a0
  pr.locking = 0;
    80005f98:	00022797          	auipc	a5,0x22
    80005f9c:	ae07a423          	sw	zero,-1304(a5) # 80027a80 <pr+0x18>
  backtrace();
    80005fa0:	00000097          	auipc	ra,0x0
    80005fa4:	f30080e7          	jalr	-208(ra) # 80005ed0 <backtrace>
  printf("panic: ");
    80005fa8:	00002517          	auipc	a0,0x2
    80005fac:	79050513          	addi	a0,a0,1936 # 80008738 <etext+0x738>
    80005fb0:	00000097          	auipc	ra,0x0
    80005fb4:	02e080e7          	jalr	46(ra) # 80005fde <printf>
  printf(s);
    80005fb8:	8526                	mv	a0,s1
    80005fba:	00000097          	auipc	ra,0x0
    80005fbe:	024080e7          	jalr	36(ra) # 80005fde <printf>
  printf("\n");
    80005fc2:	00002517          	auipc	a0,0x2
    80005fc6:	05650513          	addi	a0,a0,86 # 80008018 <etext+0x18>
    80005fca:	00000097          	auipc	ra,0x0
    80005fce:	014080e7          	jalr	20(ra) # 80005fde <printf>
  panicked = 1; // freeze uart output from other CPUs
    80005fd2:	4785                	li	a5,1
    80005fd4:	00008717          	auipc	a4,0x8
    80005fd8:	e6f72423          	sw	a5,-408(a4) # 8000de3c <panicked>
  for(;;)
    80005fdc:	a001                	j	80005fdc <panic+0x50>

0000000080005fde <printf>:
{
    80005fde:	7131                	addi	sp,sp,-192
    80005fe0:	fc86                	sd	ra,120(sp)
    80005fe2:	f8a2                	sd	s0,112(sp)
    80005fe4:	e8d2                	sd	s4,80(sp)
    80005fe6:	f06a                	sd	s10,32(sp)
    80005fe8:	0100                	addi	s0,sp,128
    80005fea:	8a2a                	mv	s4,a0
    80005fec:	e40c                	sd	a1,8(s0)
    80005fee:	e810                	sd	a2,16(s0)
    80005ff0:	ec14                	sd	a3,24(s0)
    80005ff2:	f018                	sd	a4,32(s0)
    80005ff4:	f41c                	sd	a5,40(s0)
    80005ff6:	03043823          	sd	a6,48(s0)
    80005ffa:	03143c23          	sd	a7,56(s0)
  locking = pr.locking;
    80005ffe:	00022d17          	auipc	s10,0x22
    80006002:	a82d2d03          	lw	s10,-1406(s10) # 80027a80 <pr+0x18>
  if(locking)
    80006006:	040d1463          	bnez	s10,8000604e <printf+0x70>
  if (fmt == 0)
    8000600a:	040a0b63          	beqz	s4,80006060 <printf+0x82>
  va_start(ap, fmt);
    8000600e:	00840793          	addi	a5,s0,8
    80006012:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
    80006016:	000a4503          	lbu	a0,0(s4)
    8000601a:	18050b63          	beqz	a0,800061b0 <printf+0x1d2>
    8000601e:	f4a6                	sd	s1,104(sp)
    80006020:	f0ca                	sd	s2,96(sp)
    80006022:	ecce                	sd	s3,88(sp)
    80006024:	e4d6                	sd	s5,72(sp)
    80006026:	e0da                	sd	s6,64(sp)
    80006028:	fc5e                	sd	s7,56(sp)
    8000602a:	f862                	sd	s8,48(sp)
    8000602c:	f466                	sd	s9,40(sp)
    8000602e:	ec6e                	sd	s11,24(sp)
    80006030:	4981                	li	s3,0
    if(c != '%'){
    80006032:	02500b13          	li	s6,37
    switch(c){
    80006036:	07000b93          	li	s7,112
  consputc('x');
    8000603a:	4cc1                	li	s9,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    8000603c:	00004a97          	auipc	s5,0x4
    80006040:	12ca8a93          	addi	s5,s5,300 # 8000a168 <digits>
    switch(c){
    80006044:	07300c13          	li	s8,115
    80006048:	06400d93          	li	s11,100
    8000604c:	a0b1                	j	80006098 <printf+0xba>
    acquire(&pr.lock);
    8000604e:	00022517          	auipc	a0,0x22
    80006052:	a1a50513          	addi	a0,a0,-1510 # 80027a68 <pr>
    80006056:	00000097          	auipc	ra,0x0
    8000605a:	4b8080e7          	jalr	1208(ra) # 8000650e <acquire>
    8000605e:	b775                	j	8000600a <printf+0x2c>
    80006060:	f4a6                	sd	s1,104(sp)
    80006062:	f0ca                	sd	s2,96(sp)
    80006064:	ecce                	sd	s3,88(sp)
    80006066:	e4d6                	sd	s5,72(sp)
    80006068:	e0da                	sd	s6,64(sp)
    8000606a:	fc5e                	sd	s7,56(sp)
    8000606c:	f862                	sd	s8,48(sp)
    8000606e:	f466                	sd	s9,40(sp)
    80006070:	ec6e                	sd	s11,24(sp)
    panic("null fmt");
    80006072:	00002517          	auipc	a0,0x2
    80006076:	6d650513          	addi	a0,a0,1750 # 80008748 <etext+0x748>
    8000607a:	00000097          	auipc	ra,0x0
    8000607e:	f12080e7          	jalr	-238(ra) # 80005f8c <panic>
      consputc(c);
    80006082:	00000097          	auipc	ra,0x0
    80006086:	b74080e7          	jalr	-1164(ra) # 80005bf6 <consputc>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
    8000608a:	2985                	addiw	s3,s3,1
    8000608c:	013a07b3          	add	a5,s4,s3
    80006090:	0007c503          	lbu	a0,0(a5)
    80006094:	10050563          	beqz	a0,8000619e <printf+0x1c0>
    if(c != '%'){
    80006098:	ff6515e3          	bne	a0,s6,80006082 <printf+0xa4>
    c = fmt[++i] & 0xff;
    8000609c:	2985                	addiw	s3,s3,1
    8000609e:	013a07b3          	add	a5,s4,s3
    800060a2:	0007c783          	lbu	a5,0(a5)
    800060a6:	0007849b          	sext.w	s1,a5
    if(c == 0)
    800060aa:	10078b63          	beqz	a5,800061c0 <printf+0x1e2>
    switch(c){
    800060ae:	05778a63          	beq	a5,s7,80006102 <printf+0x124>
    800060b2:	02fbf663          	bgeu	s7,a5,800060de <printf+0x100>
    800060b6:	09878863          	beq	a5,s8,80006146 <printf+0x168>
    800060ba:	07800713          	li	a4,120
    800060be:	0ce79563          	bne	a5,a4,80006188 <printf+0x1aa>
      printint(va_arg(ap, int), 16, 1);
    800060c2:	f8843783          	ld	a5,-120(s0)
    800060c6:	00878713          	addi	a4,a5,8
    800060ca:	f8e43423          	sd	a4,-120(s0)
    800060ce:	4605                	li	a2,1
    800060d0:	85e6                	mv	a1,s9
    800060d2:	4388                	lw	a0,0(a5)
    800060d4:	00000097          	auipc	ra,0x0
    800060d8:	d4a080e7          	jalr	-694(ra) # 80005e1e <printint>
      break;
    800060dc:	b77d                	j	8000608a <printf+0xac>
    switch(c){
    800060de:	09678f63          	beq	a5,s6,8000617c <printf+0x19e>
    800060e2:	0bb79363          	bne	a5,s11,80006188 <printf+0x1aa>
      printint(va_arg(ap, int), 10, 1);
    800060e6:	f8843783          	ld	a5,-120(s0)
    800060ea:	00878713          	addi	a4,a5,8
    800060ee:	f8e43423          	sd	a4,-120(s0)
    800060f2:	4605                	li	a2,1
    800060f4:	45a9                	li	a1,10
    800060f6:	4388                	lw	a0,0(a5)
    800060f8:	00000097          	auipc	ra,0x0
    800060fc:	d26080e7          	jalr	-730(ra) # 80005e1e <printint>
      break;
    80006100:	b769                	j	8000608a <printf+0xac>
      printptr(va_arg(ap, uint64));
    80006102:	f8843783          	ld	a5,-120(s0)
    80006106:	00878713          	addi	a4,a5,8
    8000610a:	f8e43423          	sd	a4,-120(s0)
    8000610e:	0007b903          	ld	s2,0(a5)
  consputc('0');
    80006112:	03000513          	li	a0,48
    80006116:	00000097          	auipc	ra,0x0
    8000611a:	ae0080e7          	jalr	-1312(ra) # 80005bf6 <consputc>
  consputc('x');
    8000611e:	07800513          	li	a0,120
    80006122:	00000097          	auipc	ra,0x0
    80006126:	ad4080e7          	jalr	-1324(ra) # 80005bf6 <consputc>
    8000612a:	84e6                	mv	s1,s9
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    8000612c:	03c95793          	srli	a5,s2,0x3c
    80006130:	97d6                	add	a5,a5,s5
    80006132:	0007c503          	lbu	a0,0(a5)
    80006136:	00000097          	auipc	ra,0x0
    8000613a:	ac0080e7          	jalr	-1344(ra) # 80005bf6 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    8000613e:	0912                	slli	s2,s2,0x4
    80006140:	34fd                	addiw	s1,s1,-1
    80006142:	f4ed                	bnez	s1,8000612c <printf+0x14e>
    80006144:	b799                	j	8000608a <printf+0xac>
      if((s = va_arg(ap, char*)) == 0)
    80006146:	f8843783          	ld	a5,-120(s0)
    8000614a:	00878713          	addi	a4,a5,8
    8000614e:	f8e43423          	sd	a4,-120(s0)
    80006152:	6384                	ld	s1,0(a5)
    80006154:	cc89                	beqz	s1,8000616e <printf+0x190>
      for(; *s; s++)
    80006156:	0004c503          	lbu	a0,0(s1)
    8000615a:	d905                	beqz	a0,8000608a <printf+0xac>
        consputc(*s);
    8000615c:	00000097          	auipc	ra,0x0
    80006160:	a9a080e7          	jalr	-1382(ra) # 80005bf6 <consputc>
      for(; *s; s++)
    80006164:	0485                	addi	s1,s1,1
    80006166:	0004c503          	lbu	a0,0(s1)
    8000616a:	f96d                	bnez	a0,8000615c <printf+0x17e>
    8000616c:	bf39                	j	8000608a <printf+0xac>
        s = "(null)";
    8000616e:	00002497          	auipc	s1,0x2
    80006172:	5d248493          	addi	s1,s1,1490 # 80008740 <etext+0x740>
      for(; *s; s++)
    80006176:	02800513          	li	a0,40
    8000617a:	b7cd                	j	8000615c <printf+0x17e>
      consputc('%');
    8000617c:	855a                	mv	a0,s6
    8000617e:	00000097          	auipc	ra,0x0
    80006182:	a78080e7          	jalr	-1416(ra) # 80005bf6 <consputc>
      break;
    80006186:	b711                	j	8000608a <printf+0xac>
      consputc('%');
    80006188:	855a                	mv	a0,s6
    8000618a:	00000097          	auipc	ra,0x0
    8000618e:	a6c080e7          	jalr	-1428(ra) # 80005bf6 <consputc>
      consputc(c);
    80006192:	8526                	mv	a0,s1
    80006194:	00000097          	auipc	ra,0x0
    80006198:	a62080e7          	jalr	-1438(ra) # 80005bf6 <consputc>
      break;
    8000619c:	b5fd                	j	8000608a <printf+0xac>
    8000619e:	74a6                	ld	s1,104(sp)
    800061a0:	7906                	ld	s2,96(sp)
    800061a2:	69e6                	ld	s3,88(sp)
    800061a4:	6aa6                	ld	s5,72(sp)
    800061a6:	6b06                	ld	s6,64(sp)
    800061a8:	7be2                	ld	s7,56(sp)
    800061aa:	7c42                	ld	s8,48(sp)
    800061ac:	7ca2                	ld	s9,40(sp)
    800061ae:	6de2                	ld	s11,24(sp)
  if(locking)
    800061b0:	020d1263          	bnez	s10,800061d4 <printf+0x1f6>
}
    800061b4:	70e6                	ld	ra,120(sp)
    800061b6:	7446                	ld	s0,112(sp)
    800061b8:	6a46                	ld	s4,80(sp)
    800061ba:	7d02                	ld	s10,32(sp)
    800061bc:	6129                	addi	sp,sp,192
    800061be:	8082                	ret
    800061c0:	74a6                	ld	s1,104(sp)
    800061c2:	7906                	ld	s2,96(sp)
    800061c4:	69e6                	ld	s3,88(sp)
    800061c6:	6aa6                	ld	s5,72(sp)
    800061c8:	6b06                	ld	s6,64(sp)
    800061ca:	7be2                	ld	s7,56(sp)
    800061cc:	7c42                	ld	s8,48(sp)
    800061ce:	7ca2                	ld	s9,40(sp)
    800061d0:	6de2                	ld	s11,24(sp)
    800061d2:	bff9                	j	800061b0 <printf+0x1d2>
    release(&pr.lock);
    800061d4:	00022517          	auipc	a0,0x22
    800061d8:	89450513          	addi	a0,a0,-1900 # 80027a68 <pr>
    800061dc:	00000097          	auipc	ra,0x0
    800061e0:	3e6080e7          	jalr	998(ra) # 800065c2 <release>
}
    800061e4:	bfc1                	j	800061b4 <printf+0x1d6>

00000000800061e6 <printfinit>:

void
printfinit(void)
{
    800061e6:	1101                	addi	sp,sp,-32
    800061e8:	ec06                	sd	ra,24(sp)
    800061ea:	e822                	sd	s0,16(sp)
    800061ec:	e426                	sd	s1,8(sp)
    800061ee:	1000                	addi	s0,sp,32
  initlock(&pr.lock, "pr");
    800061f0:	00022497          	auipc	s1,0x22
    800061f4:	87848493          	addi	s1,s1,-1928 # 80027a68 <pr>
    800061f8:	00002597          	auipc	a1,0x2
    800061fc:	56058593          	addi	a1,a1,1376 # 80008758 <etext+0x758>
    80006200:	8526                	mv	a0,s1
    80006202:	00000097          	auipc	ra,0x0
    80006206:	27c080e7          	jalr	636(ra) # 8000647e <initlock>
  pr.locking = 1;
    8000620a:	4785                	li	a5,1
    8000620c:	cc9c                	sw	a5,24(s1)
}
    8000620e:	60e2                	ld	ra,24(sp)
    80006210:	6442                	ld	s0,16(sp)
    80006212:	64a2                	ld	s1,8(sp)
    80006214:	6105                	addi	sp,sp,32
    80006216:	8082                	ret

0000000080006218 <uartinit>:

void uartstart();

void
uartinit(void)
{
    80006218:	1141                	addi	sp,sp,-16
    8000621a:	e406                	sd	ra,8(sp)
    8000621c:	e022                	sd	s0,0(sp)
    8000621e:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80006220:	100007b7          	lui	a5,0x10000
    80006224:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80006228:	10000737          	lui	a4,0x10000
    8000622c:	f8000693          	li	a3,-128
    80006230:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    80006234:	468d                	li	a3,3
    80006236:	10000637          	lui	a2,0x10000
    8000623a:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    8000623e:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    80006242:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    80006246:	10000737          	lui	a4,0x10000
    8000624a:	461d                	li	a2,7
    8000624c:	00c70123          	sb	a2,2(a4) # 10000002 <_entry-0x6ffffffe>

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    80006250:	00d780a3          	sb	a3,1(a5)

  initlock(&uart_tx_lock, "uart");
    80006254:	00002597          	auipc	a1,0x2
    80006258:	50c58593          	addi	a1,a1,1292 # 80008760 <etext+0x760>
    8000625c:	00022517          	auipc	a0,0x22
    80006260:	82c50513          	addi	a0,a0,-2004 # 80027a88 <uart_tx_lock>
    80006264:	00000097          	auipc	ra,0x0
    80006268:	21a080e7          	jalr	538(ra) # 8000647e <initlock>
}
    8000626c:	60a2                	ld	ra,8(sp)
    8000626e:	6402                	ld	s0,0(sp)
    80006270:	0141                	addi	sp,sp,16
    80006272:	8082                	ret

0000000080006274 <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    80006274:	1101                	addi	sp,sp,-32
    80006276:	ec06                	sd	ra,24(sp)
    80006278:	e822                	sd	s0,16(sp)
    8000627a:	e426                	sd	s1,8(sp)
    8000627c:	1000                	addi	s0,sp,32
    8000627e:	84aa                	mv	s1,a0
  push_off();
    80006280:	00000097          	auipc	ra,0x0
    80006284:	242080e7          	jalr	578(ra) # 800064c2 <push_off>

  if(panicked){
    80006288:	00008797          	auipc	a5,0x8
    8000628c:	bb47a783          	lw	a5,-1100(a5) # 8000de3c <panicked>
    80006290:	eb85                	bnez	a5,800062c0 <uartputc_sync+0x4c>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    80006292:	10000737          	lui	a4,0x10000
    80006296:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80006298:	00074783          	lbu	a5,0(a4)
    8000629c:	0207f793          	andi	a5,a5,32
    800062a0:	dfe5                	beqz	a5,80006298 <uartputc_sync+0x24>
    ;
  WriteReg(THR, c);
    800062a2:	0ff4f513          	zext.b	a0,s1
    800062a6:	100007b7          	lui	a5,0x10000
    800062aa:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    800062ae:	00000097          	auipc	ra,0x0
    800062b2:	2b4080e7          	jalr	692(ra) # 80006562 <pop_off>
}
    800062b6:	60e2                	ld	ra,24(sp)
    800062b8:	6442                	ld	s0,16(sp)
    800062ba:	64a2                	ld	s1,8(sp)
    800062bc:	6105                	addi	sp,sp,32
    800062be:	8082                	ret
    for(;;)
    800062c0:	a001                	j	800062c0 <uartputc_sync+0x4c>

00000000800062c2 <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    800062c2:	00008797          	auipc	a5,0x8
    800062c6:	b7e7b783          	ld	a5,-1154(a5) # 8000de40 <uart_tx_r>
    800062ca:	00008717          	auipc	a4,0x8
    800062ce:	b7e73703          	ld	a4,-1154(a4) # 8000de48 <uart_tx_w>
    800062d2:	06f70f63          	beq	a4,a5,80006350 <uartstart+0x8e>
{
    800062d6:	7139                	addi	sp,sp,-64
    800062d8:	fc06                	sd	ra,56(sp)
    800062da:	f822                	sd	s0,48(sp)
    800062dc:	f426                	sd	s1,40(sp)
    800062de:	f04a                	sd	s2,32(sp)
    800062e0:	ec4e                	sd	s3,24(sp)
    800062e2:	e852                	sd	s4,16(sp)
    800062e4:	e456                	sd	s5,8(sp)
    800062e6:	e05a                	sd	s6,0(sp)
    800062e8:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    800062ea:	10000937          	lui	s2,0x10000
    800062ee:	0915                	addi	s2,s2,5 # 10000005 <_entry-0x6ffffffb>
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    800062f0:	00021a97          	auipc	s5,0x21
    800062f4:	798a8a93          	addi	s5,s5,1944 # 80027a88 <uart_tx_lock>
    uart_tx_r += 1;
    800062f8:	00008497          	auipc	s1,0x8
    800062fc:	b4848493          	addi	s1,s1,-1208 # 8000de40 <uart_tx_r>
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    
    WriteReg(THR, c);
    80006300:	10000a37          	lui	s4,0x10000
    if(uart_tx_w == uart_tx_r){
    80006304:	00008997          	auipc	s3,0x8
    80006308:	b4498993          	addi	s3,s3,-1212 # 8000de48 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    8000630c:	00094703          	lbu	a4,0(s2)
    80006310:	02077713          	andi	a4,a4,32
    80006314:	c705                	beqz	a4,8000633c <uartstart+0x7a>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80006316:	01f7f713          	andi	a4,a5,31
    8000631a:	9756                	add	a4,a4,s5
    8000631c:	01874b03          	lbu	s6,24(a4)
    uart_tx_r += 1;
    80006320:	0785                	addi	a5,a5,1
    80006322:	e09c                	sd	a5,0(s1)
    wakeup(&uart_tx_r);
    80006324:	8526                	mv	a0,s1
    80006326:	ffffb097          	auipc	ra,0xffffb
    8000632a:	344080e7          	jalr	836(ra) # 8000166a <wakeup>
    WriteReg(THR, c);
    8000632e:	016a0023          	sb	s6,0(s4) # 10000000 <_entry-0x70000000>
    if(uart_tx_w == uart_tx_r){
    80006332:	609c                	ld	a5,0(s1)
    80006334:	0009b703          	ld	a4,0(s3)
    80006338:	fcf71ae3          	bne	a4,a5,8000630c <uartstart+0x4a>
  }
}
    8000633c:	70e2                	ld	ra,56(sp)
    8000633e:	7442                	ld	s0,48(sp)
    80006340:	74a2                	ld	s1,40(sp)
    80006342:	7902                	ld	s2,32(sp)
    80006344:	69e2                	ld	s3,24(sp)
    80006346:	6a42                	ld	s4,16(sp)
    80006348:	6aa2                	ld	s5,8(sp)
    8000634a:	6b02                	ld	s6,0(sp)
    8000634c:	6121                	addi	sp,sp,64
    8000634e:	8082                	ret
    80006350:	8082                	ret

0000000080006352 <uartputc>:
{
    80006352:	7179                	addi	sp,sp,-48
    80006354:	f406                	sd	ra,40(sp)
    80006356:	f022                	sd	s0,32(sp)
    80006358:	ec26                	sd	s1,24(sp)
    8000635a:	e84a                	sd	s2,16(sp)
    8000635c:	e44e                	sd	s3,8(sp)
    8000635e:	e052                	sd	s4,0(sp)
    80006360:	1800                	addi	s0,sp,48
    80006362:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    80006364:	00021517          	auipc	a0,0x21
    80006368:	72450513          	addi	a0,a0,1828 # 80027a88 <uart_tx_lock>
    8000636c:	00000097          	auipc	ra,0x0
    80006370:	1a2080e7          	jalr	418(ra) # 8000650e <acquire>
  if(panicked){
    80006374:	00008797          	auipc	a5,0x8
    80006378:	ac87a783          	lw	a5,-1336(a5) # 8000de3c <panicked>
    8000637c:	e7c9                	bnez	a5,80006406 <uartputc+0xb4>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    8000637e:	00008717          	auipc	a4,0x8
    80006382:	aca73703          	ld	a4,-1334(a4) # 8000de48 <uart_tx_w>
    80006386:	00008797          	auipc	a5,0x8
    8000638a:	aba7b783          	ld	a5,-1350(a5) # 8000de40 <uart_tx_r>
    8000638e:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    80006392:	00021997          	auipc	s3,0x21
    80006396:	6f698993          	addi	s3,s3,1782 # 80027a88 <uart_tx_lock>
    8000639a:	00008497          	auipc	s1,0x8
    8000639e:	aa648493          	addi	s1,s1,-1370 # 8000de40 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800063a2:	00008917          	auipc	s2,0x8
    800063a6:	aa690913          	addi	s2,s2,-1370 # 8000de48 <uart_tx_w>
    800063aa:	00e79f63          	bne	a5,a4,800063c8 <uartputc+0x76>
    sleep(&uart_tx_r, &uart_tx_lock);
    800063ae:	85ce                	mv	a1,s3
    800063b0:	8526                	mv	a0,s1
    800063b2:	ffffb097          	auipc	ra,0xffffb
    800063b6:	254080e7          	jalr	596(ra) # 80001606 <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800063ba:	00093703          	ld	a4,0(s2)
    800063be:	609c                	ld	a5,0(s1)
    800063c0:	02078793          	addi	a5,a5,32
    800063c4:	fee785e3          	beq	a5,a4,800063ae <uartputc+0x5c>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    800063c8:	00021497          	auipc	s1,0x21
    800063cc:	6c048493          	addi	s1,s1,1728 # 80027a88 <uart_tx_lock>
    800063d0:	01f77793          	andi	a5,a4,31
    800063d4:	97a6                	add	a5,a5,s1
    800063d6:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    800063da:	0705                	addi	a4,a4,1
    800063dc:	00008797          	auipc	a5,0x8
    800063e0:	a6e7b623          	sd	a4,-1428(a5) # 8000de48 <uart_tx_w>
  uartstart();
    800063e4:	00000097          	auipc	ra,0x0
    800063e8:	ede080e7          	jalr	-290(ra) # 800062c2 <uartstart>
  release(&uart_tx_lock);
    800063ec:	8526                	mv	a0,s1
    800063ee:	00000097          	auipc	ra,0x0
    800063f2:	1d4080e7          	jalr	468(ra) # 800065c2 <release>
}
    800063f6:	70a2                	ld	ra,40(sp)
    800063f8:	7402                	ld	s0,32(sp)
    800063fa:	64e2                	ld	s1,24(sp)
    800063fc:	6942                	ld	s2,16(sp)
    800063fe:	69a2                	ld	s3,8(sp)
    80006400:	6a02                	ld	s4,0(sp)
    80006402:	6145                	addi	sp,sp,48
    80006404:	8082                	ret
    for(;;)
    80006406:	a001                	j	80006406 <uartputc+0xb4>

0000000080006408 <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    80006408:	1141                	addi	sp,sp,-16
    8000640a:	e422                	sd	s0,8(sp)
    8000640c:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    8000640e:	100007b7          	lui	a5,0x10000
    80006412:	0795                	addi	a5,a5,5 # 10000005 <_entry-0x6ffffffb>
    80006414:	0007c783          	lbu	a5,0(a5)
    80006418:	8b85                	andi	a5,a5,1
    8000641a:	cb81                	beqz	a5,8000642a <uartgetc+0x22>
    // input data is ready.
    return ReadReg(RHR);
    8000641c:	100007b7          	lui	a5,0x10000
    80006420:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    80006424:	6422                	ld	s0,8(sp)
    80006426:	0141                	addi	sp,sp,16
    80006428:	8082                	ret
    return -1;
    8000642a:	557d                	li	a0,-1
    8000642c:	bfe5                	j	80006424 <uartgetc+0x1c>

000000008000642e <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    8000642e:	1101                	addi	sp,sp,-32
    80006430:	ec06                	sd	ra,24(sp)
    80006432:	e822                	sd	s0,16(sp)
    80006434:	e426                	sd	s1,8(sp)
    80006436:	1000                	addi	s0,sp,32
  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80006438:	54fd                	li	s1,-1
    8000643a:	a029                	j	80006444 <uartintr+0x16>
      break;
    consoleintr(c);
    8000643c:	fffff097          	auipc	ra,0xfffff
    80006440:	7fc080e7          	jalr	2044(ra) # 80005c38 <consoleintr>
    int c = uartgetc();
    80006444:	00000097          	auipc	ra,0x0
    80006448:	fc4080e7          	jalr	-60(ra) # 80006408 <uartgetc>
    if(c == -1)
    8000644c:	fe9518e3          	bne	a0,s1,8000643c <uartintr+0xe>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    80006450:	00021497          	auipc	s1,0x21
    80006454:	63848493          	addi	s1,s1,1592 # 80027a88 <uart_tx_lock>
    80006458:	8526                	mv	a0,s1
    8000645a:	00000097          	auipc	ra,0x0
    8000645e:	0b4080e7          	jalr	180(ra) # 8000650e <acquire>
  uartstart();
    80006462:	00000097          	auipc	ra,0x0
    80006466:	e60080e7          	jalr	-416(ra) # 800062c2 <uartstart>
  release(&uart_tx_lock);
    8000646a:	8526                	mv	a0,s1
    8000646c:	00000097          	auipc	ra,0x0
    80006470:	156080e7          	jalr	342(ra) # 800065c2 <release>
}
    80006474:	60e2                	ld	ra,24(sp)
    80006476:	6442                	ld	s0,16(sp)
    80006478:	64a2                	ld	s1,8(sp)
    8000647a:	6105                	addi	sp,sp,32
    8000647c:	8082                	ret

000000008000647e <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    8000647e:	1141                	addi	sp,sp,-16
    80006480:	e422                	sd	s0,8(sp)
    80006482:	0800                	addi	s0,sp,16
  lk->name = name;
    80006484:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80006486:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    8000648a:	00053823          	sd	zero,16(a0)
}
    8000648e:	6422                	ld	s0,8(sp)
    80006490:	0141                	addi	sp,sp,16
    80006492:	8082                	ret

0000000080006494 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80006494:	411c                	lw	a5,0(a0)
    80006496:	e399                	bnez	a5,8000649c <holding+0x8>
    80006498:	4501                	li	a0,0
  return r;
}
    8000649a:	8082                	ret
{
    8000649c:	1101                	addi	sp,sp,-32
    8000649e:	ec06                	sd	ra,24(sp)
    800064a0:	e822                	sd	s0,16(sp)
    800064a2:	e426                	sd	s1,8(sp)
    800064a4:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    800064a6:	6904                	ld	s1,16(a0)
    800064a8:	ffffb097          	auipc	ra,0xffffb
    800064ac:	a42080e7          	jalr	-1470(ra) # 80000eea <mycpu>
    800064b0:	40a48533          	sub	a0,s1,a0
    800064b4:	00153513          	seqz	a0,a0
}
    800064b8:	60e2                	ld	ra,24(sp)
    800064ba:	6442                	ld	s0,16(sp)
    800064bc:	64a2                	ld	s1,8(sp)
    800064be:	6105                	addi	sp,sp,32
    800064c0:	8082                	ret

00000000800064c2 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    800064c2:	1101                	addi	sp,sp,-32
    800064c4:	ec06                	sd	ra,24(sp)
    800064c6:	e822                	sd	s0,16(sp)
    800064c8:	e426                	sd	s1,8(sp)
    800064ca:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800064cc:	100024f3          	csrr	s1,sstatus
    800064d0:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    800064d4:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800064d6:	10079073          	csrw	sstatus,a5
  int old = intr_get();

  intr_off();
  if(mycpu()->noff == 0)
    800064da:	ffffb097          	auipc	ra,0xffffb
    800064de:	a10080e7          	jalr	-1520(ra) # 80000eea <mycpu>
    800064e2:	5d3c                	lw	a5,120(a0)
    800064e4:	cf89                	beqz	a5,800064fe <push_off+0x3c>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    800064e6:	ffffb097          	auipc	ra,0xffffb
    800064ea:	a04080e7          	jalr	-1532(ra) # 80000eea <mycpu>
    800064ee:	5d3c                	lw	a5,120(a0)
    800064f0:	2785                	addiw	a5,a5,1
    800064f2:	dd3c                	sw	a5,120(a0)
}
    800064f4:	60e2                	ld	ra,24(sp)
    800064f6:	6442                	ld	s0,16(sp)
    800064f8:	64a2                	ld	s1,8(sp)
    800064fa:	6105                	addi	sp,sp,32
    800064fc:	8082                	ret
    mycpu()->intena = old;
    800064fe:	ffffb097          	auipc	ra,0xffffb
    80006502:	9ec080e7          	jalr	-1556(ra) # 80000eea <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80006506:	8085                	srli	s1,s1,0x1
    80006508:	8885                	andi	s1,s1,1
    8000650a:	dd64                	sw	s1,124(a0)
    8000650c:	bfe9                	j	800064e6 <push_off+0x24>

000000008000650e <acquire>:
{
    8000650e:	1101                	addi	sp,sp,-32
    80006510:	ec06                	sd	ra,24(sp)
    80006512:	e822                	sd	s0,16(sp)
    80006514:	e426                	sd	s1,8(sp)
    80006516:	1000                	addi	s0,sp,32
    80006518:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    8000651a:	00000097          	auipc	ra,0x0
    8000651e:	fa8080e7          	jalr	-88(ra) # 800064c2 <push_off>
  if(holding(lk))
    80006522:	8526                	mv	a0,s1
    80006524:	00000097          	auipc	ra,0x0
    80006528:	f70080e7          	jalr	-144(ra) # 80006494 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    8000652c:	4705                	li	a4,1
  if(holding(lk))
    8000652e:	e115                	bnez	a0,80006552 <acquire+0x44>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80006530:	87ba                	mv	a5,a4
    80006532:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80006536:	2781                	sext.w	a5,a5
    80006538:	ffe5                	bnez	a5,80006530 <acquire+0x22>
  __sync_synchronize();
    8000653a:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    8000653e:	ffffb097          	auipc	ra,0xffffb
    80006542:	9ac080e7          	jalr	-1620(ra) # 80000eea <mycpu>
    80006546:	e888                	sd	a0,16(s1)
}
    80006548:	60e2                	ld	ra,24(sp)
    8000654a:	6442                	ld	s0,16(sp)
    8000654c:	64a2                	ld	s1,8(sp)
    8000654e:	6105                	addi	sp,sp,32
    80006550:	8082                	ret
    panic("acquire");
    80006552:	00002517          	auipc	a0,0x2
    80006556:	21650513          	addi	a0,a0,534 # 80008768 <etext+0x768>
    8000655a:	00000097          	auipc	ra,0x0
    8000655e:	a32080e7          	jalr	-1486(ra) # 80005f8c <panic>

0000000080006562 <pop_off>:

void
pop_off(void)
{
    80006562:	1141                	addi	sp,sp,-16
    80006564:	e406                	sd	ra,8(sp)
    80006566:	e022                	sd	s0,0(sp)
    80006568:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    8000656a:	ffffb097          	auipc	ra,0xffffb
    8000656e:	980080e7          	jalr	-1664(ra) # 80000eea <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80006572:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80006576:	8b89                	andi	a5,a5,2
  if(intr_get())
    80006578:	e78d                	bnez	a5,800065a2 <pop_off+0x40>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    8000657a:	5d3c                	lw	a5,120(a0)
    8000657c:	02f05b63          	blez	a5,800065b2 <pop_off+0x50>
    panic("pop_off");
  c->noff -= 1;
    80006580:	37fd                	addiw	a5,a5,-1
    80006582:	0007871b          	sext.w	a4,a5
    80006586:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80006588:	eb09                	bnez	a4,8000659a <pop_off+0x38>
    8000658a:	5d7c                	lw	a5,124(a0)
    8000658c:	c799                	beqz	a5,8000659a <pop_off+0x38>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000658e:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80006592:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80006596:	10079073          	csrw	sstatus,a5
    intr_on();
}
    8000659a:	60a2                	ld	ra,8(sp)
    8000659c:	6402                	ld	s0,0(sp)
    8000659e:	0141                	addi	sp,sp,16
    800065a0:	8082                	ret
    panic("pop_off - interruptible");
    800065a2:	00002517          	auipc	a0,0x2
    800065a6:	1ce50513          	addi	a0,a0,462 # 80008770 <etext+0x770>
    800065aa:	00000097          	auipc	ra,0x0
    800065ae:	9e2080e7          	jalr	-1566(ra) # 80005f8c <panic>
    panic("pop_off");
    800065b2:	00002517          	auipc	a0,0x2
    800065b6:	1d650513          	addi	a0,a0,470 # 80008788 <etext+0x788>
    800065ba:	00000097          	auipc	ra,0x0
    800065be:	9d2080e7          	jalr	-1582(ra) # 80005f8c <panic>

00000000800065c2 <release>:
{
    800065c2:	1101                	addi	sp,sp,-32
    800065c4:	ec06                	sd	ra,24(sp)
    800065c6:	e822                	sd	s0,16(sp)
    800065c8:	e426                	sd	s1,8(sp)
    800065ca:	1000                	addi	s0,sp,32
    800065cc:	84aa                	mv	s1,a0
  if(!holding(lk))
    800065ce:	00000097          	auipc	ra,0x0
    800065d2:	ec6080e7          	jalr	-314(ra) # 80006494 <holding>
    800065d6:	c115                	beqz	a0,800065fa <release+0x38>
  lk->cpu = 0;
    800065d8:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    800065dc:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    800065e0:	0310000f          	fence	rw,w
    800065e4:	0004a023          	sw	zero,0(s1)
  pop_off();
    800065e8:	00000097          	auipc	ra,0x0
    800065ec:	f7a080e7          	jalr	-134(ra) # 80006562 <pop_off>
}
    800065f0:	60e2                	ld	ra,24(sp)
    800065f2:	6442                	ld	s0,16(sp)
    800065f4:	64a2                	ld	s1,8(sp)
    800065f6:	6105                	addi	sp,sp,32
    800065f8:	8082                	ret
    panic("release");
    800065fa:	00002517          	auipc	a0,0x2
    800065fe:	19650513          	addi	a0,a0,406 # 80008790 <etext+0x790>
    80006602:	00000097          	auipc	ra,0x0
    80006606:	98a080e7          	jalr	-1654(ra) # 80005f8c <panic>

000000008000660a <lookup_symbol>:

int nsyminfos = sizeof(syminfos) / sizeof(syminfos[0]);

int
lookup_symbol(uint64 addr, char *func_out, char *fileline_out)
{
    8000660a:	1141                	addi	sp,sp,-16
    8000660c:	e422                	sd	s0,8(sp)
    8000660e:	0800                	addi	s0,sp,16
  int lo = 0, hi = nsyminfos - 1;
    80006610:	00007817          	auipc	a6,0x7
    80006614:	7a882803          	lw	a6,1960(a6) # 8000ddb8 <nsyminfos>
    80006618:	387d                	addiw	a6,a6,-1
  int best = -1;

  while (lo <= hi) {
    8000661a:	0a084e63          	bltz	a6,800066d6 <lookup_symbol+0xcc>
  int best = -1;
    8000661e:	537d                	li	t1,-1
  int lo = 0, hi = nsyminfos - 1;
    80006620:	4881                	li	a7,0
    int mid = (lo + hi) / 2;
    if (syminfos[mid].addr <= addr) {
    80006622:	00004e17          	auipc	t3,0x4
    80006626:	b5ee0e13          	addi	t3,t3,-1186 # 8000a180 <syminfos>
    8000662a:	a029                	j	80006634 <lookup_symbol+0x2a>
      best = mid;
      lo = mid + 1;
    } else {
      hi = mid - 1;
    8000662c:	fff7081b          	addiw	a6,a4,-1
  while (lo <= hi) {
    80006630:	03184763          	blt	a6,a7,8000665e <lookup_symbol+0x54>
    int mid = (lo + hi) / 2;
    80006634:	010887bb          	addw	a5,a7,a6
    80006638:	01f7d71b          	srliw	a4,a5,0x1f
    8000663c:	9f3d                	addw	a4,a4,a5
    8000663e:	4017571b          	sraiw	a4,a4,0x1
    80006642:	0007069b          	sext.w	a3,a4
    if (syminfos[mid].addr <= addr) {
    80006646:	00169793          	slli	a5,a3,0x1
    8000664a:	97b6                	add	a5,a5,a3
    8000664c:	078e                	slli	a5,a5,0x3
    8000664e:	97f2                	add	a5,a5,t3
    80006650:	639c                	ld	a5,0(a5)
    80006652:	fcf56de3          	bltu	a0,a5,8000662c <lookup_symbol+0x22>
      lo = mid + 1;
    80006656:	0017089b          	addiw	a7,a4,1
      best = mid;
    8000665a:	8336                	mv	t1,a3
    8000665c:	bfd1                	j	80006630 <lookup_symbol+0x26>
    }
  }

  if (best < 0)
    8000665e:	06034e63          	bltz	t1,800066da <lookup_symbol+0xd0>
    return -1;

  { char *src; int i;
    for (src = syminfos[best].func, i = 0; i < 63 && *src; i++) func_out[i] = *src++;
    80006662:	00131793          	slli	a5,t1,0x1
    80006666:	979a                	add	a5,a5,t1
    80006668:	078e                	slli	a5,a5,0x3
    8000666a:	00004717          	auipc	a4,0x4
    8000666e:	b1670713          	addi	a4,a4,-1258 # 8000a180 <syminfos>
    80006672:	97ba                	add	a5,a5,a4
    80006674:	6798                	ld	a4,8(a5)
    80006676:	852e                	mv	a0,a1
    80006678:	4781                	li	a5,0
    8000667a:	03f00813          	li	a6,63
    8000667e:	00074683          	lbu	a3,0(a4)
    80006682:	ca81                	beqz	a3,80006692 <lookup_symbol+0x88>
    80006684:	0705                	addi	a4,a4,1
    80006686:	00d50023          	sb	a3,0(a0)
    8000668a:	2785                	addiw	a5,a5,1
    8000668c:	0505                	addi	a0,a0,1
    8000668e:	ff0798e3          	bne	a5,a6,8000667e <lookup_symbol+0x74>
    func_out[i] = 0; }
    80006692:	95be                	add	a1,a1,a5
    80006694:	00058023          	sb	zero,0(a1)
  { char *src; int i;
    for (src = syminfos[best].fileline, i = 0; i < 63 && *src; i++) fileline_out[i] = *src++;
    80006698:	00131793          	slli	a5,t1,0x1
    8000669c:	979a                	add	a5,a5,t1
    8000669e:	078e                	slli	a5,a5,0x3
    800066a0:	00004717          	auipc	a4,0x4
    800066a4:	ae070713          	addi	a4,a4,-1312 # 8000a180 <syminfos>
    800066a8:	97ba                	add	a5,a5,a4
    800066aa:	6b98                	ld	a4,16(a5)
    800066ac:	85b2                	mv	a1,a2
    800066ae:	4781                	li	a5,0
    800066b0:	03f00513          	li	a0,63
    800066b4:	00074683          	lbu	a3,0(a4)
    800066b8:	ca81                	beqz	a3,800066c8 <lookup_symbol+0xbe>
    800066ba:	0705                	addi	a4,a4,1
    800066bc:	00d58023          	sb	a3,0(a1)
    800066c0:	2785                	addiw	a5,a5,1
    800066c2:	0585                	addi	a1,a1,1
    800066c4:	fea798e3          	bne	a5,a0,800066b4 <lookup_symbol+0xaa>
    fileline_out[i] = 0; }
    800066c8:	963e                	add	a2,a2,a5
    800066ca:	00060023          	sb	zero,0(a2)
  return 0;
    800066ce:	4501                	li	a0,0
}
    800066d0:	6422                	ld	s0,8(sp)
    800066d2:	0141                	addi	sp,sp,16
    800066d4:	8082                	ret
    return -1;
    800066d6:	557d                	li	a0,-1
    800066d8:	bfe5                	j	800066d0 <lookup_symbol+0xc6>
    800066da:	557d                	li	a0,-1
    800066dc:	bfd5                	j	800066d0 <lookup_symbol+0xc6>
	...

0000000080007000 <_trampoline>:
    80007000:	14051073          	csrw	sscratch,a0
    80007004:	02000537          	lui	a0,0x2000
    80007008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000700a:	0536                	slli	a0,a0,0xd
    8000700c:	02153423          	sd	ra,40(a0)
    80007010:	02253823          	sd	sp,48(a0)
    80007014:	02353c23          	sd	gp,56(a0)
    80007018:	04453023          	sd	tp,64(a0)
    8000701c:	04553423          	sd	t0,72(a0)
    80007020:	04653823          	sd	t1,80(a0)
    80007024:	04753c23          	sd	t2,88(a0)
    80007028:	f120                	sd	s0,96(a0)
    8000702a:	f524                	sd	s1,104(a0)
    8000702c:	fd2c                	sd	a1,120(a0)
    8000702e:	e150                	sd	a2,128(a0)
    80007030:	e554                	sd	a3,136(a0)
    80007032:	e958                	sd	a4,144(a0)
    80007034:	ed5c                	sd	a5,152(a0)
    80007036:	0b053023          	sd	a6,160(a0)
    8000703a:	0b153423          	sd	a7,168(a0)
    8000703e:	0b253823          	sd	s2,176(a0)
    80007042:	0b353c23          	sd	s3,184(a0)
    80007046:	0d453023          	sd	s4,192(a0)
    8000704a:	0d553423          	sd	s5,200(a0)
    8000704e:	0d653823          	sd	s6,208(a0)
    80007052:	0d753c23          	sd	s7,216(a0)
    80007056:	0f853023          	sd	s8,224(a0)
    8000705a:	0f953423          	sd	s9,232(a0)
    8000705e:	0fa53823          	sd	s10,240(a0)
    80007062:	0fb53c23          	sd	s11,248(a0)
    80007066:	11c53023          	sd	t3,256(a0)
    8000706a:	11d53423          	sd	t4,264(a0)
    8000706e:	11e53823          	sd	t5,272(a0)
    80007072:	11f53c23          	sd	t6,280(a0)
    80007076:	140022f3          	csrr	t0,sscratch
    8000707a:	06553823          	sd	t0,112(a0)
    8000707e:	00853103          	ld	sp,8(a0)
    80007082:	02053203          	ld	tp,32(a0)
    80007086:	01053283          	ld	t0,16(a0)
    8000708a:	00053303          	ld	t1,0(a0)
    8000708e:	12000073          	sfence.vma
    80007092:	18031073          	csrw	satp,t1
    80007096:	12000073          	sfence.vma
    8000709a:	8282                	jr	t0

000000008000709c <userret>:
    8000709c:	12000073          	sfence.vma
    800070a0:	18051073          	csrw	satp,a0
    800070a4:	12000073          	sfence.vma
    800070a8:	02000537          	lui	a0,0x2000
    800070ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800070ae:	0536                	slli	a0,a0,0xd
    800070b0:	02853083          	ld	ra,40(a0)
    800070b4:	03053103          	ld	sp,48(a0)
    800070b8:	03853183          	ld	gp,56(a0)
    800070bc:	04053203          	ld	tp,64(a0)
    800070c0:	04853283          	ld	t0,72(a0)
    800070c4:	05053303          	ld	t1,80(a0)
    800070c8:	05853383          	ld	t2,88(a0)
    800070cc:	7120                	ld	s0,96(a0)
    800070ce:	7524                	ld	s1,104(a0)
    800070d0:	7d2c                	ld	a1,120(a0)
    800070d2:	6150                	ld	a2,128(a0)
    800070d4:	6554                	ld	a3,136(a0)
    800070d6:	6958                	ld	a4,144(a0)
    800070d8:	6d5c                	ld	a5,152(a0)
    800070da:	0a053803          	ld	a6,160(a0)
    800070de:	0a853883          	ld	a7,168(a0)
    800070e2:	0b053903          	ld	s2,176(a0)
    800070e6:	0b853983          	ld	s3,184(a0)
    800070ea:	0c053a03          	ld	s4,192(a0)
    800070ee:	0c853a83          	ld	s5,200(a0)
    800070f2:	0d053b03          	ld	s6,208(a0)
    800070f6:	0d853b83          	ld	s7,216(a0)
    800070fa:	0e053c03          	ld	s8,224(a0)
    800070fe:	0e853c83          	ld	s9,232(a0)
    80007102:	0f053d03          	ld	s10,240(a0)
    80007106:	0f853d83          	ld	s11,248(a0)
    8000710a:	10053e03          	ld	t3,256(a0)
    8000710e:	10853e83          	ld	t4,264(a0)
    80007112:	11053f03          	ld	t5,272(a0)
    80007116:	11853f83          	ld	t6,280(a0)
    8000711a:	7928                	ld	a0,112(a0)
    8000711c:	10200073          	sret
	...
