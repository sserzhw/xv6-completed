#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return wait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int n;

  argint(0, &n);
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  backtrace();
  int n;
  uint ticks0;

  argint(0, &n);
  if(n < 0)
    n = 0;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}





//lab4.3
// sys_sigalarm: 设置报警定时器。
// 参数 inteval: 报警间隔（以时钟滴答为单位），0 表示取消报警。
// 参数 handler: 用户态报警处理函数的地址。
// 当进程消耗的 CPU 时间达到 inteval 个滴答时，内核将调用 handler。
uint64
sys_sigalarm(void)
{
  int inteval;
  uint64 handler;

  argint(0, &inteval);
  argaddr(1, &handler);

  struct proc *p = myproc();
  p->alarm_inteval = inteval;
  p->alarm_handler = (void (*)(void))handler;
  p->alarm_ticks = 0;
  p->alarm_armed = 0;

  return 0;
}

// sys_sigreturn: 从报警处理程序返回。
// 恢复被中断的用户程序上下文（所有寄存器、PC），
// 并允许后续再次触发报警。
// 注意：必须返回保存的 a0 值，因为 syscall() 会将返回值
// 写入 p->trapframe->a0，覆盖刚才恢复的值。
uint64 sys_sigreturn(void)
{
  struct proc *p = myproc();
  // 先读取被中断时保存的 a0，memmove 会覆盖掉 trapframe
  uint64 saved_a0 = p->alarm_trapframe->a0;
  // 恢复被中断时的完整寄存器现场
  memmove(p->trapframe, p->alarm_trapframe, sizeof(struct trapframe));
  // 清除报警处理程序执行标志，允许再次触发
  p->alarm_armed = 0;
  // 返回保存的 a0，使 syscall() 写入正确的 a0 值
  return saved_a0;
}
