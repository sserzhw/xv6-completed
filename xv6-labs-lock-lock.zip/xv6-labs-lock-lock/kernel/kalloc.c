// Physical memory allocator, for user processes,
// kernel stacks, page-table pages,
// and pipe buffers. Allocates whole 4096-byte pages.

#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "riscv.h"
#include "defs.h"

void freerange(void *pa_start, void *pa_end);

extern char end[]; // first address after kernel.
                   // defined by kernel.ld.

struct run {
  struct run *next;
};

struct {
  struct spinlock lock;
  struct run *freelist;
} kmem[NCPU];

char kmem_lock_names[NCPU][8];

void
kinit()
{
  for (int i = 0; i < NCPU; i++) {
    snprintf(kmem_lock_names[i], 8, "kmem_%d", i);
    initlock(&kmem[i].lock, kmem_lock_names[i]);
  }
  freerange(end, (void*)PHYSTOP);
}

void
freerange(void *pa_start, void *pa_end)
{
  char *p;
  p = (char*)PGROUNDUP((uint64)pa_start);
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    kfree(p);
}

// Free the page of physical memory pointed at by pa,
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);

  r = (struct run*)pa;

  push_off();
  int id = cpuid();
  acquire(&kmem[id].lock);
  r->next = kmem[id].freelist;
  kmem[id].freelist = r;
  release(&kmem[id].lock);
  pop_off();
}

// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
  struct run *r;

  push_off();
  int id = cpuid();
  acquire(&kmem[id].lock);
  r = kmem[id].freelist;
  if(r) {
    kmem[id].freelist = r->next;
    release(&kmem[id].lock);
    pop_off();
  } else {
    release(&kmem[id].lock);
    // Steal up to 64 pages from another CPU
    for (int i = 0; i < NCPU; i++) {
      int other = (id + 1 + i) % NCPU;
      if (other == id) continue;
      acquire(&kmem[other].lock);
      r = kmem[other].freelist;
      if(r) {
        // Take up to 64 pages from victim
        struct run *last = r;
        int count = 1;
        while (last->next && count < 64) {
          last = last->next;
          count++;
        }
        kmem[other].freelist = last->next;
        last->next = 0;
        release(&kmem[other].lock);
        // Put remaining stolen pages on our freelist
        if (r->next) {
          acquire(&kmem[id].lock);
          last->next = kmem[id].freelist;
          kmem[id].freelist = r->next;
          release(&kmem[id].lock);
        }
        r->next = 0;
        break;
      }
      release(&kmem[other].lock);
    }
    pop_off();
  }

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
  return (void*)r;
}
