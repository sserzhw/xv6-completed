// Buffer cache.
//
// The buffer cache is a linked list of buf structures holding
// cached copies of disk block contents.  Caching disk blocks
// in memory reduces the number of disk reads and also provides
// a synchronization point for disk blocks used by multiple processes.
//
// Interface:
// * To get a buffer for a particular disk block, call bread.
// * After changing buffer data, call bwrite to write it to disk.
// * When done with the buffer, call brelse.
// * Do not use the buffer after calling brelse.
// * Only one process at a time can use a buffer,
//     so do not keep them longer than necessary.


#include "types.h"
#include "param.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "riscv.h"
#include "defs.h"
#include "fs.h"
#include "buf.h"

#define NBUCKET 13
#define HASH(dev, blockno) ((((dev) << 27) | (blockno)) % NBUCKET)

struct {
  struct spinlock lock;
  struct buf buf[NBUF];
  struct {
    struct spinlock lock;
    struct buf head;
  } bucket[NBUCKET];
} bcache;

char bcache_bucket_names[NBUCKET][32];

void
binit(void)
{
  struct buf *b;

  initlock(&bcache.lock, "bcache");

  for (int i = 0; i < NBUCKET; i++) {
    snprintf(bcache_bucket_names[i], 32, "bcache.bucket_%d", i);
    initlock(&bcache.bucket[i].lock, bcache_bucket_names[i]);
    bcache.bucket[i].head.prev = &bcache.bucket[i].head;
    bcache.bucket[i].head.next = &bcache.bucket[i].head;
  }

  // Create linked list of buffers, evenly distributed among buckets
  int bi = 0;
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    b->next = bcache.bucket[bi].head.next;
    b->prev = &bcache.bucket[bi].head;
    b->timestamp = 0;
    initsleeplock(&b->lock, "buffer");
    bcache.bucket[bi].head.next->prev = b;
    bcache.bucket[bi].head.next = b;
    bi = (bi + 1) % NBUCKET;
  }
}

// Look through buffer cache for block on device dev.
// If not found, allocate a buffer.
// In either case, return locked buffer.
static struct buf*
bget(uint dev, uint blockno)
{
  struct buf *b;
  uint key = HASH(dev, blockno);
  uint lk_first, lk_second;

  acquire(&bcache.bucket[key].lock);

  // Is the block already cached?
  for(b = bcache.bucket[key].head.next; b != &bcache.bucket[key].head; b = b->next){
    if(b->dev == dev && b->blockno == blockno){
      release(&bcache.bucket[key].lock);
      __sync_fetch_and_add(&b->refcnt, 1);
      b->timestamp = ticks;
      acquiresleep(&b->lock);
      return b;
    }
  }
  release(&bcache.bucket[key].lock);

  // Not cached.
  // Need to recycle a buffer. Serialize recycling with global bcache lock.
  acquire(&bcache.lock);

  // Double-check in case it was added while we released the bucket lock
  acquire(&bcache.bucket[key].lock);
  for(b = bcache.bucket[key].head.next; b != &bcache.bucket[key].head; b = b->next){
    if(b->dev == dev && b->blockno == blockno){
      release(&bcache.bucket[key].lock);
      __sync_fetch_and_add(&b->refcnt, 1);
      b->timestamp = ticks;
      release(&bcache.lock);
      acquiresleep(&b->lock);
      return b;
    }
  }
  release(&bcache.bucket[key].lock);

  // Find the least recently used unused buffer across all buckets.
  struct buf *victim = 0;
  uint victim_key = 0;
  uint min_ticks = 0xFFFFFFFF;

  for (int i = 0; i < NBUCKET; i++) {
    acquire(&bcache.bucket[i].lock);
    for(b = bcache.bucket[i].head.next; b != &bcache.bucket[i].head; b = b->next){
      if(b->refcnt == 0 && b->timestamp < min_ticks){
        min_ticks = b->timestamp;
        victim = b;
        victim_key = i;
      }
    }
    release(&bcache.bucket[i].lock);
  }

  if (victim == 0)
    panic("bget: no buffers");

do_recycle:
  // Acquire both bucket locks in order to avoid deadlock.
  if (victim_key < key) {
    lk_first = victim_key;
    lk_second = key;
  } else if (key < victim_key) {
    lk_first = key;
    lk_second = victim_key;
  } else {
    lk_first = key;
    lk_second = key;
  }

  acquire(&bcache.bucket[lk_first].lock);
  if (lk_first != lk_second)
    acquire(&bcache.bucket[lk_second].lock);

  // Verify victim is still unused (race with bget cache-hit path)
  if (victim->refcnt != 0) {
    if (lk_first != lk_second) {
      release(&bcache.bucket[lk_second].lock);
    }
    release(&bcache.bucket[lk_first].lock);
    release(&bcache.lock);
    // Retry from the beginning
    goto retry;
  }

  // Remove victim from its bucket
  victim->next->prev = victim->prev;
  victim->prev->next = victim->next;

  // Add victim to target bucket (at head)
  victim->next = bcache.bucket[key].head.next;
  victim->prev = &bcache.bucket[key].head;
  bcache.bucket[key].head.next->prev = victim;
  bcache.bucket[key].head.next = victim;

  victim->dev = dev;
  victim->blockno = blockno;
  victim->valid = 0;
  victim->refcnt = 1;
  victim->timestamp = ticks;

  if (lk_first != lk_second) {
    release(&bcache.bucket[lk_second].lock);
  }
  release(&bcache.bucket[lk_first].lock);
  release(&bcache.lock);

  acquiresleep(&victim->lock);
  return victim;

retry:
  acquire(&bcache.bucket[key].lock);
  for(b = bcache.bucket[key].head.next; b != &bcache.bucket[key].head; b = b->next){
    if(b->dev == dev && b->blockno == blockno){
      release(&bcache.bucket[key].lock);
      __sync_fetch_and_add(&b->refcnt, 1);
      b->timestamp = ticks;
      acquiresleep(&b->lock);
      return b;
    }
  }
  release(&bcache.bucket[key].lock);

  acquire(&bcache.lock);

  // Find LRU victim again starting fresh
  victim = 0;
  min_ticks = 0xFFFFFFFF;
  for (int i = 0; i < NBUCKET; i++) {
    acquire(&bcache.bucket[i].lock);
    for(b = bcache.bucket[i].head.next; b != &bcache.bucket[i].head; b = b->next){
      if(b->refcnt == 0 && b->timestamp < min_ticks){
        min_ticks = b->timestamp;
        victim = b;
        victim_key = i;
      }
    }
    release(&bcache.bucket[i].lock);
  }

  if (victim == 0)
    panic("bget: no buffers");

  // Re-establish ordering
  if (victim_key < key) {
    lk_first = victim_key;
    lk_second = key;
  } else if (key < victim_key) {
    lk_first = key;
    lk_second = victim_key;
  } else {
    lk_first = key;
    lk_second = key;
  }

  goto do_recycle;
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
  if(!holdingsleep(&b->lock))
    panic("bwrite");
  virtio_disk_rw(b, 1);
}

// Release a locked buffer.
void
brelse(struct buf *b)
{
  if(!holdingsleep(&b->lock))
    panic("brelse");

  releasesleep(&b->lock);

  __sync_fetch_and_add(&b->refcnt, -1);
}

void
bpin(struct buf *b) {
  __sync_fetch_and_add(&b->refcnt, 1);
}

void
bunpin(struct buf *b) {
  __sync_fetch_and_add(&b->refcnt, -1);
}


